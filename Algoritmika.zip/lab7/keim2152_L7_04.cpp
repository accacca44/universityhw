//Kovacs Elek Akos
//513/1
//2152
//Feladat 4 : MergeSort

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(int& n, vector<double>& a)
{
    ifstream in("bemenet04.txt");
    in >> n;
    for (int i = 0; i < n; i++)
    {
        double aux = 0;
        in >> aux;
        a.push_back(aux);
    }
    in.close();
}

void kiir(vector<double> a)
{
    ofstream out("kimenet04.txt");

    for (double i : a)
        out << i << " " << endl;
    out << endl;
}

void osszefesul(vector<double>& a, int bal, int kozep, int jobb)
{
    vector<double> seged(a.size());                     //segedtomb
    for (int i = 0; i < a.size(); i++)
        seged[i] = a[i];

    int db = bal;                                       

    int i = bal;
    int j = kozep + 1;
    while ((i <= kozep) && (j <= jobb))
    {
        if (a[i] < a[j])
        {
            seged[db] = a[i];
            i++;
        }
        else
        {
            seged[db] = a[j];
            j++;
        }
        db++;
    }
    while (i <= kozep)
    {
        seged[db] = a[i];
        i++;
        db++;
    }
    while (j <= bal)
    {
        seged[db] = a[j];
        j++;
        db++;
    }

    for (int i = 0; i < a.size(); i++)
        a[i] = seged[i];
}


void mergeSort(int n, vector<double>& a, int bal, int jobb)
{
    if (bal < jobb)
    {
        int kozep = (bal + jobb) / 2;
        mergeSort(n, a, bal, kozep);
        mergeSort(n, a, kozep + 1, jobb);
        osszefesul(a, bal, kozep, jobb);
    }
}

int main()
{
    int n;
    vector<double> a;

    beolvas(n, a);

    mergeSort(n, a, 0, n - 1);

    kiir(a);
}