//Kovacs Elek Akos
//513/1
//2152
//Feladat 1 : Legyen n darab 32 bites előjeles egész szám, állapítsuk meg a számok összegét Oszd meg és uralkodj módszerrel!

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(int &n, vector<int>& a)
{
    ifstream in("bemenet01.txt");
    in >> n;
    for(int i = 0; i < n; i++)
    {
        int aux = 0;
        in >> aux;
        a.push_back(aux);
    }
    in.close();
}

void kiir(long long x)
{
    ofstream out("kimenet01.txt");
    out << x;
}

long long D_osszeg(vector<int> a, int n, int bal, int jobb)
{
    if(bal == jobb)
        return a[jobb];
    else
    {
        int mid = (bal + jobb)/2;
        int s1 = D_osszeg(a,n,bal,mid);
        int s2 = D_osszeg(a,n,mid+1, jobb);
        return s1+s2;
    }
}

int main()
{   
    int n;              // -darab szam
    vector<int> a;      //sorozat
    
    beolvas(n,a);

    long long sum = 0;
    sum = D_osszeg(a,n,0,n-1);
    
    kiir(sum);
    
    return 0;
}