//Kovacs Elek Akos
//513/1
//2152
//Feladat 10 : Adott egy ponthalmaz, amely 2n (n > 1) pontot tartalmaz. Ismerve a pontok koordinátáit, határozzuk meg a legközelebb eső két pont közötti 
//			   távolságot!

#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <cfloat>
#include <algorithm>

using namespace std;

struct Node2D{
	double x;
	double y;
};

int hatvany(int x, int y)
{
	if (y != 0)
	{
		if (y % 2 == 1)
			return	x * hatvany(x * x, y / 2);
		return hatvany(x * x, y/2);
	}
	return 1;
}

void beolvas(int& n, vector<Node2D>& points)
{
	ifstream in("bemenet10.txt");
	in >> n;

	n = hatvany(2, n);
	Node2D temp;
	for (int i = 0; i < n; i++)
	{
		in >> temp.x >> temp.y;
		points.push_back(temp);
	}
    in.close();
}

void kiir(double x)
{
	ofstream out("kimenet10.txt");
	out << x;
	out.close();
}

//beepitett rendezeshez szukseges osszehasonlitas
bool osszehasonlit(Node2D n1, Node2D n2)
{
	if (n1.x < n2.x)return true;
	return false;
}

//kiszamolja ket pont kozott a tavolsagot
double getDist(Node2D node1, Node2D node2)
{
	double temp = ((node2.x - node1.x) * (node2.x - node1.x)) + ((node2.y - node1.y) * (node2.y - node1.y));
	return sqrt(temp);
}

//a jobb es bal oldal kozotti atfedest szamolja negyzetesen
double getCross(vector<Node2D> points, int bal, int kozep, int jobb, double min)
{
	double temp_min = DBL_MAX;
	for (int i = bal; i <= kozep; i++)
	{
		for (int j = kozep + 1; j <= jobb; j++)
		{
			temp_min = getDist(points[i], points[j]);
			if (temp_min < min)
			{
				min = temp_min;
			}
		}
	}
	return min;
}

//driver code megkeresi a legkissebb tavolsagot 2 pont kozott
double getMin(vector<Node2D> points, int bal, int jobb, int n)
{
	if ((jobb - bal) == 1)
	{
		return getDist(points[bal], points[jobb]);
	}
	else
	{
		int kozep = (bal + jobb) / 2;
		double d1 = getMin(points, bal, kozep, n);
		double d2 = getMin(points, kozep + 1, jobb, n);
		double d = min(d1, d2);
		double d3 = getCross(points, bal, kozep, jobb,d);
		return min(d, d3);
	}
}

int main()
{
	vector<Node2D>points;
	int n = 0;

	beolvas(n, points);												//beolvasom az adatokat

	sort(points.begin(), points.end(), osszehasonlit);				//rendezem x koordinata szerint

	double min = getMin(points, 0, n - 1, n);

	kiir(min);

	
}