//Kovacs Elek Akos
//513/1
//2152
//Feladat 3 : Adott egy n elemű tömb, mely 32 bites előjeles egész számokat tartalmaz és egy x 32 bites előjeles 
            //egész szám. Határozzuk meg, hogy létezik-e két olyan eleme a tömbnek, melynek összege pontosan x. 
            //Alkalmazzunk bináris keresést!


#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(int& x, int& n, vector<int>& a)
{
    ifstream in("bemenet03.txt");
    in >> n;
    in >> x;
    for (int i = 0; i < n; i++)
    {
        int aux = 0;
        in >> aux;
        a.push_back(aux);
    }
}

void osszefesul(vector<int>& a, int bal, int kozep, int jobb)
{
    vector<int> seged(a.size());                     //segedtomb
    for (int i = 0; i < a.size(); i++)
        seged[i] = a[i];

    int db = bal;

    int i = bal;
    int j = kozep + 1;
    while ((i <= kozep) && (j <= jobb))
    {
        if (a[i] < a[j])
        {
            seged[db] = a[i];
            i++;
        }
        else
        {
            seged[db] = a[j];
            j++;
        }
        db++;
    }
    while (i <= kozep)
    {
        seged[db] = a[i];
        i++;
        db++;
    }
    while (j <= bal)
    {
        seged[db] = a[j];
        j++;
        db++;
    }

    for (int i = 0; i < a.size(); i++)
        a[i] = seged[i];
}

void mergeSort(int n, vector<int>& a, int bal, int jobb)
{
    if (bal < jobb)
    {
        int kozep = (bal + jobb) / 2;
        mergeSort(n, a, bal, kozep);
        mergeSort(n, a, kozep + 1, jobb);
        osszefesul(a, bal, kozep, jobb);
    }
}

bool bin_search(int n, vector<int> a, int s, int bal, int jobb)
{
    if (bal <= jobb)
    {
        int mid = (jobb + bal) / 2;
        if (s > a[mid])
            bin_search(n, a, s, mid + 1, jobb);
        else
        {
            if (s < a[mid])
                bin_search(n, a, s, bal, mid - 1);
            else
            {
                return true;
            }
        }
    }
    return false;
}

void sum2(int n, vector<int> a, int x)
{
    ofstream out("kimenet03.txt");

    bool ok = false;

    //iteralom a sorozatot
    for (int i = 0; i < n; i++)
    {
        int to_search = x - a[i];
        ok = bin_search(n, a, to_search, i + 1, n - 1);
        if (ok)
        {
            out << "IGEN" << endl;
            out << a[i] << " " << x - a[i];
            break;
        }
    }
    if (!ok)
    {
        out << "NEM";
    }

    out.close();
}

int main()
{
    int x;            //osszeg
    int n;           //n elemu sorozat
    vector<int> a;  //sorozat

    beolvas(x, n, a);

    mergeSort(n, a, 0, n - 1);

    sum2(n, a, x);
}