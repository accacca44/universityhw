//Kovacs Elek Akos
//513/1
//2152
//Feladat 9 : Egy kiállítási csarnokot le fognak fedni előre gyártott műanyaglapokkal. Előbb felosztották a 
            //csarnok alapját négyzet alakú felületekre úgy, hogy a csarnok belsejében található oszlop pontosan egy ilyen 
            //négyzetnyi helyet foglaljon el. A műanyaglapok alakja olyan, hogy három ilyen négyzetet fednek majd le.
            //A tervező rájött, hogy nem fogja tudni ezekkel lefedni a teljes felületet, ezért kiválasztott egy 2n x 2n méretű 
            //részt a csarnokból, amelyen ott van az oszlop is. Tervezzük meg a lefedést felhasználva az alakzatot úgy, hogy ne 
            //maradjon fedetlen felület a kiválasztott részben. Ezen alakzat elforgatható három irányba.

#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <algorithm>

using namespace std;

struct Node2D
{
    int x;
    int y;
};

void beolvas(int& n, Node2D& oszlop)
{
    ifstream in("bemenet09.txt");
    in >> n;
    in >> oszlop.x >> oszlop.y;
    oszlop.x--;
    oszlop.y--;
    in.close();
}

void kiir(vector<vector<Node2D>> m)
{
    ofstream out("kimenet09.txt");
    for (vector<Node2D> vec : m)
    {
        for (Node2D node : vec)
        {
            out << "(" << node.x + 1 << ", " << node.y + 1 << ") ";
        }
        out << endl;
    }
}

int melyik_negyed(Node2D eleje, Node2D vege,Node2D temp)
{
    //a visszateritett ertekek egy 4x4es matrrixra :        0011
    //                                                      2233


    Node2D kozep;
    kozep.x = (eleje.x + vege.x) / 2;
    kozep.y = (eleje.y + vege.y) / 2;

    //jobb oldal
    if (kozep.y < temp.y)
    {
        //fent
        if (kozep.x < temp.x)
        {
            return 3;
        }
        //lent
        else
        {
            return 1;
        }
    }
    //bal oldal
    else
    {
        //fent
        if (kozep.x < temp.x)
        {
            return 2;
        }
        //lent
        else
        {
            return 0;
        }
    }   

}

void lefed(Node2D eleje, Node2D vege, Node2D oszlop, vector<vector<Node2D>>& megoldas)
{
    //egy sor taralmazza a a csempe 3 kockajanak koordinatait lexikografikus sorrendben
    vector<Node2D> sorok;
    Node2D mid;
    mid.x = (eleje.x + vege.x) / 2;
    mid.y = (eleje.y + vege.y) / 2;
    //megkeresem melyik negyedben van az oszlop
    int pos = melyik_negyed(eleje, vege, oszlop);

    //leallasi feltetel
    //eleje = bal also
    //vege  = jobb felso
    if (vege.y - eleje.y == 1)
    {

        //egy 2x2-es kockahoz ertunk ahol mindent be lehet egyszerre fedni
        //vizsgalom, hogy hova kell rakni a 3 kockat

        //az oszlop bal fent van
        if (pos == 0)
        {
            sorok.push_back({ mid.x,mid.y+1 });            //koordinatak: (le, jobbra)
            sorok.push_back({ mid.x+1,mid.y });
            sorok.push_back({ mid.x+1,mid.y+1 });
        }
        //az oszlop bal lent van
        if (pos == 2)
        {
            sorok.push_back({ mid.x,mid.y });
            sorok.push_back({ mid.x,mid.y +1});
            sorok.push_back({ mid.x+1,mid.y+1 });
        }
        //az oszlop jobb fent van
        if (pos == 1)
        {
            sorok.push_back({ mid.x,mid.y });
            sorok.push_back({ mid.x+1,mid.y });
            sorok.push_back({ mid.x + 1,mid.y+1 });
        }        
        //az oszlop jobb lent van
        if (pos == 3)
        {
            sorok.push_back({ mid.x,mid.y });
            sorok.push_back({ mid.x,mid.y +1 });
            sorok.push_back({ mid.x +1,mid.y });
        }

        megoldas.push_back(sorok);
    }
    //ha egy nagyobb negyzetben vagyunk (4x4, 8x8...)
    else
    {     
        //a 2^n hosszu negyzetben a kozeppont mindig az oldalakkal parhuzamos szimmetriatengely metszetetol
        //a legkozelebbi pont fel es balra
        /*pl:
                    0000
                    0100
                    0000
                    0000    */

        //bal fent
        if (pos == 0)
        {
            sorok.push_back({ mid.x,mid.y+1 });         //koordinatak: (le, jobbra)
            sorok.push_back({ mid.x+1,mid.y });
            sorok.push_back({ mid.x+1,mid.y+1 });

            lefed({ mid.x,eleje.y }, { vege.x,mid.y }, oszlop, megoldas);
            lefed({ mid.x,mid.y + 1 }, { vege.x,vege.y }, {mid.x,mid.y+1}, megoldas);
            lefed({ eleje.x,eleje.y }, { mid.x + 1,mid.y }, {mid.x+1,mid.y}, megoldas);
            lefed({ eleje.x,mid.y + 1 }, { mid.x + 1,vege.y }, {mid.x+1,mid.y+1}, megoldas);
        }

        //jobb fent
        if (pos == 1)
        {
            sorok.push_back({ mid.x,mid.y });            //koordinatak: (le, jobbra)
            sorok.push_back({ mid.x + 1,mid.y });
            sorok.push_back({ mid.x + 1,mid.y + 1 });
        
            lefed({ mid.x,eleje.y }, { vege.x,mid.y }, { mid.x,mid.y }, megoldas);
            lefed({ mid.x,mid.y + 1 }, { vege.x,vege.y }, oszlop, megoldas);
            lefed({ eleje.x,eleje.y }, { mid.x + 1,mid.y }, { mid.x + 1,mid.y }, megoldas);
            lefed({ eleje.x,mid.y + 1 }, { mid.x + 1,vege.y }, { mid.x + 1,mid.y + 1 }, megoldas);
        }

        //bal lent
        if (pos == 2)
        {
            sorok.push_back({ mid.x,mid.y });            //koordinatak: (le, jobbra)
            sorok.push_back({ mid.x,mid.y + 1 });
            sorok.push_back({ mid.x + 1,mid.y + 1 });

            lefed({ mid.x,eleje.y }, { vege.x,mid.y }, { mid.x,mid.y }, megoldas);
            lefed({ mid.x,mid.y + 1 }, { vege.x,vege.y }, { mid.x,mid.y + 1 }, megoldas);
            lefed({ eleje.x,eleje.y }, { mid.x + 1,mid.y }, oszlop, megoldas);
            lefed({ eleje.x,mid.y + 1 }, { mid.x + 1,vege.y }, { mid.x + 1,mid.y + 1 }, megoldas);
        }
        
        //jobb lent
        if (pos == 3)
        {
            sorok.push_back({ mid.x,mid.y });            //koordinatak: (le, jobbra)
            sorok.push_back({ mid.x,mid.y + 1 });
            sorok.push_back({ mid.x + 1,mid.y });

            lefed({ mid.x,eleje.y }, { vege.x,mid.y }, { mid.x,mid.y }, megoldas);
            lefed({ mid.x,mid.y + 1 }, { vege.x,vege.y }, { mid.x,mid.y + 1 }, megoldas);
            lefed({ eleje.x,eleje.y }, { mid.x + 1,mid.y }, { mid.x + 1,mid.y }, megoldas);
            lefed({ eleje.x,mid.y + 1 }, { mid.x + 1,vege.y }, oszlop, megoldas);
        }

        megoldas.push_back(sorok);
    }
}

bool compare(vector<Node2D>v1, vector<Node2D> v2)
{
    if (v1[0].x < v2[0].x)
        return true;
    return false;
}

int main()
{
    int n = 0;
    int l = 0;  //a negyzet oldala
    Node2D oszlop;
    Node2D eleje;
    Node2D vege;

    beolvas(n, oszlop);

    l = pow(2, n);
    
    //koordinatak: {le, jobb}
    eleje = { l - 1,0 };
    vege  = { 0, l - 1 };

    vector<vector<Node2D>> megoldas;

    lefed(eleje, vege, oszlop, megoldas);

    sort(megoldas.begin(), megoldas.end(), compare);

    kiir(megoldas);
    




    return 0;
}