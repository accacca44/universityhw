//Kovacs Elek Akos
//513/1
//2152
//Feladat 2 : Legyen a következő játék: az egyik játékos (Játékos1) gondol egy 0 és 1000 közötti természetes számra. 
            //A másik játékosnak (Játékos2) ki kell találnia ezt a számot minél kevesebb próbálgatással. A titkos szám „birtokosa” 
            //(Játékos1) egy-egy találgatásra csak annyit válaszol, hogy a titkos szám kisebb vagy nagyobb mint a másik játékos 
            //(Játékos2) által feltételezett szám.

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

short choose(int x)
{
    short a;
    cout << x << "ra gondoltal?"<<endl;
    cout << "1 - Igen!" << endl;
    cout << "2 - Nem, nagyobb!" << endl;
    cout << "3 - Nem, kisebb!" << endl;
    cout << "Valaszod : ";
    cin >> a;
    
    switch (a)
    {
    case 1:
        return 1;
        break;
    case 2:
        return 2;
        break;
    case 3:
        return 3;
        break;
    default:
        break;
    }
}

void guesser(int bal, int jobb)
{
    if(bal == jobb)
        cout << "Szerintem " << bal << "ra gondoltal." << endl;
    else
    {
        int kozep = (bal + jobb)/2;
        short valasz = choose(kozep);

        if(valasz == 1)cout << "Szerintem " << kozep << "ra gondoltal.";
        if(valasz == 2)guesser(kozep+1, jobb);
        if(valasz == 3)guesser(bal,kozep);
    }
}

int main()
{
    int bal = 0;
    int jobb = 1000;
    guesser(bal,jobb);

    return 0;
}