//Kovacs Elek Akos
//513/1
//2152
//Feladat 5 : Adott egy legtöbb 1 000 000 karakterláncot tartalmazó sorozat. 
            /*Rendezzük ezeket lexikografikusan növekvő sorrendbe a QuickSort algoritmus tetszőleges változatának
            segítségével! A bemeneti állomány első sora a sorozat hosszát tartalmazza, majd az ezt követő sorokban
            a sorozat egy-egy elemét soronként. Feltételezhetjük, hogy egy karakterlánc hossza legtöbb
            100 karakter és csak a latin ábécé kisbetűit tartalmazza. A kimeneti állomány a rendezett sorozat
            elemeit tartalmazza soronként.*/

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void beolvas(vector<double>& v, int& n, int& k)
{
    ifstream in("bemenet06.txt");
    in >> n >> k;
    for (int i = 0; i < n; i++)
    {
        double aux;
        in >> aux;
        v.push_back(aux);
    }
    in.close();
}

void kiir(double x)
{
    ofstream out("kimenet06.txt");
    out << x;
    out.close();
}

//Hoare felosztas
int feloszt(vector<double>& v, int bal, int jobb)
{
    double strazsa = v[jobb];
    int i = bal - 1;

    for (int j = bal; j < jobb; j++)
    {
        if (v[j] <= strazsa)
        {
            i++;
            //swap(v[i], v[j]);
            double  temp = v[i];
            v[i] = v[j];
            v[j] = temp;
        }
    }
    //swap(v[i + 1], v[jobb]);
    double temp = v[i + 1];
    v[i + 1] = v[jobb];
    v[jobb] = temp;
    return i + 1;
}

double quickSort(vector<double>& v, int bal, int jobb, int k)
{
    if (bal <= jobb)
    {
        int m = feloszt(v, bal, jobb);

        if (m + 1 == k)
            return v[m];
        else if(k > m + 1)
            return quickSort(v, m + 1, jobb, k);
        else
            return quickSort(v, bal, m - 1, k);
    
    }
}

int main()
{
    int n;
    int k;
    vector<double> v;

    beolvas(v, n, k);

    kiir(quickSort(v, 0, n - 1, k));

    return 0;

}