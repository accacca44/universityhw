//Kovacs Elek Akos
//513/1
//2152
//Feladat 5 : Adott egy legtöbb 1 000 000 karakterláncot tartalmazó sorozat. 
            /*Rendezzük ezeket lexikografikusan növekvő sorrendbe a QuickSort algoritmus tetszőleges változatának
            segítségével! A bemeneti állomány első sora a sorozat hosszát tartalmazza, majd az ezt követő sorokban
            a sorozat egy-egy elemét soronként. Feltételezhetjük, hogy egy karakterlánc hossza legtöbb
            100 karakter és csak a latin ábécé kisbetűit tartalmazza. A kimeneti állomány a rendezett sorozat
            elemeit tartalmazza soronként.*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

void beolvas(vector<string>& v, int& n)
{
    ifstream in("bemenet05.txt");
    in >> n;
    for (int i = 0; i < n; i++)
    {
        string aux;
        in >> aux;
        v.push_back(aux);
    }
    in.close();
}

void kiir(vector<string> v)
{
    ofstream out("kimenet05.txt");
    for (string i : v)
        out << i << endl;
    out.close();
}

//Hoare felosztas
int feloszt(vector<string>& v, int bal, int jobb)
{
    string strazsa = v[bal];
    int i = bal - 1;
    int j = jobb + 1;

    do
    {

        do
        {
                j--;
        } while (v[j] > strazsa);

        do
        {
                i++;
        } while (v[i] < strazsa);

        if (i < j)
        {
            //swap(v[i], v[j]);
            string temp = v[i];
            v[i] = v[j];
            v[j] = temp;

        }
    } while (i < j);
    return j;
}

void quickSort(vector<string>& v, int bal, int jobb)
{
    if (bal < jobb)
    {
        int m = feloszt(v, bal, jobb);
        quickSort(v, bal, m);
        quickSort(v, m + 1, jobb);
    }
}

int main()
{
    int n;
    vector<string> v;

    beolvas(v, n);

    quickSort(v, 0, n - 1);

    kiir(v);

    return 0;

}