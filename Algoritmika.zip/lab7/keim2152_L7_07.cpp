//Kovacs Elek Akos
//513/1
//2152
//Feladat 7 : Adott egy n darab 64 bites valós számot tartalmazó sorozat. Határozzuk meg azt a legnagyobb összeget, 
            //amelyet a tömb egymás utáni elemeinek összeadásával kaphatunk (vagyis a legnagyobb összegű tömbszakaszt keressük).


#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(vector<double>& a, int& n)
{
    ifstream in("bemenet07.txt");
    in >> n;
    for (int i = 0; i < n; i++)
    {
        double aux;
        in >> aux;
        a.push_back(aux);
    }
    in.close();
}

double maxi(double a, double b)
{
    if (a > b)
        return a;
    return b;
}

double maxiAtfedes(vector<double> a, int n, int bal,int kozep, int jobb)
{
    double jobb_maxi = a[kozep+1];
    double bal_maxi = a[kozep];

    double temp = 0;

    for (int i = kozep; i >= bal;i--)
    {
        temp += a[i];
        bal_maxi = maxi(bal_maxi, temp);
    }

    temp = 0;
    for (int i = kozep+1; i <= jobb; i++)
    {
        temp += a[i];
        jobb_maxi = maxi(jobb_maxi, temp);
    }
    
    return maxi(bal_maxi + jobb_maxi, maxi(bal_maxi, jobb_maxi));
}

double maxiTombszakasz(vector<double> a, int n, int bal, int jobb)
{
    if (bal > jobb)
        return 0;
    else
    {
        if (bal == jobb)
            return a[bal];
        else
        {
            int  kozep = (bal + jobb) / 2;
            double jobb_oldal = maxiTombszakasz(a, n, bal, kozep);
            double bal_oldal = maxiTombszakasz(a, n, kozep+1, jobb);
            double atfedes = maxiAtfedes(a, n, bal, kozep, jobb);
            return maxi(maxi(jobb_oldal, bal_oldal), atfedes);
        }
    }
}

void kiir(double x)
{
    ofstream out("kimenet07.txt");
    out << x;
    out.close();
}

int main()
{
    vector<double> a;
    int n;

    beolvas(a, n);

    double sum = maxiTombszakasz(a, n, 0, n - 1);

    kiir(sum);

    return 0;
}