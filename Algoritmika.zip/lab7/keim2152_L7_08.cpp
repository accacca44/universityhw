//Kovacs Elek Akos
//513/1
//2152
//Feladat 8 : Adott egy f(x) másodfokú függvény. Határozzuk meg bináris kereséssel, hogy minimumpontja 
            //vagy maximumpontja van-e az [a,b] intervallumon és azt az x értéket amelyre ezt felveszi 10-6 pontossággal. 
            //Garantáljuk, hogy vagy minimum vagy maximum létezni fog az adott intervallumon. A bemeneti állományban a 
            //függvény együtthatói (64 bites valós számok, fokszám szerinti csökkenő sorrendben), valamint a és b 64 
            //bites valós számok találhatóak.


#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#define P 0.000001

using namespace std;

void beolvas(double& a, double& b, vector<double>& func)
{
    ifstream in("bemenet08.txt");
    for (int i = 0; i < 3; i++)
        in >> func[i];
    in >> a >> b;
}

//kiszamitja a func fuggveny erteket egy adott x pontban
double fuggveny_ertek(double x, vector<double> func)
{
    return (func[0] * x * x) + (func[1] * x) + (func[2]);
}

// a) valtozat 
double keres_ertek(vector<double> func, double a, double b, bool elojel)
{
    //a hatarokat viszem kozelebb egymashoz, amig el nem erem a kivant pontossagot
    double Fa = fuggveny_ertek(a, func);
    double Fb = fuggveny_ertek(b, func);

    //elertem a kivant P pontossagot, megkaptam a szelsoertek pontot
    if (abs(a - b) < P)
    {
        return a;
    }
    else
    {
        double mid = (a + b) / 2;
        if (abs(Fa - Fb) < P) 
        {
            return mid;
        }
            

        else
        {
            //tudom hogy minimum pontom van
            if (elojel)
            {
                if (Fa > Fb)return keres_ertek(func, mid, b, elojel);
                if (Fa < Fb)return keres_ertek(func, a, mid, elojel);
            }

            //tudom hogy maximum pontom van
            else
            {
                if (Fa < Fb)return keres_ertek(func, mid, b, elojel);
                if (Fa > Fb)return keres_ertek(func, a, mid, elojel);
            }
        }
    }
}

void kiir(double p, bool ok,vector<double> func)
{
    ofstream out("kimenet08.txt");
    if(ok)
        out << "Minimum: f(" << p << ") = " << fuggveny_ertek(p, func);
    else
        out << "Maximum: f(" << p << ") = " << fuggveny_ertek(p, func);
    
    out.close();
}


void szelsoertek(double a, double b, vector<double> func)
{    
    //eldonti hogy maximum vagy minimum pontom van
    bool elojel = (func[0] > 0) ? true : false;

    //megkeresi a helyi szelsoertek pontot
    double szelsoErtek = keres_ertek(func, a, b, elojel);

    //kiirja az kapott pontot
    kiir(szelsoErtek,elojel,func);
}



int main()
{
    //tarolja az egyenlet a, b, es c tagjait
    vector<double> func(3);

    //[a,b] intervallum
    double a = 0;
    double b = 0;

    beolvas(a, b, func);

    //megkeresi a szelsoertek pontot
    szelsoertek(a, b, func);

}