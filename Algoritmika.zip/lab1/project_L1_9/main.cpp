#include <iostream>

using namespace std;

bool leap_year(int x){

    if((x % 4 == 0 && x % 100 != 0) || x % 400 == 0){
        return true;
    }
    return false;
}

int leap_year_count(int x){
    int cnt = 0;
    for(int i = 1; i <x; i++){
        if(leap_year(i))cnt++;
    }
    return cnt;
}

int numb_of_days(int y, int m, int d){
    int day_of_months[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int dayz = 0;
    dayz += (d + 365*y);
    for(int i = 0 ; i < m-1;i++){
        dayz += day_of_months[i];
    }
    dayz += leap_year_count(y);

    return dayz;
}

int main()
{


    cout << numb_of_days(2023,4,5) - numb_of_days(1980,11,27);





    return 0;
}
