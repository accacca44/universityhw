//KOVACS ELEK - AKOS
//513/1
//L1_10
//�rjunk ki egy, a 60-as sz�mrendszerben megadott sz�mot a 10-es sz�mrendszerben! A 60-as sz�mrendszer sz�mjegyei: 0,1, �, 9, (10), (11), �, (59).

#include <iostream>
#include <string>
#include <vector>

using namespace std;

vector <int> v_result;

void input(string &str){
    cout << "Szam = ";

    cin >> str;
}


//Converting from character to integer
int convert_str(string str){
    int num;
    int k = '0' - 0; //difference between num and char (ascii)

    int l = str.size();
    if(l == 1){
        num = str[0]-k;
    }

    if(l == 2){
        num = (str[0]-k) * 10 + (str[1]-k);
    }

    return num;

}

void partialize(string &str){
    int numb;

    //Breaking down the input string from the end,
    //"digit" by "digit"
    while(str != ""){
    string aux = "";
    int n = str.size();

    //If the number is not in "( )"-brackets, is is a single digit
    //Ex: 2 or 9
    if(str[n-1] != ')'){
        aux = str.substr(n-1,1);
        str.erase(n-1,1);

        numb = convert_str(aux);
    }

    //If the number is in pharanteses, it shoud be greater than 9 and smaller than 60,
    //so it takes up 2 spaces + 2 from the berackets,
    //Ex:  (20) or (59)
    else{
        aux = str.substr(n-4,4);
        str.erase(n-4,4);

        //Deleting the brackets to pass only the digit characters
        //Ex: "(59)" --> "59"
        aux = aux.substr(1,2);
        numb = convert_str(aux);
    }

    //We save the digit in a vector
    v_result.push_back(numb);

    }

}

//A function to determin the n-th power of a number
int pow(int base, int power){
    int a = base;

    if(base == 1 || power == 1)return base;
    if(power == 0)return 1;

    for(int i = 0; i < power-1;i++){
        base *= a;
    }

    return base;
}


unsigned long long to_decimal(bool &ok){
    unsigned long long sum = 0;

    int x = 60;

    int n = v_result.size();

    //If the number of digits is greater than 12, it won't fit into a 64-bit integer
    if(n > 12){
        ok = false;
        return -1;
    }

    //If it fits, we do the math
    for(int i = 0; i <n ;i++){
        long long aux = v_result[i]*pow(x,i);
        //cout << aux << endl;
        sum += aux;

    //Exeption handling
    if(sum < 0 || sum > ULONG_MAX){
        ok = false;
        return -1;
    }
    }



    return sum;
}


//Printing the solution
void print(long long a, bool o){
    if(!o)cout << "The number is too big to handle!";

    else cout <<"A megadott szam 10-es szamrendszerben: "<< a;
}



int main()
{
    //readin the input
    string in_str;
    input(in_str);

    //breaking the input down  to smaller chunks and saving them in a vector
    partialize(in_str);


    bool ok = true;

    //converting from 60-th base to deicmal
    unsigned long long dec_num = to_decimal(ok);

    //checking if the number fits into a 64-bit number, then  printiong the answer
    print(dec_num,ok);


    return 0;
}
