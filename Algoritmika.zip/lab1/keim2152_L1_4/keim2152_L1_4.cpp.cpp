//KOVACS ELEK - AKOS
//513/1
//LAB1_4
//Sz�m�tsuk ki egy h�romsz�g ter�let�t, ha ismerj�k oldalainak a hossz�t!

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;


//beolvaso fuggveny
void input(double &a, double &b, double &c){

    //Beolvasom a haromszog harom oldalat
    cout << "a = ";
    cin >> a;

    cout << "b = ";
    cin >> b;

    cout << "c = ";
    cin >> c;

}
//kiiratom a teruletet
void print(double T){
    cout <<"A haromszog terulete: " <<setprecision(4)<< T;
}

//heron keplet
double area(double a, double b, double c){
    double p = (a+b+c)/2.0;
    return sqrt(p*(p-a)*(p-b)*(p-c));
}

int main()
{
    double a,b,c;

    input(a,b,c);

    double terulet = area(a,b,c);

    print(terulet);



    return 0;
}
