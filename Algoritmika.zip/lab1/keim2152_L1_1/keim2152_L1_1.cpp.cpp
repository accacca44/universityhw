//KOVACS ELEK - AKOS
//513/1
//LAB1_1
//Hasonlítsuk össze két egész típusú változó cseréjének sebességét három különböző módszerrel:

#include <iostream>
#include <time.h>

using namespace std;


//a ket kicserelni kivant valtozo
int a;
int b;

//a valtozocsere-fuggvenyek idoigenye az osszes lefutasra nezve
double total_time_aux = 0.0;
double total_time_arith = 0.0;
double total_time_xor =  0.0;

//lefutasok szama
int number_of_executions;


//erteket beolvaso fuggveny
void inputFunc(){
    cout <<"A ket valtozo:a,b" << endl;
    cout << "a = ";
    cin >> a;

    cout << "b = ";
    cin >> b;

    cout << "Hanyszor hajtsa vegre a program a valtozok cserejet? (Ajanlott 1millio felett!)" << endl;
    cin >> number_of_executions;
}


//segedvaltozos megoldas
void auxVarFunc(int &x, int &y){


	if(x == y)
		return;

	int temp;
	temp = x;
	x = y;
	y = temp;


}

//osszeadast es kivonast felhasznalo valtozocsere
void addSubtrFunc(int &x, int &y){
	if(x == y)
		return;

	x = x + y;
	y = x - y;
	x = x - y;
}

//xor-csere
void xorFunc(int &x, int &y){
	if(x == y)
		return;

	x ^= y;
    y ^= x;
    x ^= y;
}

//kiirja a megoldasokat
void output(double t_aux, double t_arith, double t_xor){
    cout << t_aux << "sec alatt futott le a segedvaltozos megoldas. " << endl;
    cout << t_arith << "sec alatt futott le az osszeadasos es kivonasos megoldas. " <<endl;
    cout << t_xor<< "sec alatt futott le a xor-t hasznalo megoldas. "  << endl;


}

int main()
{   //idomerok
    clock_t start_timer;
    clock_t stop_timer;

    inputFunc();

    //Egy ciklusban futtatom mind a 3 modszert, s hogy merheto legyen az egyes modszerek lefutasi idejet
    //kulon, osszeadva mentem le
    for(int i = 0; i < number_of_executions; i++){

        start_timer = clock();
        auxVarFunc(a,b);
        stop_timer = clock();
        total_time_aux +=(double)(stop_timer-start_timer) / CLOCKS_PER_SEC;

        start_timer = clock();
        addSubtrFunc(a,b);
        stop_timer = clock();
        total_time_arith +=(double)(stop_timer-start_timer) / CLOCKS_PER_SEC;

        clock_t start_timer = clock();
        xorFunc(a,b);
        clock_t stop_timer = clock();
        total_time_xor +=(double)(stop_timer-start_timer) / CLOCKS_PER_SEC;


    }


    output(total_time_aux,total_time_arith,total_time_xor);


    return 0;
}
