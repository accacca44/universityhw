//KOVACS ELEK - AKOS
//513/1
//LAB1/5
//Számítsuk ki, adott n és x értékekre, a következő összeget:
//S= 1- x2/2! + x4/4! - x6/6! + ... + (-1)n x2n/(2n)!




#include <iostream>
#include <iomanip>
using namespace std;

//beolvasom a sorozat 2 parameteret
void input(int &n, double &x){
    cout << " n = ";cin >> n;
    cout << " x = ";cin >> x;
}

//kiiratom az eredmenyt
void print(double a){
    cout<<setprecision(4)<< a;
}

int paritas(int i){
    if(i % 2 == 0)return 1;
    return -1;
}


int main()
{
    int n;
    double x,S=1;

    input(n,x);

    //i-1.dik tag
    double base = x*x/2;
    double tag;

    S = S-base;

    for(int i = 2; i <= n; i++){
        tag = base * x*x /((2*i)*((2*i)-1));
        S += tag * paritas(i);
        base = tag;
    }



    print(S);
    return 0;
}
