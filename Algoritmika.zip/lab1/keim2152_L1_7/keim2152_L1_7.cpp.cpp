//KOVACS ELEK - AKOS
//513/1
//LAB1_7
//�rjunk algoritmust az ax2 + bx + c = 0 val�s egy�tthat�j� egyenlet megold�s�ra! Az egy�tthat�k 128-bites val�s sz�mok (long double).

#include <iostream>
#include <cmath>

using namespace std;


//Beolvasni az egyenlet egyutthatoit
void input(long double &a, long double &b, long double &c){
    cout << "a = ";cin >> a;
    cout << "b = ";cin >> b;
    cout << "c = ";cin >> c;
}

//Kiszamoljuk az egyenlet deltajat
long double delta(long double a, long double b, long double c){

    return b*b-4*a*c;
}
int main()
{
    long double a,b,c;
    input(a,b,c);

    long double D = delta(a,b,c);


    if(D > 0){
        long double x1 = (-b + sqrt(D)) / (2*a);    //masodfoku egyenlet megoldokeplete
        long double x2 = (-b - sqrt(D)) / (2*a);
        cout << "Megoldasok: " << x1 << ", " << x2;
     }
    if(D == 0){
        cout << "Megoldas: " << -b/2/a;
    }

    if(D < 0){
        cout << "Nincs valos megoldas!" << endl;
    }

    return 0;
}
