//KOVACS ELEK - AKOS
//513/1
//LAB1_6
//Adott három szigorúan pozitív 64-bites valós szám (double): a, b, c. Képezhetik-e ezek a számok egy háromszög oldalait? Ha igen, határozzuk meg és írjuk ki a háromszögbe írt, illetve a háromszög köré írt kör sugarát! Ha nem, írjunk ki megfelelő üzenetet.

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

double r,R;

void input(double &a, double &b, double &c){

    cout << "a = ";cin >> a;
    cout << "b = ";cin >> b;
    cout << "c = ";cin >> c;

}

//Output fuggveny, kiirja a megoldasokat
void print(int answer){
    if(answer == -1){
        cout << "Nem alkothatnak haromszoget!";
    }
    if(answer == 1){
        cout << "A haromszogbe irhato kor sugara:" << r << endl;
        cout << "A haromszog kore irhato kor sugara" << R << endl;}
}

//ellenorzom, hogy letezik e a haromszog
bool is_ok(double a, double b, double c){
    if(a >= b + c)return false;
    if(b >= a + c)return false;
    if(c >= a + b)return false;
    return true;
}

//Kiszamitja a haromszog teruletet a harom oldalbol a Heron-kepletet hasznalva
double heron(double a, double b, double c){
    double p = (a + b + c)/2; //Felkerulet
    return sqrt(p*(p-a)*(p-b)*(p-c));

}

int main()
{
    //deklaralom a 3 oldalt
    double a,b,c;
    input(a,b,c);

    //Ha letezik a haromszog, akkor megkeresem a sugarakat
    if(is_ok(a,b,c)){
        double T = heron(a,b,c);      //Terulet
         r = 2*T/(a+b+c);              //A haromszogbe irt kor sugara
         R = a*b*c/4/T;                //A haromszog kore irt kor sugara

        print(1);
    }
    else{
        print(-1);
    }

    return 0;
}
