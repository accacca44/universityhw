//KOVACS ELEK - AKOS
//513/1
//LAB1_3
//Olvassunk be a billentyűzetről három 64-bites előjeles egész számot. Írjuk ki őket növekvő sorrendben!

#include <iostream>

using namespace std;

//Beolvasas
void input(long long int &x, long long int &y, long long &z){
   cout << "x = ";
   cin >> x;

   cout << "y = ";
   cin >> y;

   cout << "z = ";
   cin >> z;

}

//Kiiratas
void print(long long int x, long long int y, long long z){
    cout << x << ", " << y << ", " << z;
}

int main(){
     long long int x;
     long long int y;
     long long int z;

     input(x,y,z);


    //Feletelek vizsgalata
     if(x > y){
        if(x > z){
            if(y > z)print(z,y,x);
            else print(y,z,x);
        }
        else print(y,x,z);
     }
     else{
        if(y > z){
            if(x > z)print(z,x,y);
            else print(x,z,y);
        }
        else print(x,y,z);

     }

     //print(x,y,z);
}
