//KOVACS ELEK AKOS
//2152/1
//Beszuras Erettsegi feladat

#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream in("input.txt");

    int n,m;
    int a,b;
    bool ok = false;


    int max_a, min_a = -1;
    int b1 = 1000001; int b2 = 1000001;

    in >> n >> m;

    //meghatarozom az a sorozat minimumat es maximumat
    for(int i = 0; i < n; i++){
        in >> a;
        if(i == 0)min_a = a;
        if(i == n-1)max_a = a;


    }

    //vegigmegyek a b sorozaton es hasonlitom paronkent
    for(int i = 0; i < m; i++){
        in >> b;
        b2 = b1;
        b1 = b;

        if(b1 >= max_a && min_a >= b2 && !ok){

            cout << i+1 << endl;
           // cout << b1 << " - " << b2;
            ok = true;
        }

    }
    if(!ok)cout << "NEM";


    return 0;
}
