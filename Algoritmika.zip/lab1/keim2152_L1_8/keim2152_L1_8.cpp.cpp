//KOVACS ELEK - AKOS
//513/1
//LAB1_8
//Számítsuk ki hány szökőév volt/lesz két különböző évszám között! A két évszám előjel nélküli 32-bites egész.


#include <iostream>

using namespace std;

//Input beolvasas
void input(int &elso, int &masodik){
    cout << "elso = "; cin >> elso;
    cout << "masodik = "; cin >> masodik;
}

//Szokoev vizsgalat
bool szokoev(int x){
    if(x % 100 != 0 && x % 4 == 0) return true;
    if(x % 400 == 0) return true;
    return false;

}

void print(int s){
    cout << s << " szokoev" << endl;
}
int main()
{
    int elso;
    int masodik;
    int sum = 0;
    input(elso, masodik);

    //Legegyszerubb megoldas, minden evet megvizsgalok, ha szokoev-e vagy sem.

    for(int i = elso; i <= masodik; i++){
        if(szokoev(i)){
            sum++;
        }
    }
    print(sum);
    return 0;
}
