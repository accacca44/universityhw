//KOVACS ELEK AKOS
//2152
//CSOKIK ERETTSEGI FELADAT

#include <iostream>

using namespace std;

int lkkt(int a, int b){

   int szorzat = a*b;

   while(a!=b){
    if(a > b)a -= b;
    if(a < b)b -= a;
   }
    return szorzat/a;
}

int main()
{
    int n;
    int k;

    cout << "n = ";cin >> n;
    cout << "k = ";cin >> k;

    int kap = lkkt(k,n)/k;
    int nem_kap = n-kap;
    cout << nem_kap;

    return 0;
}
