//KOVACS ELEK - AKOS
//513/1
//LAB1_2
//Hasonlítsuk össze egy ismétlődő ciklus sebességet amely a beolvasott szám gyökeig megy el, háromféleképpen implementalva:


#include <iostream>
#include <cmath>
#include <time.h>

using namespace std;

//olvassuk a bemeneti erteket
void input(unsigned long long int &num){
    cout <<"Az n erteke legyen (ajanlott min. 14 szamjegyu szam):";
    cin >> num;
}


//kiirtato fuggveny
void print(double t1, double t2, double t3){
    cout << t1 << "sec -- i*i <= n" << endl;
    cout << t2 << "sec -- i <= sqrt(n) " << endl;
    cout << t3 << "sec -- sqrt(n) elore lementve" << endl;
}

int main()
{
    clock_t start;
    clock_t stop;

    double t1 = 0.0;
    double t2 = 0.0;
    double t3 = 0.0;

    unsigned long long int n;
    unsigned long long int i;
    input(n);

    //elso modszer
    start = clock();
    i = 1;
    while(i*i <= n){i++;}
    stop = clock();
    t1 = (double)(stop-start) / CLOCKS_PER_SEC;

    //masodik modszer
    start = clock();
    i = 1;
    while(i <= sqrt(n)){i++;}
    stop = clock();
    t2 = (double)(stop-start) / CLOCKS_PER_SEC;

    //harmadik modszer
    unsigned long long int temp = sqrt(n);
    i = 1;
    start = clock();
    while(i < temp){i++;}
    stop = clock();
    t3 = (double)(stop-start) / CLOCKS_PER_SEC;

    //kiiratas
    print(t1,t2,t3);
    return 0;
}
