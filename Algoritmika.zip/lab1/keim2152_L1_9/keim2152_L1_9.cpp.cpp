//KOVACS ELEK - AKOS
//513/1
//LAB1_9
//Sz�m�tsuk ki, h�ny napot �lt�nk a mai nappal bez�r�lag!

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

ifstream in("keim2152_L1_9.txt");

//a honapok maximalis napjait lementem
int ho_max[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30 ,31};



//beolvasom a datumokat egy tombbe
void input(char date[]){
    in >> date;

}


//Megszamolom hany szokoev volt n-evig
int szokoev_count(int year, int month)
{
    if (month <= 2)
        year--;

    //Az ev akor szokoev ha oszthato 4-el, valamint ha 100-al is oszthato
    //akkor 400al is oszthato kell legyen
    return (year / 4) - (year / 100) + (year / 400);
}



void convert(char date[], int &year, int &month, int &day){
    //az ascii tablazatban a karakter es a tenyleges szamjegy kozotti kulombseg
    int aux = '0' - 0;

    year = (date[0]-aux)*1000 + (date[1]-aux)*100 + (date[2]-aux)*10 + (date[3]-aux);
    month = (date[5]-aux)*10 + (date[6]-aux);
    day = (date[8]-aux)*10 + (date[9]-aux);
}



//megszamolja a 0000/00/0 datudomtol hany nap telt el a megadott datumig
int day_count(int year, int month, int day){
    int days_passed = 0;
    days_passed += day;
    days_passed += year*365;
    days_passed += szokoev_count(year,month);

    for(int i = 0; i < month-1; i++){
        //cout << ho_max[i] << " " << year << endl;
        days_passed += ho_max[i];
    }
    return days_passed;
}



void print(long x){
    cout << x << " nap";
}



int main()
{
    //datumok
    char elso[11];
    char masodik[11];


    //beolvasom a datudot
    input(elso);
    input(masodik);

    //a kovetkezo valtozokba konvertalm at a datumot, hogy arithmetikai muveleteket tudja veluk vegezni
    int ev1, ev2;
    int ho1, ho2;
    int nap1, nap2;

    //atvaltom a karaktereket szamokka
    convert(elso,ev1,ho1,nap1);
    convert(masodik,ev2,ho2,nap2);



    long answer = day_count(ev2,ho2,nap2) - day_count(ev1,ho1,nap1);
    print(answer);





    return 0;
}
