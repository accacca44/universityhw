//Kovacs Elek Akos
//513/1
//2152
//Feladat : 8 Egy tolvaj betört egy hentesüzletbe, ahol n áru közül válogat. 
            //Minden árunak ismeri a súlyát és az értékét. Mivel a hátizsákjába legtöbb S súly fér, szeretne úgy válogatni, 
            //hogy a nyeresége maximális legyen. (Ha egy áru nem fér be egészében a hátizsákba, a tolvaj nem vághat le belőle.) 
            //Írj heurisztikus algoritmust, amely javaslatot tesz a tolvajnak!

#include <iostream>
#include <fstream>
#include <vector>
#include <stdlib.h>
#include <algorithm>

using namespace std;

struct Termek
{
    double s;
    double e;
    double arany;
    short regi_pos;
};

void beolvas(int& n, int& suly, vector<Termek>& list)
{
    ifstream in("bemenet08.txt");
    in >> n >> suly;
    for(int i = 0; i < n; i++)
    {
        Termek temp;
        in >> temp.e >> temp.s;
        list.push_back(temp);
    }
}

void aranyok(vector<Termek>& a, int n)
{
    for(int i = 0; i < n; i++)
    {
        a[i].arany = a[i].e / a[i].s;       //kiszamolom az aranyokat
        a[i].regi_pos = i+1;                //lementem a regi poziciot
    }
}

bool comp(Termek a1, Termek a2)
{
    return(a1.arany > a2.arany);
}

void kiir(vector<int> a)
{
    ofstream out("kimenet08.txt");
    //sort(a.begin(), a.end());
    for(int i : a)
        out << i << " ";
}

void hatizsak(vector<Termek> myList, int n, int suly)
{
    vector<int> megoldas;
    int meg_suly = 0;
    for(int i = 0; i < n; i++)
    {
        if(myList[i].s + meg_suly <= suly)
        {
            meg_suly += myList[i].s;
            megoldas.push_back(myList[i].regi_pos);
        }
    }
    kiir(megoldas);
}

int main()
{
    int n = 0;
    int suly = 0;
    vector<Termek> myList;

    beolvas(n,suly,myList);                             //beolvasom a bemeneti adatokat

    aranyok(myList,n);                                  //kiszamolom az ertek/suly aranyokat

    sort(myList.begin(),myList.end(), comp);            //rendezem a listat az aranyok szerint

    hatizsak(myList,n,suly);                            //javaslatot tesz
}