//Kovacs Elek Akos
//513/1
//2152
//Feladat 3 : Legyen két, 32 bites előjeles egész számokat tartalmazó halmaz: 
    //A = {a1, a2, ..., am} és B = {b1, b2, …, bn} (1 <=  m <= n <= 10 000). Határozzuk meg a 
    //B halmaz azon X = {x1, x2, …, xm} részhalmazát, amelynek megfelelően az E = a1x1 + a2x2 + … + 
    //amxm kifejezés értéke a lehető legnagyobb. A bemenet szerkezete: m értéke, A elemei, n értéke, 
    //B elemei. A kimenet a maximális értéket kell tartalmazza.

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

//eredmeny kiiratas
void kiir(long long e)
{
    ofstream out("kimenet03.txt");
    out << e;
    out.close();
}

//beolvasom a bemeneti adatokat
void beolvas(int& m, int& n, vector<int>& a, vector<int>& b)
{
    ifstream in("bemenet03.txt");
    in >> m;
    for (int i = 0; i < m; i++)
    {
        int temp;
        in >> temp;
        a.push_back(temp);
    }
    in >> n;
    for (int i = 0; i < n; i++)
    {
        int temp;
        in >> temp;
        b.push_back(temp);
    }
    in.close();
}

int getMax(vector<int>a)
{   
    if (a.size() == 0)
    {
        return 0;
    }
    int maxi = a[0];
    for (int i : a)
    {
        if (i > maxi)maxi = i;
    }
    return maxi;
}

void counting_sort(vector<int>& a, int n, int szj)
{
    //a szamok 1 es k kozott lehetnek
    int k = 10;
    vector<unsigned long long> darab(k, 0);
    vector<unsigned long long> b(n, 0);
    for (int i = 0; i < n; i++)
    {
        darab[(a[i] / szj) % 10]++;
    }

    for (int i = 1; i < k; i++)
    {
        darab[i] += darab[i - 1];
    }

    for (int i = n - 1; i >= 0; i--)
    {

        darab[(a[i] / szj) % 10]--;
        b[darab[(a[i] / szj) % 10]] = a[i];
    }

    for (int i = 0; i < n; i++)
    {
        a[i] = b[i];
    }

}

void radix_sort(vector<int>& a, int n)
{
    int mx = getMax(a);

    for (int i = 1; mx / i > 0; i++)
    {
        counting_sort(a, n, i);
    }
}

//rendezem a ket halmazt
void sort(vector<int>& a, int n)
{
    //kulonvalogatom a negativakat es a pozitivakat
    vector<int> negativak;
    vector<int> pozitivak;
    for (int i : a)
        if (i < 0)
            negativak.push_back(-i);
        else
            pozitivak.push_back(i);

    radix_sort(negativak, negativak.size());                 //rendezem a negativ elemu tombot kulon
    radix_sort(pozitivak, pozitivak.size());                 //remdezem a pozitiv elemu tombot kulon

    int  index = 0;
    for (auto i : negativak)
    {
        a[negativak.size() - 1 - index] = -i;               //a negativ elemek pozitivak lettek, igy a forditott sorrenben 
        index++;                                            //es negativ elojellel illesztem oket be
    }
    for (auto i : pozitivak)
    {
        a[index] = i;
        index++;
    }
}

//kiszamitom a legnagyobb osszeget
long long int E(vector<int> a, int m, vector<int>b, int n)
{
    short index_a = m - 1;
    short index_b = n - 1;
    long long int sum = 0;

    for (int i = 0; i < m; i++)
    {
        if (a[index_a] > -1 && b[index_b] > -1)
        {
            sum += (a[index_a]) * (b[index_b]);
            //cout << a[index_a] << "*" << b[index_b] << endl; 
            index_a--;
            index_b--;
            if (index_a < 0 || index_b < 0)
                return  sum;
            if (a[index_a] < 0 || b[index_b] < 0)
            {
                index_a = 0;
                index_b = 0;
            }
        }
        else
        {
            sum += (a[index_a]) * (b[index_b]);
            //cout << a[index_a] << "*" << b[index_b] << endl; 
            index_a++;
            index_b++;
        }
    }
    return sum;
}

int main()
{
    vector<int> a;
    vector<int> b;
    int m = 0;
    int n = 0;

    beolvas(m, n, a, b);

    sort(a, m);                  //rendezem a tomboket
    sort(b, n);


    //szamolom az E erteket
    long long e = E(a, m, b, n);
    kiir(e);



}