//Kovacs Elek Akos
//513/1
//2152
/*Feladat  2 :  Adott egy nxm-es mátrix. Határozzuk meg azt a legnagyobb n elemű összeget, amelyet úgy kapunk meg, 
                hogy minden elem a mátrix különböző soraiból "származik" és az i. sorból kiválasztott elem kisebb mint az i+1. 
                sorból kiválasztott elem. Ha nem létezik megoldás, írjunk ki megfelelő üzenetet.*/


#include <iostream>
#include <vector>
#include <fstream>
#define INT_MAX 2147483647
#define INT_MIN -2147483648

using namespace std;

void beolvas(vector<vector<int>>& a, int& n, int& m)
{
    ifstream in("bemenet02.txt");
    in >> n >> m;
    
    for(int i = 0; i < n; i++)
    {
        vector<int> sor;
        for(int j = 0; j < m; j++)
        {
            int temp;
            in >> temp;
            sor.push_back(temp);
        }
        a.push_back(sor);
    }
    in.close();
}

void kiir(long long x,bool volt)
{
    ofstream out("kimenet02.txt");
    if(volt)
        out << x;
    else
        out << "Nincs ilyen megoldas!";
    out.close();
}

long long osszeg(vector<vector<int>> a, int n, int m, bool& volt)
{
    int sum = 0;
    int prevmax = INT_MAX;
    for(int i = n-1; i >= 0; i--)
    {
        int maxi = INT_MIN;
        for(int j = 0; j < m; j++)
        {
            if(maxi < a[i][j] && a[i][j] < prevmax)
            {
                maxi = a[i][j];
            }
        }
        //cout << maxi << endl;
        if(maxi == -1)
        {
            volt = false;
        }
        prevmax = maxi;
        sum += maxi;
    }
    return sum;
}

int main()
{
    vector<vector<int>> a;
    int n;
    int m;
    bool volt = true;

    beolvas(a,n,m);

    long long sum = osszeg(a,n,m,volt);
    kiir(sum,volt);

    return 0;
}