//Kovacs Elek Akos
//513/1
//2152
//Feladat 6 : Állapítsuk meg egy adott nem irányított összefüggő gráf minimális feszítőfáját! 
            //A bemenet első sora a csúcsok n és az élek m számát tartalmazza. A következő m sor mindegyike három számot tartalmaz, 
            //egy-egy él végpontjait és költségét. A kimenet tartalmazza a minimális feszítőfa összköltségét.

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct El
{
    int start;
    int stop;
    int weight;
};

void beolvas(int& n, int& m, vector<El>& graf)
{
    ifstream in("bemenet06.txt");
    in >> n >> m;
    graf.resize(m);

    //beovlasom az eleket
    for(int i = 0; i < m; i++)
    {
        in >> graf[i].start >> graf[i].stop >> graf[i].weight;   
    }
}

void init(vector<int>& comp, int n)
{
    for(int i = 0; i <= n; i++)
    {
        comp.push_back(i);
    }
}

int getMax(vector<El>a)
{   
    if (a.size() == 0)
    {
        return 0;
    }
    int maxi = a[0].weight;
    for(El i : a)
    {
        if(i.weight > maxi)maxi = i.weight;
    }
    return maxi;
}

void counting_sort(vector<El> &a, int n, int szj)
{    
    //a szamok 1 es k kozott lehetnek
    int k = 10;
    vector<unsigned long long> darab(k,0);
    vector<El> b(n);
    for(int i = 0; i < n; i++)
    {
        darab[(a[i].weight/szj)%10]++;
    }

   for(int i = 1; i < k; i++)
   {
       darab[i]+=darab[i-1];
   }

    for(int i = n-1; i >=0; i--)
    {
        
        darab[(a[i].weight/szj)%10]--;
        b[darab[(a[i].weight/szj)%10]] = a[i];
    }

    for(int i = 0; i < n; i++)
    {
        a[i] = b[i];
    }

}

void radix_sort(vector<El>&a, int n)
{
    int mx = getMax(a);

    for(int i = 1; mx/i > 0; i++)
    {
        counting_sort(a,n,i);
    }
}

int kruskal(int n, int m, vector<El> graf, vector<int> comp)
{
    int sum = 0;
    int j = 0;
    int i = 0;
    while(j < m && i < n-1)
    {
        if(comp[graf[j].start != comp[graf[j].stop]])
        {
            i++;
            sum += graf[j].weight;
            int id = comp[graf[j].stop];
            for(int k = 0; k < n; k++)
            {
                if(comp[k] == id)
                {
                    comp[k] = comp[graf[j].start];
                }
            }
        }
        j++;
    }

    return sum;
}

void kiir(int x)
{
    ofstream out("kimenet06.txt");
    out << x;
}

int main()
{
    int n;
    int m;
    vector<El> graf;
    vector<int> comp;

    //beolvasom az eleket
    beolvas(n,m,graf);
    //inicializaom a komponens tombot
    init(comp,n);
    //rendezem a az eleket a tavolsag szerint
    radix_sort(graf,m); 

    int sum = kruskal(n,m,graf,comp);
    kiir(sum);
    return 0;
}