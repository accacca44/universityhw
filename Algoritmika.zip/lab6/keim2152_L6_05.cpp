//Kovacs Elek Akos
//513/1
//2152
//Feladat 5 : Adva van n + 1 cipősdoboz és n pár cipő, amelyek meg vannak számozva 1-től n-ig (1 <= n <= 10 000). 
            //Az n pár cipő n+1 dobozban található, a dobozok közül az egyik üres. El kell rendezni a cipőket úgy, hogy minden 
            //cipő a saját dobozába kerüljön. Munka közben csak egy pár cipőt szabad kivenni a dobozból, amelyben található, és 
            //azonnal be kell tenni az üres dobozba. Állapítsuk meg a költöztetések sorozatát minimális számú művelettel. 
            //A bemenet első sora a cipők számát tartalmazza. Ezután következik a jelenlegi elrendezés, a 0 jelöli az üres dobozt. 
            //A kimenet a rendezéshez szükséges minimális lépésszámot kell hogy tartalmazza. 

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void beolvas(vector<int>& a, int& n)
{
    ifstream in("bemenet05.txt");
    in >> n;

    a.push_back(n + 1);

    for (int i = 0; i <= n; i++)
    {
        int temp;
        in >> temp;
        a.push_back(temp);
    }
 
}

void kiir_perm(vector<int> a)
{
    int n = a.size();
    for (int i = 0; i < n; i++)
        cout << i << " ";
    cout << endl;

    for (int i : a)
        cout << i << " ";
    cout << endl;
    cout << endl;
}

void kiir(int x)
{
    ofstream out("kimenet05.txt");
    out << x;
}

int sim(vector<int> tomb, int n)
{
    int db = 0;
    vector<int> inverz(n+2);

    for (int i = 0; i < n+2; i++)
    {
        inverz[tomb[i]] = i;
    }

    vector<int> solution(n + 2);
    for (int i = 0; i < solution.size(); i++)
        solution[i] = i;
    solution[0] = n + 1;
    solution[n + 1] = 0;

    while (tomb != solution)
    {
        if (tomb[n + 1] == 0)
        {
            int aux = 1;
            while (tomb[aux] == aux)
                aux++;
            swap(tomb[aux], tomb[n + 1]);
            inverz[0] = aux;
            inverz[tomb[n + 1]] = n + 1;
            db++;
        }
        else
        {
            int pos_zero = inverz[0];
            int next_pos = inverz[pos_zero];
            swap(tomb[pos_zero], tomb[next_pos]);

            inverz[0] = next_pos;
            inverz[pos_zero] = pos_zero;

            db++;
        }
        //kiir_perm(tomb);
    }

    return db;
}

int main()
{
    int n;          //cipok szama
    vector<int> a;  //ciposdobozok szama

    beolvas(a, n);

    int lepes = sim(a, n);
    kiir(lepes);
}