//Kovacs Elek Akos
//513/1
//2152
//Feladat 1 : Adott n zeneszámot tartalmazó állomány hossza. Ezeket az állományokat ugyanazon a mágnes szalagon 
            //szeretnénk tárolni. Állapítsuk meg az állományok optimális elrendezését a szalagon ahhoz, hogy az átlagos elérési 
            //idő a lehető legkisebb legyen. A bemenet első sora a zeneszámok számát és azok hosszát tartalmazza. 
            //A kimenet az állományok optimális elrendezését tartalmazza.  

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct Zene
{
    int len;
    int prev_pos;
};

void beolvas(int& n, vector<Zene>& a)
{
    ifstream in("bemenet01.txt");
    in >> n;
    for(int i = 0;i < n; i++)
    {
        Zene temp;
        in >> temp.len;
        temp.prev_pos = i+1;
        a.push_back(temp);
    }
    in.close();
}

int getMax(vector<Zene>a)
{   
    if (a.size() == 0)
    {
        return 0;
    }
    int maxi = a[0].len;
    for(Zene i : a)
    {
        if(i.len > maxi)maxi = i.len;
    }
    return maxi;
}

void counting_sort(vector<Zene> &a, int n, int szj)
{    
    //a szamok 1 es k kozott lehetnek
    int k = 10;
    vector<unsigned long long> darab(k,0);
    vector<Zene> b(n);
    for(int i = 0; i < n; i++)
    {
        darab[(a[i].len/szj)%10]++;
    }

   for(int i = 1; i < k; i++)
   {
       darab[i]+=darab[i-1];
   }

    for(int i = n-1; i >=0; i--)
    {
        
        darab[(a[i].len/szj)%10]--;
        b[darab[(a[i].len/szj)%10]] = a[i];
    }

    for(int i = 0; i < n; i++)
    {
        a[i] = b[i];
    }

}

void radix_sort(vector<Zene>&a, int n)
{
    int mx = getMax(a);

    for(int i = 1; mx/i > 0; i++)
    {
        counting_sort(a,n,i);
    }
}

void kiir(vector<Zene> a, int n)
{
    ofstream out("kimenet01.txt");
    for(Zene x : a)
        out  << x.prev_pos << " ";
    out.close();
}

int main()
{
    vector<Zene> a;
    int n;
    
    beolvas(n,a);

    radix_sort(a,n);

    kiir(a,n);

}
