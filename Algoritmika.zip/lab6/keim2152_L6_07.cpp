//Kovacs Elek Akos
//513/1
//2152
//Feladat 7 : Költözik a múzeum. A tárgyakat kocka alakú, különböző méretű  ládákba csomagolták. 
            //Kicsomagoláskor több személy dolgozik egyidőben. A rendetlenség elkerülése végett, azokba a helyiségekbe, 
            //ahol a kicsomagolás folyik felszereltek egy futószalagot, amelyre az üres ládákat helyezik, a nyitott felükkel 
            //felfele. A futószalag végéhez egy gyereket állítottak, akinek az a feladata, hogy összeszedje a ládákat és úgy 
            //helyezze egyiket a másikba, (ha lehetséges), hogy végül a ládacsomagok száma a lehető legkisebb legyen.

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void beolvas(int& n, vector<int>& a)
{
    ifstream in("bemenet07.txt");
    in >> n;
    for (int i = 0; i < n; i++)
    {
        int temp;
        in >> temp;
        a.push_back(temp);
    }
    in.close();
}

//visszateriti a keresett ertekhez legkozelebbi legnagyobb erteket
int bin_search(vector<int> a, int n, int target)
{
    if (a.size() == 0)return -1;

    int kezdo = 0;
    int veg = n - 1;
    while (kezdo < veg)
    {
        int mid = (kezdo + veg) / 2;
        if (target == a[kezdo])return kezdo + 1;
        if (target == a[mid])return mid + 1;
        if (target < a[mid])veg = mid;
        if (target > a[mid])kezdo = mid + 1;
    }
    if (target < a[kezdo])
    {
        return kezdo;
    }
    return veg;
}

void kiir(vector<vector<int>> a)
{
    ofstream out("kimenet07.txt");
    out << a.size() << endl;
    for(int i =  0; i < a.size(); i++)
    { 
        for (int x : a[i])
        {
            out << x << " ";
        }
        out << endl;
    }
    out.close();
}

void ladak(vector<int> a, int n)
{
    vector<vector<int>> csomag;

    //veszek minden csomagot
    for (int box = 0; box < n; box++)
    {   
        //kivalogatom az legutolso dobozokat
        vector<int> utolso;
        for (int i = 0; i < csomag.size(); i++)
        {
            utolso.push_back(csomag[i][csomag[i].size() - 1]);
        }
        //megkeresem a kovetkezo ladasor pozitciojat    
        int pos = bin_search(utolso, utolso.size(), a[box]);

        //ha nem letezik egy kedvezo eset akkor uj ladasort hozunk letre
        if (pos == -1 || a[box] >= utolso[utolso.size()-1])
        {
            vector<int> newvec;
            newvec.push_back(a[box]);
            csomag.push_back(newvec);
        }
        //ha letezik egy ilyen ladasor akkor hozzaillesztjuk a ladankat
        else
        {
            csomag[pos].push_back(a[box]);
        }
    }
    //kiirjuk a ladasorok vegso allapotat
    kiir(csomag);
}

int main()
{
    int n; //ladak szama
    vector<int> a;

    //beolvasom az adatokat
    beolvas(n, a);
    
    //csomagolom a ladakat
    ladak(a, n);
    


}