//Kovacs Elek Akos
//513/1
//2152
//Feladat 4 : A kolozsvári színház műsorában n előadás szerepel 
            /*(1 <= n <= 10 000). Mindenik esetében ismert a kezdés időpontja, valamint az előadás végének pontos ideje. 
              Egy különleges vendég kedvéért a színház be szeretné mutatni egyetlen nap folyamán minden előadását. 
              Mivel csak egy színhely áll rendelkezésre, állapítsuk meg azt a maximális számú színdarabot, amelyeket a 
              színház bemutathat anélkül, hogy az eredeti kezdési és zárási időpontokat változtatnák.*/

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct Eloadas{
    int start;
    int end;
};

int getMax(vector<Eloadas>a)
{
    if (a.size() == 0)
    {
        return 0;
    }
    int maxi = a[0].end;
    for(Eloadas i : a)
    {
        if(i.end > maxi)maxi = i.end;
    }
    return maxi;
}

void counting_sort(vector<Eloadas> &a, int n, int szj)
{    
    //a szamok 1 es k kozott lehetnek
    int k = 10;
    vector<unsigned long long> darab(k,0);
    vector<Eloadas> b(n);
    for(int i = 0; i < n; i++)
    {
        darab[((a[i].end)/szj)%10]++;
    }

   for(int i = 1; i < k; i++)
   {
       darab[i]+=darab[i-1];
   }

    for(int i = n-1; i >=0; i--)
    {
        
        darab[((a[i].end)/szj)%10]--;
        b[darab[((a[i].end)/szj)%10]] = a[i];
    }

    for(int i = 0; i < n; i++)
    {
        a[i] = b[i];
    }

}

void radix_sort(vector<Eloadas>&a, int n)
{
    int mx = getMax(a);

    for(int i = 1; mx/i > 0; i++)
    {
        counting_sort(a,n,i);
    }
}

void kiir(int a)
{
    ofstream out("kimenet04.txt");
    out << a;
    out.close();
}

void beolvas(vector<Eloadas>& a)
{
    ifstream in("bemenet04.txt");
    int n = 0;
    int ora = 0;
    int perc = 0;
    char kettospont;

    in >> n;
    for(int i = 0; i < n; i++)
    {
        Eloadas temp;
        //beolvas kezdesi ido
        in >> ora >> kettospont >> perc;
        temp.start = ora*60 + perc;
    
        //beolvas befejezesi ido
        in >> ora >> kettospont >> perc;
        temp.end = ora*60 + perc;

        //beillesztem a segedvaltozot a megoldasba
        a.push_back(temp);
    }
    in.close();
}

int megtart(vector<Eloadas>a)
{
    int n = a.size();
    int db = 1;
    int prev_eloadas = a[0].end;

    //az elso eloadast biztos meg tudjuk tartani
    int i = 1;
    while(i < n)
    {
        if(prev_eloadas <= a[i].start)
        {
            db++;
            prev_eloadas = a[i].end;
        }
        i++;
    }

    return db;
}

int main()
{
    vector<Eloadas> a;          //beolvasom az eloadasok idopontjait
    beolvas(a);                 
    radix_sort(a,a.size());     //rendezem a befejezesi ido szerint novekvo sorrendben

    int db = megtart(a);        //a megtart fuggveny meghatarozza es visszateritti a legtobb lehetseges eloadast
    kiir(db);
    return 0;
}