#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(vector<int>&a)
{
    ifstream in("input.txt");
    int temp;
    while(in >> temp)
        a.push_back(temp);
}

void lassu_sort(vector<int>&a, int n)
{
    for(int i = 0; i < n; i++){
        for(int j = i+1; j < n; j++)
        {
            if(a[i] > a[j])
            {
                swap(a[i],a[j]);
            }
        }
    }
}

int getMax(vector<int>a)
{   
    if (a.size() == 0)
    {
        return 0;
    }
    int maxi = a[0];
    for(int i : a)
    {
        if(i > maxi)maxi = i;
    }
    return maxi;
}

void counting_sort(vector<int> &a, int n, int szj)
{    
    //a szamok 1 es k kozott lehetnek
    int k = 10;
    vector<unsigned long long> darab(k,0);
    vector<unsigned long long> b(n,0);
    for(int i = 0; i < n; i++)
    {
        darab[(a[i]/szj)%10]++;
    }

   for(int i = 1; i < k; i++)
   {
       darab[i]+=darab[i-1];
   }

    for(int i = n-1; i >=0; i--)
    {
        
        darab[(a[i]/szj)%10]--;
        b[darab[(a[i]/szj)%10]] = a[i];
    }

    for(int i = 0; i < n; i++)
    {
        a[i] = b[i];
    }

}

void radix_sort(vector<int>&a, int n)
{
    int mx = getMax(a);

    for(int i = 1; mx/i > 0; i++)
    {
        counting_sort(a,n,i);
    }
}

int main()
{   
    ofstream out("output.txt");
    vector<int>a;
    beolvas(a);
    radix_sort(a,a.size());

    for(int i : a)
        cout << i << endl;
}