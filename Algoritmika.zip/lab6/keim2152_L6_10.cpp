//Kovacs Elek Akos
//513/1
//2152
/*Feladat : 10   Az állami kincstárba n (n <= 2000) zsákban hozzák a pénzérméket. A raktár főnöke ismeri minden 
                    zsák tartalmát (az érmék számát) és át szeretné rendezni minden zsák tartalmát az érmék költöztetésével úgy,
                    hogy végül minden zsákban azonos számú érme legyen. Írjunk heurisztikus algoritmust, amely segít a főnöknek, 
                    hogy, amennyiben ez lehetséges a legkevesebb költöztetéssel érje el a célját! Ha nincs megoldás, írjunk ki egy 
                    megfelelő üzenetet!*/

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ofstream out("kimenet10.txt");

//strukturaban tarolom a regi poziciot es az erteket
struct Zsak
{
    int position;
    int ertek;
};

//beolvasom a bemeneti adatokat
void beolvas(vector<Zsak>& zsak, int& n)
{
	ifstream in("bemenet10.txt");
	in >> n;
	zsak.resize(n);
    for (int i = 0; i < n; i++)
    {
        in >> zsak[i].ertek;
        zsak[i].position = i + 1;
    }
    in.close();
}

//legynagyobb szamot hatarozza meg a radixsorthoz
int getMax(vector<Zsak>a)
{
    if (a.size() == 0)
    {
        return 0;
    }
    int maxi = a[0].ertek;
    for (Zsak i : a)
    {
        if (i.ertek > maxi)maxi = i.ertek;
    }
    return maxi;
}

void counting_sort(vector<Zsak>& a, int n, int szj)
{
    //a szamok 1 es k kozott lehetnek
    int k = 10;
    vector<unsigned long long> darab(k, 0);
    vector<Zsak> b(n);
    for (int i = 0; i < n; i++)
    {
        darab[(a[i].ertek / szj) % 10]++;
    }

    for (int i = 1; i < k; i++)
    {
        darab[i] += darab[i - 1];
    }

    for (int i = n - 1; i >= 0; i--)
    {

        darab[(a[i].ertek / szj) % 10]--;
        b[darab[(a[i].ertek / szj) % 10]] = a[i];
    }

    for (int i = 0; i < n; i++)
    {
        a[i] = b[i];
    }

}

void radix_sort(vector<Zsak>& a, int n)
{
    int mx = getMax(a);

    for (int i = 1; mx / i > 0; i++)
    {
        counting_sort(a, n, i);
    }
}

//binaris kereses
int bin_search(vector<Zsak>& a, int n, int target)
{
    radix_sort(a, n);
    int start = 0;
    int end = n - 1;
    int mid = -1;
    while (start <= end)
    {
        mid = (start + end) / 2;

        if (a[mid].ertek == target)return mid;
        if (a[mid].ertek > target)end = mid - 1;
        if (a[mid].ertek < target)start = mid + 1;
    }
    return -1;
}

//eredmeny lementes
void save(vector<Zsak> zsak, int p1, int p2, int x, bool b,vector<int>& megoldas)
{
    int m1;
    int m2;

    if (zsak[p1].ertek > zsak[p2].ertek)
    {
        m1 = p1;
        m2 = p2;
    }
    else
    {
        m1 = p2;
        m2 = p1;
    }
    
    int s = abs(x - zsak[p2].ertek);

    //b az a kiiratasi mod
    if (b)
    {
        megoldas.push_back(zsak[m1].position);
        megoldas.push_back(zsak[m2].position);
        megoldas.push_back(s);
    }
    else
    {
        megoldas.push_back(zsak[m1].position);
        megoldas.push_back(zsak[m2].position);
        megoldas.push_back(x);
    }
        
}

void kiir(vector<int> megoldas, int cnt)
{
    out << cnt;
    for (int i = 0; i < megoldas.size(); i++)
    {
        if (i % 3 == 0)
            out << endl;
        out << megoldas[i] << " ";
    }
}

void rendez(vector<Zsak> zsak, int n, int avg)
{

    int cnt = 0;            //lepes szamlalo
    vector<int>megoldas;    //megoldas tomb
    //azokat az elemekkel egybol lehet 2 zsakot letrehozni eloszor vegzem el
    int k = 0;
    while(k < n)
    {
        //megnezem hogy letezik e a zsak parja
        int leftover = 2*avg - zsak[k].ertek;
        int pos = bin_search(zsak, n, leftover);
        if (pos != -1 && leftover != 9)
        {
            save(zsak, k, pos, avg,1,megoldas);
            zsak[pos].ertek = zsak[k].ertek = avg;
            cnt++;
            k--;
        }
        k++;
    }

    //a maradek zsakokbol csak addig rakom at a penzt ameddig ki nem adjak az atlagot
    int i = n - 1;      //a vegerol indulok ahol a nagyobb szamok vannak
    int j = 0;          //az elejerol indulok ahol a kisebb szamok vannak
    while (j < i)
    {
        while (zsak[i].ertek > avg)
        {
            if (zsak[j].ertek < avg)
            {
                int lefti = abs(avg - zsak[i].ertek);
                int leftj = abs(avg - zsak[j].ertek);
                int left = min(lefti, leftj);
                cnt++;

                save(zsak, i, j, left, 0,megoldas);
            
                zsak[j].ertek += left;
                zsak[i].ertek -= left;
            }
            else if(zsak[j].ertek == avg)
            {
                j++;
            }
        }
        i--;
    }
    kiir(megoldas, cnt);
}

double atlag(vector<Zsak> zsak, int n)
{
    double sum = 0;
    double cnt = n;

    for (Zsak i : zsak)
    {
        sum += i.ertek;
    }
    return double(sum / cnt);
}

int main()
{
	int n;
	vector<Zsak> zsak;

	beolvas(zsak, n);
    
    double avg = atlag(zsak, n);

    //helyes input eseten
    if (avg == int(avg))
    {
        //rendez novekvo sorrendbe
        radix_sort(zsak, n);

        rendez(zsak, n, int(avg));
    }
    //hibas input eseten
    else
    {
        out << "Hiba";
    }
    out.close();
    return 0;

}