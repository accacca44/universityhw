//Kovacs Elek Akos
//513/1
//2152
/*Feladat : 9   Az egyetem kapott n számítógépet, amelyeket különböző épületekbe és termekbe fognak elhelyezni 
                úgy, hogy a számítógépek egy lineáris hálózatot alkossanak: minden számítógép két másikkal lesz összekötve, 
                kivéve az elsőt és az utolsót, amelyek csak egy-egy számítógéppel lesznek összekötve. Írjunk heurisztikus 
                algoritmust, amely megállapít egy hálózatot úgy, hogy minél kevesebb kábelre legyen szükség!*/

#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>

using namespace std;

struct Node
{
    int x;
    int y;
    int pos;
};

void beolvas(int& n, vector<Node>& pc)
{
    ifstream in("bemenet09.txt");
    in >> n;
    for(int i = 0; i < n; i++)
    {
        Node temp;
        in >> temp.x >> temp.y;
        temp.pos = i;
        pc.push_back(temp);
    }
    in.close();
}

void initMatrix(vector<vector<double>> m, int n)
{
    vector<double> temp(n,0);
    for(int i = 0; i < n; i++)
        m.push_back(temp);

    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j< n; j++)
            cout << m[i][j] << " ";
        cout << endl;
    }
}

double  calcDist(Node n1, Node n2)
{
    double X = n1.x - n2.x;
    double Y = n1.y - n2.y;
    Y *= Y;
    X *= X;
    return sqrt(X + Y);
}

void setDist(int n, vector<Node> pc, vector<vector<double>>& m)
{
    for(int i = 0; i < n - 1; i++)
    {
        for(int j = i + 1; j < n; i++){
            double d = calcDist(pc[i],pc[j]);
            m[pc[i].pos][pc[j].pos] = d;
            m[pc[j].pos][pc[i].pos] = d;
        }
    }
}

int main()
{
    int n;
    vector<Node> pc;

    beolvas(n,pc);

    vector<vector<double>> m;
    initMatrix(m,n);

    setDist(n,pc,m);
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j< n; j++)
            cout << m[i][j] << " ";
        cout << endl;
    }
    
}