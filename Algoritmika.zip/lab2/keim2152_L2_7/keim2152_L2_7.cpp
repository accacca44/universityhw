//Kovacs Elek Akos
//513/1
//2152
//Feladat:Adottak az elsőéves egyetemisták névsorai (abc sorrendben), csoportonként. 
//Állítsunk elő ezekből egyetlen névsort, mely szintén abc sorrendben van! Legtöbb 10 csoport lehet és egy 
//csoportban nem lesz több, mint 100 diák. Egy diák neve legtöbb 100 karakterből áll.

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

void print_vec(vector<string>v){
    ofstream out("output.txt");
    for(int i =0; i < v.size();i++)out << v[i] << endl;
}


void beolvas_nevsor(vector<string>&v, int &n, int &m, vector<int>&h){
    ifstream in("input.txt");
    string aux = "";
    h.push_back(0);
    in >> n;

    for(int i = 0; i < n; i++){
        in >> m;
        h.push_back(m+h[i]);
        for(int j = 0; j <= m; j++){
        getline(in,aux);
        if(aux != "")
            v.push_back(aux);
        }
    }
}


//igazat terit vissza ha x hamarabb jelenik meg a nevsorban
bool compare(string x, string y)
{
    string a = x;
    string b = y;

    if(a == b)return 1;

    int i = 0;
    int j = 0;

    while(a[i] == b[i]){
        //if(a[i] == ' ')i++;
        //if(b[i] == ' ')j++;
        i++;
        j++;
    }
    if(a[i] < b[j])return 1;
    return 0;

}

//osszefuzom a 2 reszt,de mindig 0tol kezdem, es igy csak a 2 sorozat vegere mutato indexre van szuksegem
void osszefesul(vector<string> &v, int stop1, int stop2)
{
    int start = 0;


    int start1 = 0;
    int start2 = stop1;

    while(start1 < stop1 && start2 < stop2){
        start++;

        if(compare(v[start1],v[start2])){
            v[start] = v[start1];
            start1++;
        }
        else{
            v[start] = v[start2];
            start2++;
        }
    }


    while(start1 < stop1){
        start++;
        v[start] = v[start1];
        start1++;
    }
    while(start2 < stop1){
        start++;
        v[start] = v[start2];
        start2++;
    }




}


void drive(vector<string>v, int n, vector<int> s){
    //ELSO MODSZER : NEGYZETES MEGOLDAS

    for(int i = 0; i < n-1; i++){
        for(int j = i+1; j <= n-1; j++){
            cout << v[i] << " -- " << v[j]<< " ::"<<compare(v[i],v[j]) <<endl;
            if(!compare(v[i],v[j])){
                string aux = v[i];
                v[i] = v[j];
                v[j] = aux;
            }
        }
    }

    /*//MASODIK MODSZER : TOBBSZOROS OSSZEFUZES
    for(int i = 0; i < n-1; i++){
        osszefesul(v,s[i+1],s[i+2]);
    }
*/

    print_vec(v);
}

int main()
{

    int csoport_szam = 0;
    int csoport_meret = 0;
    vector<string> nevek;
    vector<int> csop_hossz;

    beolvas_nevsor(nevek,csoport_szam,csoport_meret,csop_hossz);

    int n = nevek.size();

    drive(nevek,n,csop_hossz);



    return 0;
}
