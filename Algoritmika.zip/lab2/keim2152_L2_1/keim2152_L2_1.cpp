//KOVACS ELEK - AKOS
//513/1
//LAB2_1
//Állapítsuk meg, hogy egy adott nevű tanuló az első három díjazott között van-e?


#include <iostream>
#include <fstream>
#include <string>

using namespace std;

//the students' data
struct Stud{
    int ID;
    double mark;
    string first_name;
    string last_name;

};

//reading the input data
void input(int &n, Stud studs[], string &str1, string &str2){

    ifstream in("keim2152_L2_1.txt");

    in >> n;
    for(int i = 0; i < n; i++){
        in >> studs[i].first_name >> studs[i].last_name >> studs[i].mark;
        studs[i].ID = i;
    }
    in >> str1 >> str2;
    in.close();
}

bool in_top_three(int n, Stud s[], string s1, string s2){

    //Keresem a 3 maximumot, ezzel egyszer atmegyek a tombon,
    //majd azt vizsgalom, ha a legnagyobb haromba benne van-e a keresett diak
    double max1 = -1, max2 = -1, max3 = -1;
    double toFind_note;
    bool ok = false;

    //max1 - legnagyobb, max3-legkissebb
    for(int i = 0; i < n; i++){
        //finding the students grade
        if(s[i].first_name == s1 && s[i].last_name == s2 && !ok){

            toFind_note = s[i].mark;
            ok = true;

        }


        if(s[i].mark > max3){
            if(s[i].mark > max2){
                if(s[i].mark > max1){
                    max3 = max2;
                    max2 = max1;
                    max1 = s[i].mark;
                }
                else{
                    max3 = max2;
                    max2 = s[i].mark;
                }
            }
            else{
                max3 = s[i].mark;
            }
        }
    }
    //cout << toFind_note << endl;
    //cout << max1 << " " << max2 << " " << max3;
    if(toFind_note == max1)return true;
    if(toFind_note == max2)return true;
    if(toFind_note == max3)return true;

    return false;


}

void print(bool b){
    if(b)cout <<"igen";
    else cout <<"nem" ;

}

int main()
{

    //number of students
    int n;
    Stud studs[100];

    string toFind_first_name;
    string toFind_last_name;

    //reads from the file
    input(n, studs, toFind_first_name, toFind_last_name);

    //gets the top 3 students of the class
    bool b = in_top_three(n,studs,toFind_first_name,toFind_last_name);

    //prints the answer
    print(b);







    return 0;
}
