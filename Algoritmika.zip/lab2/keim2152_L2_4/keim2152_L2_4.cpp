//Nev:Kovacs Elek Akos
//Csoport: 513/1
//NR. Matricol: 2152
//Feladat:Adott egy csoport év végi vizsgajegyeinek listája. Töröljük ki az 5-ösnél kisebb jegyeket a listából.
 //(A végső listában a jegyek sorrendje nem lényeges). A módósítást a beolvasott tömbben kell elvégezni, nem elég 
 //csak kiiratni az eredményt. A jegyek double típusú valós számok. Legtöbb 1 000 000 jegy lehet.


#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void input(vector<double> &v,int &n){
    ifstream in("keim2152_L2_4.txt");

    in >> n;
    double a;
    while(in >> a)v.push_back(a);
}

//Kicserel ket erteket
/*void swap_Func(double &a, double &b){
    double temp;
    temp = a;
    a = b;
    b = temp;
}*/

void print(vector<double> v, int n){
    //cout << n << endl;
    if(n != 0){
    for(int i = 0; i < n; i++){
        cout << v[i] << " ";
    }
    cout << endl;

}}


//Ket iterator segitsegevel vegigmegyek egyser a vektoron,
//ami kisebb mint 5, azt a vegere rakom, s kitorlom
void delete_grades(vector<double> &v, int &n){

    int cnt = 0;
    for(int i = 0;i < n; i++){
        if(v[i] >= 5){
            v[cnt] = v[i];
            cnt++;
        }
    }

    for(int i = 0; i < n-cnt; i++){
        v.pop_back();
}
    n = cnt;

}

int main()
{
    int n;
    vector<double> notes;

    //Beolvasom a jegyeket egy double tipusu vektorba
    input(notes,n);

    //Kitorli a buko jegyeket
    delete_grades(notes,n);

    //Kiiratja a vektort
    print(notes,n);

    return 0;
}
