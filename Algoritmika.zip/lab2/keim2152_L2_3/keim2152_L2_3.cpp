//KOVACS ELEK - AKOS
//513/1
//LAB2_3
//Sz�moljuk meg egy adott sz�vegben a mag�nhangz�k sz�m�t! A sz�veg maxim�lis hossza 1000 karakter.

#include <iostream>
#include <string>
using namespace std;


string vocals = "aeiouAEIOU";

//taking the input text
void input(string &s){
    getline(cin, s);
}


//Printing the answer
void print(int x){
    cout << x;
}

int cntVoc(string s){
    int sum = 0;
    for(int i = 0; i < s.size()-1; i++){
        for(int j = 0; j < 10; j++){
            if(vocals[j] == s[i]){
                //cout << s[i] << " ";
                sum++;
            }
        }
    }
    return sum;
}

int main()
{
    string line;
    input(line);

    //Counting the vocal letters
    int cnt = cntVoc(line);

    print(cnt);
    return 0;
}
