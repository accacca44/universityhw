//Kovacs Elek Akos
//513/1
//2152
//Feladat:Adott a következő sorozat, amelynek minden elemét – az elsőt kivéve – az előző elem segítségével generáljuk:
//1, 11, 21, 1211, 111221, ...
//Határozzuk meg az n-edik (n <= 20) elemét a sorozatnak!

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void beolvas(int &n){
    cout << "n = ";
    cin >> n;
}

void print(vector<int> x){
    for(int i = 0; i < x.size();i++)cout << x[i];
    cout << endl;
}

void general(int n, vector<int> x){

   for(int i = 1; i < n; i++){

    vector<int> y;
    int l = x.size();
    int cnt = 0;
    int pos = 0;
    int num = x[0];

    while(pos < l){

        while(num == x[pos] && pos< l){cnt++;pos++;}
        y.push_back(cnt);
        y.push_back(num);
        num = x[pos];
        cnt = 0;

    }
    
    x = y;
   }
   print(x);

}

int main()
{
    int n = 6;
    vector<int> a;
    a.push_back(1);

    beolvas(n);
    general(n,a);

    return 0;
}
