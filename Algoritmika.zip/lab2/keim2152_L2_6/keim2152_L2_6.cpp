//Kovacs Elek Akos
//513/1
//2152
//Feladat:Ismerjük két szám prímszám osztóit, melyeket 64-bites előjel nélküli egész típusban tárolhatunk. 
//Határozzuk meg a két szám legkisebb közös többszörösének prímszám osztóit! (A két számot nem ismerjük, 
//csupán a prim osztóikat). A bemenethez és kimenethez tartozó számok tetszőleges sorrendben lehetnek.



#include <iostream>
#include <fstream>
#include <vector>


using namespace std;



void input(vector<unsigned long long> &a){
    ifstream in("input.txt");

    unsigned long long aux;
    while(in >> aux){
        a.push_back(aux);
    }
    in.close();
}



void print(vector<unsigned long long>a){
    for(int i = 0; i < a.size(); i++)
    {
        cout << a[i] << " ";
    }
}



void halmazositas(vector<unsigned long long>&a){
    int n = a.size()-1;
    int cnt = 0;

    int i = 0;
    int j = i+1;

    while(i < n){
        while(j<= n && a[i] != a[j]){
            j++;
        }

        if(j <= n){
            a[j] = a[n];
            a.pop_back();
            n--;
        }

        i++;
        j = i+1;

    }

}



int main()
{
    vector<unsigned long long> a;

    input(a);

    halmazositas(a);
    print(a);
    return 0;
}
