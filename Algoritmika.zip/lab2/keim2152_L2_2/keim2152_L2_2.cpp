//KOVACS ELEK - AKOS
//513/1
//LAB2_2
//Hat�rozzuk meg egy adott 64-bites term�szetes sz�m legkisebb oszt�j�t, amely nagyobb mint 1!


#include <iostream>

using namespace std;

void input(unsigned long long &n){
    cout << "n = ";
    cin >> n;
}

//visszateriti az n legkissebb osztojat
unsigned long long driver_code(unsigned long long n){

    //ha az n paros, biztos hogy a legkisebb osztoja 2
    if(n%2 == 0)return 2;

    //Nem erdemes a szam gyoketol nagyobb szamokat keresni
    else{
        for(int i = 3; i*i<= n; i++){
            if(n%i == 0)return i;
        }
    }
    //Ha nem talaltunk eddig osztot, akkor a szamunk egy primszam, amelyet mar csak onmaga oszt.
    return n;
}

int main()
{
    unsigned long long n;
    input(n);

    cout << driver_code(n);

    return 0;
}
