//Kovacs Elek Akos
//513/1
//2152
//Feladat:Adott n programozó fizetése (1 <= n <= 1 000 000). Válogassuk szét őket a fizetésük alapján. 
//Az első csoportba azok kerülnek, akiknek a fizetésük nagyobb mint 1000 EUR, a másodikba a megmaradtak közül azok, 
//akiknek a fizetése nagyobb mint 700 EUR, a harmadikban maradnak a többiek (a sorrend nem fontos).
//Törekedjünk egyetlen tömbbel dolgozni és abban elvégezni a szétválogatást, nem elég a kiiratásban csoportokra
//osztani a számokat.

#include <iostream>
#include <vector>
#include <fstream>
#include <time.h>
using namespace std;


//BEOVLASOM A PROGRAMOZOK FIZETESET
void input(vector <int>&a,int &n){
    ifstream in("input.txt");
    in >> n;
    for(int i = 0; i < n;i++){
        int x;
        in >> x;
        a.push_back(x);
    }

}


//KIIRATOM A VEKTOR ELEMEIT
void print(vector <int>a,int n, int p1, int p2){
    for(int i = 0; i < n; i++){
        if(i == p1)cout << endl;
        cout << a[i] << " ";
        if(i == p2)cout << endl;
    }
}

//ELDONTOM HOGY MELYIK CSOPORTBA TARTOZIK A FIZETES
//A CSOPORT > 1000EUR
//B CSOPORT > 700EUR
//C CSOPMORT MARADEK

void swp(int &a, int &b){
    int temp = a;
    a = b;
    b = temp;
}

char group(int num){
    if(num > 1000)return 'a';
    if(num > 700) return 'b';
    return 'c';

}


void sorting(vector<int>&a, int n, int &posA, int &posC){
    clock_t start,stop;
    start = clock();
    int pos = 0;
    while(pos <= posC){

        if(group(a[pos]) == 'a'){
            swap(a[pos], a[posA]);
            posA++;
        }
        /*else if(group(a[pos]) == 'b'){

        }*/
        else if(group(a[pos]) == 'c'){
            swap(a[pos], a[posC]);
            posC--;
            pos--;
        }

        pos++;
    }
    stop = clock();
    double ido = double(stop-start)/CLOCKS_PER_SEC;
    //cout <<"TIME:" <<ido << endl;
}

int main()
{
    vector<int> a;
    int n = 0;

    input(a,n);

    int posA = 0;
    int posC = n-1;

    //DRIVER CODE, ELRENDEZI A TOMBOT A KOVETELMENYNEK MEGFELELOEN
    sorting(a, n, posA, posC);

    print(a,n,posA,posC);

    return 0;
}
