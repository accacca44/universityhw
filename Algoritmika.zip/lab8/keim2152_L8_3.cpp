//Kovacs Elek Akos
//513/1
//2152
//Feladat 3 : Határozzátok meg egy adott n (1 <= n <= 10 000) elemű 32 bites egészekből álló sorozat leghosszabb monoton növekvő részsorozatának hosszát és
//egy ilyen részsorozatot!

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void beolvas(int& n, vector<int>& v)
{
	ifstream in("bemenet03.txt");
	in >> n;
	for (int i = 0; i < n; i++)
	{
		int aux;
		in >> aux;
		v.push_back(aux);
	}
    in.close();
}
int hossz(vector<int> v, vector<int>& maxHossz, int n)
{
	int l = 0;		//maxhossz
	int pos = 0;	//maxpos

	for (int i = n - 2; i >= 0; i--)
	{
		int temp_max = 0;
		for (int j = i+1; j < n; j++)
		{
			if (v[i] <= v[j])
				temp_max = max(maxHossz[j],temp_max);
		}
		maxHossz[i] = temp_max + 1;
		if (l <= maxHossz[i])
		{
			l = maxHossz[i];
			pos = i;
		}
	}
	return pos;
}

void kiir(vector<int> v, vector<int> hossz, int n, int pos)
{
    ofstream out("kimenet03.txt");
	int i = pos;		//sorozat kezdete
	int l = hossz[pos];		//sorozat tagjainak a szama
	out << l << endl;
	while (i < n)
	{
		if (hossz[i] == l)
		{
			out << v[i] << " " << i + 1 << endl;
			l--;
		}
		i++;
	}
    out.close();
}

int main()
{
	vector<int> v;
	int n = 0;

	beolvas(n, v);

	vector<int> maxHossz(n, -1);
	maxHossz[n - 1] = 1;

	int pos = hossz(v, maxHossz, n);

	kiir(v,maxHossz, n, pos);

	return 0;
}