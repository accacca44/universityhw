//Kovacs Elek Akos
//513/1
//2152
/*Feladat : 8 Adott egy n soros és m oszlopos mátrix (1 <= n, m <= 1000), mely 1 000 000-nál kisebb természetes számokat tartalmaz.
Határozzuk meg a legkisebb összeget, amelyet úgy kaphatunk, hogy a mátrix bal felső sarkából indulunk, a jobb alsó sarkába érünk és
 minden lépésben vagy lefelé vagy jobbra léphetünk.*/

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void beolvas(int& n, int& m, vector<vector<int>>& M)
{
    ifstream in("bemenet08.txt");
    in >> n >> m;
    M.resize(n);
    for (int i = 0; i < n; i++)
    {
        M[i].resize(m);
        for (int j = 0; j < m; j++)
        {
            in >> M[i][j];
        }
    }
    in.close();
}

void kiir(int x)
{
    ofstream out("kimenet08.txt");
    out << x;
    out.close();
}

void init_matrix(vector<vector<int>>& M, int n, int m)
{
    //iteralom a matrixot, meghatarozom minden callanak azt a lepesszamat, ahova az i,j.elemre a legrovidebben jutok el
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            //alapeset a 0,0 ilyenkor, onmaga a legrovidebb ut
            if (j == 0 && i == 0)
            {
                M[i][j] = M[i][j];
            }
            //elso sor
            if (j == 0 && i != 0)
            {
                M[i][j] = M[i][j] + M[i-1][j];
            }
            //elso oszlop
            if (i == 0 && j != 0)
            {
                M[i][j] = M[i][j] + M[i][j-1];
            }
            //minden mas esetben
            if (i && j)
            {
                M[i][j] = M[i][j] + min(M[i][j - 1], M[i - 1][j]);
            }
        }
    }
}

int main()
{
    int n = 0;
    int m = 0;

    vector<vector<int>>M;

    beolvas(n, m, M);

    init_matrix(M, n, m);

    kiir(M[n - 1][m - 1]);

    return 0;
}