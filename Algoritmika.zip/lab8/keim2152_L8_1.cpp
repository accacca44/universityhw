//Kovacs Elek Akos
//513/1
//2152
//Feladat 1 : N faktorialisa

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void beolvas(int& n)
{
    ifstream in("bemenet01.txt");
    in >> n;
    in.close();
}

void kiir(unsigned long long  x)
{
    ofstream out("kimenet01.txt");
    out << x;
    out.close();
}

unsigned long long faktorialis(int n, vector<unsigned long long>& f)
{
    //ha az adat nem ismert
    if (f[n] == -1)
    {
        f[n] = faktorialis(n - 1, f) * n;
    }
    return f[n];
}

int main()
{
    int n = 0;
    beolvas(n);
    vector<unsigned long long> faktorial(n+1,-1);
    faktorial[0] = 1;
    faktorial[1] = 1;
    
    long long f = faktorialis(n, faktorial);
    kiir(f);
    return 0;
}