//Kovacs Elek Akos
//513/1
//2152
//Feladat 2 : Számoljátok ki n elem k-ad rendű kombinációinak számát feljegyzéses módszerrel!

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void beolvas(int& n, int& k)
{
	ifstream in("bemenet02.txt");
	in >> n >> k;
}

void init(vector<vector<int>>& vec)
{
	for (int i = 0; i < vec.size(); i++)
	{
		vec[i].resize(i + 1);
		for (int j = 0; j < vec[i].size(); j++)
		{
			if (j == 0 || j == i)
				vec[i][j] = 1;
			else
			{
				vec[i][j] = -1;
			}
		}
	}
}

void printVec(vector<vector<int>> v)
{
	for (int i = 0; i < v.size(); i++)
	{
		for (int j = 0; j < v[i].size(); j++)
		{
			cout << v[i][j] << " ";
		}
		cout << endl;
	}
}

void kiir(int x)
{
    ofstream out("kimenet02.txt");
    out << x;
    out.close();
}

int C(int n, int k, vector<vector<int>>& vec)
{
	if (n >= 0 && k >= 0)
	{
		if (vec[n][k] != -1)
		{
			return vec[n][k];
		}
		else
		{
			vec[n][k] = C(n - 1, k, vec) + C(n - 1, k - 1, vec);
			return vec[n][k];
		}
	}
}

int main()
{
	int n = 0;
	int k = 0;

	beolvas(n, k);

	vector<vector<int>> vec(n+2);

	init(vec);

	C(n+1, k, vec);

	kiir(vec[n][k]);
	return 0;
}	
