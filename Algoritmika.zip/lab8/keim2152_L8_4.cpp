//Kovacs Elek Akos
//513/1
//2152
/*Feladat 4 : Adott n (1 <= n <= 1 000 000) dominó. Határozzuk meg a
leghosszabb olyan sorozatot, mely közvetlenül egymás után következő dominókból áll és betartja a dominó játék
szabályait. A dominókat el lehet forgatni 180 fokkal.*/

#include <iostream>
#include <fstream>
#include <vector>

struct Domino
{
	int bal;
	int jobb;
};

using namespace std;

void beolvas(int& n, vector<Domino>& dom)
{
	ifstream in("bemenet04.txt");
	in >> n;

	for (int i = 0; i < n; i++)
	{
		Domino temp;
		in >> temp.bal >> temp.jobb;
		dom.push_back(temp);
	}
	in.close();
}

void kiir(int x)
{
	ofstream out("kimenet04.txt");
	out << x;
	out.close();
}

bool talal(Domino a, Domino b)
{
	return (a.jobb == b.bal);
}

int domino_maxhossz(int n, vector<Domino> dom, vector<vector<int>> maxHossz)
{
	//kezdooertek
	maxHossz[0][0] = maxHossz[0][1] = 1;
	int MAX = 0;

	//iteralok a dominokon, es szamolom hogy azzal bezarolag hany dominohoz illeszthetem
	//4 eset van:
	//A domino alapertelemezett alakjat illesztem az elozo alap, ill. forditott alakjahoz - ez 2db osszehasonlitas
	//A domino forditott alakjat hasonlitom az elozo domino alap, ill. forditott alakjahoz -- szinten 2db osszehasonlitas

	for (int i = 1; i < n; i++)
	{
		Domino elozo = dom[i - 1];
		Domino elozo_fordit = { elozo.jobb, elozo.bal };
		Domino jelenleg = dom[i];
		Domino jelenleg_fordit = { jelenleg.jobb, jelenleg.bal };

		int max_alap1 = 0;
		int max_alap2 = 0;
		int max_fordit1 = 0;
		int max_fordit2 = 0;

		//vizsgalom a 4 esetet:
		if (talal(elozo, jelenleg))
		{
			max_alap1 = maxHossz[i - 1][0] + 1;
		}
		if (talal(elozo_fordit, jelenleg))
		{
			max_alap2 = maxHossz[i - 1][1] + 1;
		}
		if (talal(elozo, jelenleg_fordit))
		{
			max_fordit1 = maxHossz[i - 1][0] + 1;
		}
		if (talal(elozo_fordit, jelenleg_fordit))
		{
			max_fordit2 = maxHossz[i - 1][1] + 1;
		}
		
		maxHossz[i][0] = max(max_alap1, max_alap2);
		maxHossz[i][1] = max(max_fordit1, max_fordit2);
		if (!maxHossz[i][0])
			maxHossz[i][0] = 1;
		if (!maxHossz[i][1])
			maxHossz[i][1] = 1;
		
		if (maxHossz[i][0] > MAX || maxHossz[i][1] > MAX)
			MAX = max(maxHossz[i][1], maxHossz[i][0]);
	}
	return MAX;
}

int main()
{
	int n;
	vector<Domino> dom;
	beolvas(n, dom);

	vector<vector<int>> maxhossz(n,vector<int>(2,0));

	int l = domino_maxhossz(n, dom, maxhossz);

	kiir(l);

	return 0;
}