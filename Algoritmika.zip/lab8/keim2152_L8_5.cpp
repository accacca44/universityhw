//Kovacs Elek Akos
//513/1
//2152
/*Feladat 5 :Ismerjük n (1 <= n <= 1000) tárgy értékét és súlyát. Pakoljunk fel egy teherautóra tárgyakat maximális összértékkel, tudván,
hogy a teherautó maximális teherbírása S (0 <= S <= 10 000).
A bemeneti állomány első sora n és S értékeit tartalmazza egy szóközzel elválasztva, majd a következő n sor mindegyikében két
1 000 000-nál kisebb természetes szám található: az adott tárgy értéke és súlya.
A kimeneti állomány első sorába írjuk az elérhető maximális összértéket és az ehhez felhasznált tárgyak számát. A következő
sorokban soroljuk fel a megoldáshoz tartozó tárgyak indexeit.*/

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(int& n, int& S, vector<int>& ertek, vector<int>& suly)
{
    ifstream in("bemenet05.txt");
    in >> n >> S;
    ertek.resize(n);
    suly.resize(n);
    for (int i = 0; i < n; i++)
        in >> ertek[i] >> suly[i];
    in.close();
}
void knapsack_problem(vector<vector<int>>& hatizsak, vector<int> ertek, vector<int> suly, int n, int S)
{
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= S; j++)
        {
            //ha elfer az i.elem
            if (j >= suly[i-1])
            {
                hatizsak[i][j] = max(hatizsak[i - 1][j], hatizsak[i - 1][j - suly[i-1]] + ertek[i-1]);
            }
            else
            {
                hatizsak[i][j] = hatizsak[i - 1][j];
            }
        }
    } 
}

ofstream out("kimenet05.txt");
void kiir_elemek(vector<vector<int>> hatizsak, int i, int j, vector<int> suly, bool& ok, int db)
{

    if (i > 0 && j > 0) {
        if (hatizsak[i][j] == hatizsak[i - 1][j])
            kiir_elemek(hatizsak, i - 1, j,suly,ok,db);
        else
        {
            kiir_elemek(hatizsak, i - 1, j - suly[i - 1], suly,ok,db+1);
            if (!ok)
            {
                out << hatizsak[hatizsak.size()-1][hatizsak[0].size()-1] << " " << db << endl;
                ok = true;
            }
            out << i << endl;
        }
    }
}

int main()
{
    int n = 0;
    int S = 0;
    
    vector<int> ertek;
    vector<int> suly;

    beolvas(n, S, ertek, suly);

    vector<vector<int>> hatizsak(n + 1, vector<int>(S + 1, 0));

    knapsack_problem(hatizsak, ertek, suly, n, S);

    bool ok = false;

    kiir_elemek(hatizsak,n,S,suly,ok,1);

    out.close();

    return 0;
}