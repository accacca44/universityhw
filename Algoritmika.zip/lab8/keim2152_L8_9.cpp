//Kovacs Elek Akos
//513/1
//2152
/*Feladat 9 : Adott egy n soros és m oszlopos bitmátrix (1 <= n, m <= 50). Határozzuk meg az olyan utak számát, amelyek a
mátrix bal felső sarkából indulnak és a jobb alsó sarkába érkeznek, minden lépésben vagy lefelé vagy jobbra léphetünk és
csak azokra a mezőkre léphetnek, melyek értéke 1. Garantált, hogy a bal felső és jobb alsó sarokban 1-es érték található.*/

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void beolvas(int& n, int& m, vector<vector<int>>&map)
{
    ifstream in("bemenet09.txt");
    in >> n >> m;
    map.resize(n);
    for (int i = 0; i < n; i++)
    {
        map[i].resize(m);
        for (int j = 0; j < m; j++)
        {
            in >> map[i][j];
        }
    }
    in.close();
}

void kiir(int x)
{
    ofstream out("kimenet09.txt");
    out << x;
    out.close();
}

void bejar(int n, int m, vector<vector<int>>& map)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (map[i][j] != 0)
            {
                if (i == 0 && j == 0)
                {

                }
                //elso sor
                else if(i == 0)
                {
                    if (!map[i][j - 1])
                        map[i][j] = 0;
                }
                else if (j == 0)
                {
                    if (!map[i - 1][j])
                        map[i][j] = 0;
                }
                else
                {
                    map[i][j] = map[i - 1][j] + map[i][j - 1];
                }

            }   
        }
    }
}

int main()
{
    int n = 0;
    int m = 0;
    vector<vector<int>> map;
    beolvas(n, m, map);

    bejar(n, m, map);

    kiir(map[n - 1][m - 1]);

    return 0;
}