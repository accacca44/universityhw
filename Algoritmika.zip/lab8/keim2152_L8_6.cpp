//Kovacs Elek Akos
//513/1
//2152
/*Feladat 6 : Adott két karakterlánc, melyek hossza nem haladja meg az 1000 karaktert.
Határozzuk meg a leghosszabb olyan karakterlánc hosszát, mely mindkét adott sztringnek részsorozata és
egy ilyen megoldást!*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

void beolvas(string& s1, string& s2)
{
	ifstream in("bemenet06.txt");
	getline(in, s1);
	getline(in, s2);
	in.close();
}

void matrix_atjar(int l1, int l2, string s1, string s2, vector<vector<int>>& map)
{
	for (int i = 0; i < l1; i++)
	{
		for (int j = 0; j < l2; j++)
		{
			int temp = 0;
			
			//vizsgalom ha kileptem volna a matrixbol
			if (i - 1 >= 0 && j - 1 >= 0)
			{
				temp = map[i - 1][j - 1];
			}

			//egyenlo karakterek eseten beleszamit a megodasba
			if (s1[i] == s2[j])
			{
				map[i][j] = temp + 1;
			}
			//ellenkezo esetben, nelkule folytatodik a megoldas
			else
			{
				//ujra meg kell neznem, ha letezik e jobb illetve felso szomszed
				//0,0.elem
				if (i == 0 && j == 0)
				{

				}
				//elso sor
				else if(i == 0)
				{
					map[i][j] = map[i][j - 1];
				}
				else if (j == 0)
				{
					map[i][j] = map[i - 1][j];
				}
				else
				{
					map[i][j] = max(map[i - 1][j], map[i][j - 1]);
				}

			}
		}
	}
}

ofstream out("kimenet06.txt");
void kiir(vector<vector<int>> map, int i, int j, string str1, string str2,bool& volt)
{
	if (i && j)
	{
		//ha tudom hogy a stringek karakterei egyenloek, akkor csak az atlon megyek vissza
		if (str1[i] == str2[j])
		{
			kiir(map, i - 1, j - 1, str1, str2, volt);
			out << str1[i];
		}
		else
		{
			if (map[i - 1][j] >= map[i][j - 1])
			{
				kiir(map, i - 1, j, str1, str2,volt);
			}
			else
				kiir(map, i, j - 1, str1, str2, volt);
		}
	}
	//elso sor
	else if (i == 0)
	{
		if (!volt)
		{
			int l1 = map.size() - 1;
			int l2 = map[0].size() - 1;
			out << map[l1][l2] << endl;
			volt = true;
		}
		if (map[i][j] == 1)
		{
			out << str1[i];
		}
		/*else
			kiir(map, i, j - 1, str1, str2);*/
	}
	//elso oszlop
	else if (j == 0)
	{
		if (!volt)
		{
			int l1 = map.size() - 1;
			int l2 = map[0].size() - 1;
			out << map[l1][l2] << endl;
			volt = true;
		}
		if (map[i][j] == 1)
		{
			out << str1[i];
		}
		/*else
			kiir(map, i - 1, j, str1, str2);*/
	}
}


int main()
{
	string str1 = "";
	string str2 = "";
		
	beolvas(str1, str2);
	int l1 = str1.length();
	int l2 = str2.length();

	vector<vector<int>> map(l1, vector<int>(l2, 0));

	matrix_atjar(l1, l2, str1, str2, map);
	
	//MATRIX KONZOLORA KIIRATASA
			/*cout << "  ";
			for (int i = 0; i < l2; i++)
				cout << str2[i] << " ";
			cout << endl;*

			/*for (int i = 0; i < l1; i++)
			{
				cout << str1[i] << " ";
				for (int j = 0; j < l2; j++)
				{
					cout << map[i][j] << " ";
				}
				cout << endl;
			}*/
	bool volt = false;
	kiir(map,l1-1,l2-1,str1,str2,volt);
    out.close();
    return 0;
}