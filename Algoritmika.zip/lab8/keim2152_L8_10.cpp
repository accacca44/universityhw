//Kovacs Elek Akos
//513/1
//2152
/*Feladat 10 : Adott egy n soros és m oszlopos bitmátrix (1 <= n, m <= 10 000). Határozzuk meg a legnagyobb olyan négyzet oldalhosszát, 
                amely a mátrixban található és csak 1-eseket tartalmaz!*/

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void beolvas(int& n, int& m, vector<vector<int>>&map)
{
    ifstream in("bemenet10.txt");
    in >> n >> m;
    map.resize(n);
    for (int i = 0; i < n; i++)
    {
        map[i].resize(m);
        for (int j = 0; j < m; j++)
        {
            in >> map[i][j];
        }
    }
    in.close();
}

void kiir(int x)
{
    ofstream out("kimenet10.txt");
    out << x;
    out.close();
}

int16_t bejar(int n, int m, vector<vector<int>>& map)
{
    int maxi_hossz = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if(map[i][j] != 0)
            {
                if(i && j)
                {
                    map[i][j] = min(map[i-1][j-1],min(map[i-1][j], map[i][j-1])) + 1;
                    maxi_hossz = max(maxi_hossz, map[i][j]);
                }
            }      
        }
    }
    return maxi_hossz;
}

int main()
{
    int n = 0;
    int m = 0;
    vector<vector<int>> map;
    beolvas(n, m, map);

    int max = bejar(n, m, map);

    kiir(max);

    return 0;
}