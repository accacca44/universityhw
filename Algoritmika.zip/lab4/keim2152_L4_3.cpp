//Kovacs ELek Akos
//513/1
//2152
//Feladat : Beilleszteses Rednezes

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(vector<unsigned long long> &a, int &n)
{
    ifstream in("input.txt");
    in >> n;
    unsigned long long aux = 0;
    for(int i = 0; i < n; i++)
    {
        in >> aux;
        a.push_back(aux);
    }

    in.close();
}

void kiir(vector<unsigned long long> a, int n)
{
    ofstream out("output.txt");
    
    for(int i = 0; i < n; i++)
    {
        out << a[i] << " ";
    }
    
    out.close();
}



void insertion_sort(vector<unsigned long long> &a, int &n)
{  
    unsigned long long temp;
    
    for(int i = 1; i < n; i++)
    {
        temp = a[i];
        int j = i-1;
        while(a[j] > temp && j >= 0)
        {
            a[j+1] = a[j];
            j--;
        }
        a[j+1] = temp;
    }
    
}

int main()
{
    vector<unsigned long long> a;
    int n;

    beolvas(a,n);
    kiir(a,n);
    insertion_sort(a,n);
    kiir(a,n);
}