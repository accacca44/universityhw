//Kovacs ELek Akos
//513/1
//2152
//Feladat : Buborek rendezes

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(vector<unsigned long long> &a, int &n)
{
    ifstream in("input.txt");
    in >> n;
    unsigned long long aux = 0;
    for(int i = 0; i < n; i++)
    {
        in >> aux;
        a.push_back(aux);
    }

    in.close();
}

void kiir(vector<unsigned long long> a, int n)
{
    ofstream out("output.txt");
    
    for(int i = 0; i < n; i++)
    {
        out << a[i] << " ";
    }
    out << endl;
    out.close();
}

void felcserel(unsigned long long &x, unsigned long long &y)
{
    unsigned long long temp = x;
    x = y;
    y = temp;
}

void bubble_sort(vector<unsigned long long> &a, int &n)
{
    
    int k = n;
    bool rendezett = false;
    while(!rendezett)
    {
        int nn = k-1;
        rendezett = true;
        for(int j = 0; j < nn; j++)
        {
            if(a[j] > a[j+1])
            {
                felcserel(a[j],a[j+1]);
                rendezett = false;
                k = j+1;
            }
        }
        
    }
    
}

int main()
{
    vector<unsigned long long> a;
    int n;

    beolvas(a,n);
    kiir(a,n);
    bubble_sort(a,n);
    kiir(a,n);
}