//Kovacs Elek Akos
//2152
//513/1
//Feladat: Rekurziv Torzstenyezore bontas

#include <iostream>
using namespace std;

bool ok = true;

void beolvas(int& szam)
{
    cout << "Szam = ";
    cin >> szam;
}

void kiir(int oszto, int hatvany)
{
    if (ok)
    {
        ok = false;
        if (hatvany == 1)
        {
            cout << oszto << " ";
        }
        else
        {
            cout << oszto << "^" << hatvany << " ";
        }
    }
    else
    {
        if (hatvany == 1)
        {
            cout << "* " << oszto << " ";
        }
        else {
            cout << "* " << oszto << "^" << hatvany << " ";
        }
    }
}


//meghatarozza mennyivel kell osztani a N szamot hogy ne ismetlodjon meg a szam
//pl : ha N = 24, akkor osszam el 8al (2^3), mert kulonben a 4 es 8is torzstenyezojekent jelenne meg
int osszeg(int hatvany, int oszto) {
    if (hatvany < 1)
    {
        return 1;
    }
    return oszto * osszeg(hatvany - 1, oszto);
}

//meghatarozza az oszto hatvanyszamat
int hatvany_cnt(int szam, int oszto)
{
    if (szam % oszto != 0)
    {
        return 0;
    }
    return 1 + hatvany_cnt(szam / oszto, oszto);
}

//ciklus ami novelo az osztot es kiirat
void torzstenyezo(int szam, int d)
{
    if (!(d <= szam))
    {
        return;
    }

    int hatvany = hatvany_cnt(szam, d);
    szam = szam / osszeg(hatvany, d);

    if(hatvany)kiir(d, hatvany);

    return torzstenyezo(szam, d+1);

}




int main()
{
    int szam;
    beolvas(szam);
    if(szam == 1){
        cout << "Nem letezik felbontasa";
    }
    else
    {
    torzstenyezo(szam, 2);
    }

}