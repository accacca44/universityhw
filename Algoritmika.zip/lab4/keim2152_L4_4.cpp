//Kovacs ELek Akos
//513/1
//2152
//Feladat : Leszamlalo rendezes

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(vector<unsigned long long> &a, int &n)
{
    ifstream in("input.txt");
    in >> n;
    unsigned long long aux = 0;
    for(int i = 0; i < n; i++)
    {
        in >> aux;
        a.push_back(aux);
    }

    in.close();
}

void kiir(vector<unsigned long long> a, int n)
{
    ofstream out("output.txt");
    
    for(int i = 0; i < n; i++)
    {
        out << a[i] << " ";
    }
    out << endl;
    out.close();
}

void felcserel(unsigned long long &x, unsigned long long &y)
{
    unsigned long long temp = x;
    x = y;
    y = temp;
}

void counting_sort(vector<unsigned long long> &a,vector<unsigned long long> seged, int &n)
{   
    int k = 1000000;
    vector<unsigned long long> b(1000000,0);
    for(int i = 0; i < n; i++)
    {
        seged[a[i]]++;
    }

   for(int i = 1; i < k; i++)
   {
       seged[i]+=seged[i-1];
   }

    for(int i = n-1; i >=0; i--)
    {
        
        seged[a[i]]--;
        b[seged[a[i]]] = a[i];
    }

    for(int i = 0; i < n; i++)
    {
        a[i] = b[i];
    }
   
    

    
}

int main()
{
    vector<unsigned long long> a;
    vector<unsigned long long> seged(1000000,0);
    int n;

    beolvas(a,n);
    kiir(a,n);
    counting_sort(a,seged,n);
    kiir(a,n);
}