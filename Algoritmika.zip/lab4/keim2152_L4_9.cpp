#include <iostream>
#define ull unsigned long long

using namespace std;

void beolvas(ull &x, ull &y)
{
    cout << "x = ";
    cin >> x;
    cout << "y = ";
    cin >> y;
}

void kiir(ull x)
{
    cout << x;
}

ull orosz_szoroz(ull x, ull y, ull szorzat)
{
    if(x == 0)return szorzat;
    if(x%2 == 1)szorzat+=y;
    return orosz_szoroz(x/2,y*2,szorzat);
}

int main()
{
    ull x = 0,y = 0;
    beolvas(x,y);
    ull szorzat = orosz_szoroz(x,y,0);
    kiir(szorzat);
}