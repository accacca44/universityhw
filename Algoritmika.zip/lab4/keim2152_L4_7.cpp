//Kovacs Elek Akos
//513/2
//2152
//Feladat:rjunk rekurzív algoritmust, amely kiszámítja egy n-ed fokú polinom értékét egy adott x pontban!

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(double &x, int &n, vector<int> &a)
{
    ifstream in("input_l4_8.txt");
    in >> n;
    for(int i = 0; i <= n; i++)
    {
        int aux;
        in >> aux;
        a.push_back(aux);
    }
    in >> x;
}

int horner(double x, int n, vector<int> a)
{
    if(n < 0)
    {
        return 0;
    }
    return a[n] + x * horner(x,n-1, a);
}

int main()
{
    int n;
    double x;
    vector<int> a;

    beolvas(x,n,a);
    cout << horner(x,n,a);
}