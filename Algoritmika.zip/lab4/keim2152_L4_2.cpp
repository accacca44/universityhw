//Kovacs ELek Akos
//513/1
//2152
//Feladat : Minimuim kivalasztasra epulp rendezes:

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(vector<unsigned long long> &a, int &n)
{
    ifstream in("input.txt");
    in >> n;
    unsigned long long aux = 0;
    for(int i = 0; i < n; i++)
    {
        in >> aux;
        a.push_back(aux);
    }

    in.close();
}

void kiir(vector<unsigned long long> a, int n)
{
    ofstream out("output.txt");
    
    for(int i = 0; i < n; i++)
    {
        out << a[i] << " ";
    }
    out << endl;
    out.close();
}

void felcserel(unsigned long long &x, unsigned long long &y)
{
    unsigned long long temp = x;
    x = y;
    y = temp;
}

void selection_sort(vector<unsigned long long> &a, int &n)
{
    for(int i = 0; i < n-1; i++)
    {
    int min_index = i;
        for(int j = i+1; j < n; j++)
        {
            if(a[min_index] > a[j])
            {
                min_index = j;
            }
        }
        felcserel(a[min_index],a[i]);
    }
    
}

int main()
{
    vector<unsigned long long> a;
    int n;

    beolvas(a,n);
    kiir(a,n);
    selection_sort(a,n);
    kiir(a,n);
}