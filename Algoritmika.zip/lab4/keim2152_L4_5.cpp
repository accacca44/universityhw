//Kovacs ELek Akos
//513/1
//2152
//Feladat : Radix Sort

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void beolvas(vector<unsigned long long> &a, int &n)
{
    ifstream in("input.txt");
    in >> n;
    unsigned long long aux = 0;
    for(int i = 0; i < n; i++)
    {
        in >> aux;
        a.push_back(aux);
    }

    in.close();
}

void kiir(vector<unsigned long long> a, int n)
{
    ofstream out("output.txt");
    
    for(int i = 0; i < n; i++)
    {
        out << a[i] << " ";
    }
    out << endl;
    out.close();
}

void felcserel(unsigned long long &x, unsigned long long &y)
{
    unsigned long long temp = x;
    x = y;
    y = temp;
}

short last_digit(unsigned long long x, int n)
{
    int t = 1;
    for(int i = 0; i < n; i++)
        t*= 10;
    return (x%t)/(t/10);
}

int szamjegy = 1;
void radix_sort(vector<unsigned long long> &a, int &n)
{   
    bool rendben = false;
    while(!rendben){
    rendben = true;
    vector<unsigned long long> b(1000000,0);
    vector<unsigned long long> seged(10,0);
    int k = 10;

    for(int i = 0; i < n; i++)
    {
        seged[last_digit(a[i],szamjegy)]++;
    }

   for(int i = 1; i < k; i++)
   {
       seged[i]+=seged[i-1];
       if(seged[i]!= seged[i-1])
       {
           rendben = false;
       }
   }

    for(int i = n-1; i >=0; i--)
    {
        
        seged[last_digit(a[i],szamjegy)]--;
        b[seged[last_digit(a[i],szamjegy)]] = a[i];
    }

    for(int i = 0; i < n; i++)
    {
        a[i] = b[i];
    }
    szamjegy++;
    }
}


int main()
{
    vector<unsigned long long> a;
    int n;

    beolvas(a,n);
    
    radix_sort(a,n);
    kiir(a,n);

}