#include <iostream> 
#include <fstream>
#include <vector>

using namespace std;

void csere(int &a, int &b)
{
    a = a+b;
    b = a-b;
    a = a-b;
}

void bubblesort(vector<int> &a, int n){

    int nn = n-1;
    int k = nn;
    bool rendben = false;
    while(!rendben)
    {
        rendben = true;
        for(int i = 0; i < k; i++)
        {
            if(a[i] > a[i+1])
            {
                csere(a[i], a[i+1]);
                rendben = false;
            }
        }
    }
}

void felcserel(vector<int> &a, int n)
{
    for(int i = 0; i < n-1; i++)
    {
        for(int j = i+1; j < n; j++)
        {
            if(a[i] > a[j])
            {
                csere(a[i],a[j]);
            }
        }
    }
}

void maximum(vector<int> &a, int n)
{
    for(int i = 0; i < n-1; i++)
    {
        int min_index = i;
        for(int j = i; j < n; j++)
        {
            if(a[min_index] > a[j])
            {
                min_index = j;
            }
        }
        if(i != min_index)
            csere(a[i],a[min_index]);
    }
}

void valogatasos(vector<int> &a, int n)
{
    vector<int> seged(n,0);
    for(int i = 0; i < n; i++)
    {
        int db = 0;
        for(int j = 0; j < n; j++)
        {
            if(a[i] > a[j])
            {
                db++;
            }
        }
        seged[db] = a[i];
    }
    a = seged;
}

void insertion_sort(vector<int> &a, int n)
{
    for(int i = 1;i < n;i++)
    {
        int temp = a[i];
        int j = i-1;
        while(j >= 0 && a[j]>temp)
        {
            a[j+1] = a[j];
            j--;
        }
        a[j+1] = temp;
    }
}

void countsort(vector<int> &a, int n)
{
    int k = 1000000;
    vector<int> b(n);
    vector<int> seged(k,0);
    
    for(int i = 0; i < n; i++)
    {
        seged[a[i]]++;
    }

   for(int i = 1; i <= k; i++)
   {
       seged[i]=seged[i] + seged[i-1];
   }

    for(int i = n-1; i >=0; i--)
    {
        
        b[seged[a[i]]-1] = a[i];
        seged[a[i]]--;
    }

    for(int i = 0; i < n; i++)
    {
        a[i] = b[i];
    }
   
}

int main()
{
    ifstream in("rendezesek.txt");
    int aux = 0;
    vector<int> a;
    while(in >> aux)
    {
        a.push_back(aux);
    }
    int n = a.size();

    countsort(a,n);

    for(int i = 0; i < a.size(); i++)cout << a[i]<< " ";
}