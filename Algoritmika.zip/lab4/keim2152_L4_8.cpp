//Kovacs Elek Akos
//513/1
//2152
//Feladat: Alakitsunk 16os szamrendszerbol 10esbe.

#include <iostream>
#include <string>
using namespace std;

void beolvas(string &hexa)
{
    cout << "Hexadecimali szam = ";
    cin >> hexa;
}

void kiir(int eredmeny)
{
    cout << eredmeny;
}


//a rekurziv fuggveny
unsigned long long atalakit(string hexa, int pos, unsigned long long szorzat)
{
    //kilepesi feltetel, ha minden szamjegyet megneztem
    if(pos < 0)
    {
        return 0;
    }


    //eldontom hogy melyik szamjegy minek felel meg 10es szamrendszerben
    if(hexa[pos] >= '0' && hexa[pos] <= '9')
    {
        return ((hexa[pos]-48)*szorzat) + atalakit(hexa,pos-1,szorzat*16);
    }
    if(hexa[pos] >= 'a' && hexa[pos] <= 'f')
    {
        return ((hexa[pos]-87)*szorzat) + atalakit(hexa,pos-1,szorzat*16);
    }
    if(hexa[pos] >= 'A' && hexa[pos] <= 'F')
    {
        return ((hexa[pos]-55)*szorzat) + atalakit(hexa,pos-1,szorzat*16);
    }



}

void hiba()
{
    cout << "A megadott szam nem abrazolhato 64bites egeszkent!";
}
int main()
{
    string hexa;
    beolvas(hexa);
    int pos = hexa.size()-1;

    //hibakezeles
    if(pos > 16){
        hiba();
        return 0;
    }
    unsigned long long eredmeny = atalakit(hexa,pos,1);
    kiir(eredmeny);
}