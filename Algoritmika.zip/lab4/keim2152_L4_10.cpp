//Kovacs Elek Akos
//513/1
//2152
//Feladat : 10.Írjunk rekurzív algoritmust amely meghatározza egy adott a 64 bites előjel nélküli természetes szám gyökét

#include <iostream>
using namespace std;

void beolvas(long double &szam)
{
    cout << "a = ";
    cin >> szam;
}

void kiir(long double gyok)
{
    cout << gyok;
}

//x-be teszem az eddigi gyokomet
long double sqrt(long double szam, long double x){
   if(x*x-szam < 0.000001)
   {
       return x;
   }
   return sqrt(szam, (x+(szam/x))/2 );
}

int main()
{
    long  double szam;
    beolvas(szam);
    long double gyok = sqrt(szam,szam);
    kiir(gyok);
}