//KOVACS ELEK AKOS
//513/1
//2152
//Feladat:rjuk ki n (1 <= n <= 1 000 000) darab 64 bites előjel nélküli természetes szám 
//legnagyobb közös osztóját!

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

//beolvasom a szamokat
void beolvas(vector<unsigned long> &a)
{
    unsigned long aux;
    unsigned long n;
    ifstream in("input.txt");
    in >> n;
    for(int i = 0; i < n; i++)
    {
        in >> aux;
        a.push_back(aux);
    }
}

void kiir(vector<unsigned long> a)
{
    int n = a.size();
    for(int i = 0; i < n; i++)cout << a[i] << " ";
}

//kiszamolom 2 szam lnko-jat
unsigned long lnko(unsigned long x, unsigned long y){
    while(y != 0)
    {   
        unsigned long r = x % y;
        x = y;
        y = r;  
    }
    return x;
}    

//kiszamolom sorban az osszes szam lnkojat
unsigned long driver_code(vector<unsigned long> a, int n){
        unsigned long aux = a[0];  
    for(int i = 1; i < n; i++){
        if(aux == 1)return 1;
        if(aux-a[i] == 1 || aux-a[i] == -1)return 1;
        aux = lnko(aux,a[i]);
    }
    return aux;
}


int main()
{
    vector<unsigned long> a;
    beolvas(a);
    
    cout << driver_code(a,a.size());

}