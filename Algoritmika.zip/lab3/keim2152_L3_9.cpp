//Kovacs Elek Akos
//513/1
//2152
//Feladat:Írjunk algoritmust, amely megkeresi és kiírja az első n tökéletes számot!

#include <iostream>
#include <vector>
#define MAX 99999999
#define ull unsigned long
using namespace std;

void beolvas(unsigned short& n)
{
    cout << "n = ";
    cin >> n;
}

bool vizsgal(unsigned long long x)
{
    unsigned long long s = 1;
    for (unsigned long long d = 2; d * d <= x; d++)
    {
        if (x % d == 0)
        {
            if (d * d == x)
            {
                s += d;
            }
            else
            {
                s += ((x / d) + d);
            }
        }
    }
    return (s == x);
}

void szita_feltoltes(vector<ull> &szita, unsigned  short n)
{
    cout << "Az elso " << n << " tokeletes szam: "; 
    //a szita minden elemrol megmutatja, hogy hany osztoja van
    //kezdetben minden elem osztja sajat magat, illetve minden szamot osztja az egy,
    //ezek a maximum szamitas miatt elhanyagolhatoak
    for(ull i = 0; i <= MAX; i++)
    {
        szita.push_back(1);
    }
   
    //p vel szamolom a az elemek tobbszoroseit
    ull p = 2;

    //t pedig egyel marad mindig le, ellenorzi, ha tokelets szamot alkottunk
    ull t = 1;
    while(p*2 <= MAX && n>0)
    {
        
        if(t > 2 && szita[t] == t)
        {
            n--;
            cout << t << " ";
        }
        //q egy egesz szam, amivel szamolom a p - primszam tobbszoroseit
        ull  q = 2;
        while(p*q <= MAX)
        {
            szita[p*q]+= p;
            q++;
        }
        
        //kiir(szita, n);
        t++;
        p++;
    }


}   

void tokeletes(unsigned short n)
{
    cout << "Az elso " << n << " tokeletes szam: ";
    unsigned short db = 0;
    unsigned long long i = 2;
    while (db < n)
    {

        if (vizsgal(i))
        {
            db++;
            cout << i << " ";
        }
        i++;
    }
}

int main()
{
    unsigned short int n;
    beolvas(n);

    if(n <= 4)
        {
            tokeletes(n);
        }
    else
    {
        vector<ull> szita;
        szita_feltoltes(szita, n);
    }
}
