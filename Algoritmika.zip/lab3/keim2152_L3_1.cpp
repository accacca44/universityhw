//KOVACS ELEK AKOS
//513/1
//2152
//Feladat:Döntsük el egy adott 64 bites előjel nélküli egész számról, hogy völgyszám-e vagy hegyszám. 

#include <iostream>

using namespace std;

void print(short x){
    if(x == -1)cout << "nincs benne hegyszam vagy volgyszam";
    if(x == -2)cout << "volgyszam";
    if(x == -3)cout << "hegyszam";
}

void input(unsigned long &n){
    cout << "n = ";
    cin >>n;
}

bool decide(unsigned long n){
    short x = n%10;
    short y = (n%100)/10;
    return (x < y);
} 

unsigned long volgy(unsigned long n){
    
    if(n < 100)return -1;

    unsigned long masolat = n;
    unsigned long felepit = n%10;
    unsigned long p = 10;
    short prev1 = -1; 
    short prev2 = -1;
    short i = -1; 
    bool volt = false;

    while(n != 0){
        i = n % 10;
        prev2 = prev1;
        prev1 = i;

        if(prev1 != -1 && prev2 != -1){
           if(!volt){
               if(prev1 < prev2){
                   felepit += i*p;
                   p*=10;
               }
               else{
                   volt = true;
                   felepit += i*p;
                   p*=10;
               }
           } 
           else{
               if(prev1 > prev2){
                   felepit += i*p;
                   p*=10;
               }
               else{
                   break;
               }
           }
        
        }

        n /= 10;
    }
    if(!volt)return -1;  
    if(masolat == felepit)return -2;
    cout << felepit;
    
}
int hegy(unsigned long n){

    if(n < 100)return -1;

    unsigned long masolat = n;
    unsigned long felepit = n%10;
    unsigned long p = 10;
    short prev1 = -1; 
    short prev2 = -1;
    short i = -1; 
    bool volt = false;

    while(n != 0){
        i = n % 10;
        prev2 = prev1;
        prev1 = i;

        if(prev1 != -1 && prev2 != -1){
           if(!volt){
               if(prev1 > prev2){
                   felepit += i*p;
                   p*=10;
               }
               else{
                   volt = true;
                   felepit += i*p;
                   p*=10;
               }
           } 
           else{
               if(prev1 < prev2){
                   felepit += i*p;
                   p*=10;
               }
               else{
                   break;
               }
           }
        
        }

        n /= 10;
    }
    if(!volt)return -1;  
    if(masolat == felepit)return -3;
    cout << felepit;
}

int main(){

    unsigned long n;
    short eredmeny; 
    input(n);
    bool ok = decide(n);

    if(!ok)eredmeny = volgy(n);
    else   eredmeny = hegy(n);

    print(eredmeny);
}