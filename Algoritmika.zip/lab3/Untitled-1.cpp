//Kovacs Elek Akos
//513/1
//2152
//Feladat:Írjunk algoritmust, amely megkeresi és kiírja az első n tökéletes számot!
