//KOVACS ELEK AKOS
//513/1
//2152
//Feladat:rjunk algoritmust, amely egy adott, 6-nál nagyobb 32 bites előjel nélküli egész 
//páros számot felír két különböző prímszám összegeként (Goldbach-sejtés).

#include <iostream>
#include <vector>

using namespace std;

//vekerem a szamot
void beolvas(unsigned int &n)
{
    cout << "n = ";
    cin >> n;
}

//ellenorzesre kiiratom a vektort
void kiir(vector<bool>a, int n)
{
    for(int i = 1; i <= n; i++)
    {
        cout << i << " " << a[i] << endl;
    }
   
}

void feltolt(vector<bool> &szita, unsigned int n){
    
    //feltoltom kezdetben a vektor 1-tol n-ig 1esekkel
    //mivel kezdetben feltetelezem, hogy minden szam prim
    unsigned int i = 0;
    for(int i = 0; i <= n; i++){
        szita.push_back(true);
    }

    //a szita segitsegevel meghatarozom a primszamokat 1tol n-ig

    //p - vel megyek vegig minden szamon a szitaban
    unsigned int p = 2;
    while(p*p <= n)
    {
        while(szita[p] == false)p++;

        //q egy egesz szam, amivel szamolom a p - primszam tobbszoroseit
        unsigned int q = 2;
        while(p*q <= n)
        {
            szita[p*q] = false;
            q++;
        }
        
        //kiir(szita, n);

        p++;
    }
    
}

void keres(vector<bool> szita, unsigned int n){
    unsigned int i = 2;
    
    while(2*i <= n)
    {
        while(szita[i] == false)
        {
            i++;
        }

        unsigned int a = i;
        unsigned int b = n-i;
        if(szita[b]){
            cout << n << " = " << a << " + " << b;
            break;
        }


        i++;
    }

}

int main()
{
    vector<bool> szita;
    unsigned int n;
    beolvas(n);
    feltolt(szita,n); //feltolti a szitat
    keres(szita,n);   //megkeresem azt a 2 primet, melynek osszege = n

}