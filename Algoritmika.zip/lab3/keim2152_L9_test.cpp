#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n;
    cout << "n = ";
    cin >> n;


    int szita[10000];

    for(int i = 0; i <= n; i++)szita[i] = 2;

    szita[1] = 1;
    szita[0] = 0;
    
    int p = 2;
    while(p*2 <= n)
    {
        int q = 2;
        while(p*q <= n)
        {
            szita[p*q]++;
            q++;
        }

        p++;

    }

    int maxi = -1;
    int max_oszto = -1;

    for(int i = 1; i <= n; i++)
    {
        if(szita[i] > max_oszto)
        {
            max_oszto = szita[i];
            maxi = i;
            cout << maxi << " - " << max_oszto<<endl; 
        }
    }


}