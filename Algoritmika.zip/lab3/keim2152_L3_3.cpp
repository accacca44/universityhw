//KOVACS ELEK AKOS
//513/1
//2152
//Feladat:Írjunk algoritmust, amely megadja a Fibonacci-sorozat egy adott 64 bites előjel nélküli egész 
//számnál kisebb elemeinek számát! A Fibonacci-sorozat nulladik elemét nem kell figyelembe venni.

#include <iostream>

using namespace std;

void beolvas(unsigned long &n)
{
    cout << "n = ";
    cin >> n;
}

void kiir(unsigned long x, short n)
{
    cout << n << " darab kissebb elem van a Fibonacci-sorozatban, mint " << x;
}

unsigned long fib(unsigned long n)
{
    unsigned long f1 = 1;
    unsigned long f2 = 1;
    unsigned long f = 2;
    
    if(n <= 1)return 0;
    if(n == 2)return 2;
    short db = 2;

    while(f < n)
    {
        f = f1 + f2;

        db++;

        f2 = f1;
        f1 = f;
    }

    return --db;

}

int main()
{
    unsigned long n;
    beolvas(n);
    short db = fib(n);
    kiir(n,db);

}