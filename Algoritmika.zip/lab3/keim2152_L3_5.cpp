//Kovacs Elek Akos
//513/1
//2152
//Feladat:Adott egy római szám, írjuk ki arab számjegyekkel! A bemenet hossza legtöbb 1000 karakter.


#include <iostream>
#include <string>
using namespace std;

//beolvasom a romai szamot
void beolvas(string &romai_szam)
{   
    cout << "Add meg a romai szamot:";
    getline(cin, romai_szam);    
}

//kiiratom az eredmenyt
void kiir(int x)
{
    cout << "A megadott szam arab szamjegyekkel: ";
    if(x != 0)
        cout << x;
}

//a convert alprogram atalakitja a romai szamjegyet arab szamma
int convert(char kar)
{
    int c = -1;

    if(kar == 'I')c = 1;
    if(kar == 'V')c = 5;
    if(kar == 'X')c = 10;
    if(kar == 'L')c = 50;
    if(kar == 'C')c = 100;
    if(kar == 'D')c = 500;
    if(kar == 'M')c = 1000;

    return c;

}

int szamol(string romai)
{   

    //a kivonas nev. logikai valtozo azt vizsgalja, hogy az utanna kovetkezo karakter
    //nagyobb e vagy kissebb
    bool kivonas = false; 
    //az s - ben lesz felepitve a romai szam decimalis alakban
    int s = 0;
    
    int cnt = 1;
    int prev = -1;
    int n = romai.size();

    for(int i = 0; i < n; i++)
    {   
        int num = convert(romai[i]);
        if(num == prev)
        {
            cnt++;
        }
        if(num < prev)
        {
            cnt = 1;
        }

        if(prev < num && prev != -1)
        {
            s = s-(cnt+1)*prev;
        }

        prev = num;
        s += num;
    }

    return s;
}

int main()
{
    string romai_szam;
    beolvas(romai_szam);    
    int eredmeny = szamol(romai_szam);
    kiir(eredmeny);
}
