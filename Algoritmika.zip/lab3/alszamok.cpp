#include <iostream>
using namespace std;

int beolvas(){

}

int kiir(){

}

int main(){
    
    int statvek[100];
    int a;

    
    
    return 0;
}