//Kovacs Elek Akos
//513/1
//2152
//Feladatok:Adott egy arab szám (n ≤ 5000), írjuk ki római számjegyekkel!

#include <iostream>
#include <string>
using namespace std;

void beolvas(short &szam)
{
    cout << "Arab szam = ";
    cin >> szam; 
}

void atalakit(short szam)
{

    cout << "A megadott szam romai szamjegyekkel: ";

    short a,b,c,d;
    a = szam%10000/1000;
    b = szam%1000/100;
    c = szam%100/10;
    d = szam%10/1;

    if(a <= 5)
    {
        for(int i = 0; i < a; i++)cout << "M";
    }
    
    if(b <= 3)
    {
        for(int i = 0; i < b; i++)cout << "C";
    }
    
    if(b == 4)
    {
        cout << "CD";
    }
    
    if(b  == 5)
    {
        cout << "D";
    }
    
    if(b >= 6 && b <=8)
    {
        cout << "D";
        for(int i = 0; i < b-5; i++)cout << "C";
    }
    
    if(b == 9)
    {
        cout << "CM";
    }
    if(c <= 3)
    {
        for(int i = 0; i < c; i++)cout << "X";
    }
    
    if(c == 4)
    {
        for(int i = 0; i < c; i++)cout << "XL";
    }
    
    if(c  == 5)
    {
        cout << "L";
    }
    
    if(c >= 6 && c <=8)
    {
        cout << "L";
        for(int i = 0; i < c-5; i++)cout << "X";
    }
    
    if(c == 9)
    {
        cout << "XC";
    }
    if(d <= 3)
    {
        for(int i = 0; i < d; i++)cout << "I";
    }
    
    if(d == 4)
    {
        for(int i = 0; i < d; i++)cout << "IV";
    }
    
    if(d  == 5)
    {
        cout << "V";
    }
    
    if(d >= 6 && d <=8)
    {
        cout << "V";
        for(int i = 0; i < d-5; i++)cout << "I";
    }
    
    if(d == 9)
    {
        cout << "IX";
    }
    
    

}

int main()
{
    short szam = 0;
    beolvas(szam);
    atalakit(szam);

}