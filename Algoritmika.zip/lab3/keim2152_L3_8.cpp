// &, |, ~, ^
//es, vagy, negalalas, kizaras(csak ha az egyik igaz)
// >> shift right       SHR x/2
// << shift left        SHL x*2

// x = 110
// x >> 1 -> 011 
// x << 1 -> 110
// x << 1 -> 1100

//Maszkolas


//Kovacs Elek Akos
//513/1
//2152
//Feladat:Bontsunk fel egy adott 64 bites előjel nélküli egész n számot 2 hatványainak összegére!

#include <iostream>

using namespace std;

//beolvastam a kert szamot
void beolvas(unsigned long &x)
{
    cout << "Szam = ";
    cin >> x;
}

void kiir(int i, bool &elso)
{
    if(elso)
    {   
        elso = false;
        cout << "A megadott szam 2 hatvanyaira bontva: ";
        cout << "2^" << i;
    }
    else{
        cout << " + 2^" << i;
    }
}

//mivel a valtozok 2es szamrendszerben tarolnak adatot, igy ezt hihasznalva konnyen
//fel lehet epiteni egy egesz szamot, bin -> dec kepletet alkalmazva
void maszkolas(unsigned long x)
{
    cout << "A megadott szam 2 hatvanyaira bontva: ";

    //a helyes kiiratas miatt, a '+' operandust valtoztatom
    bool elso = true;

    //minde egyes bitet megvizsgalok
    for(int i = 63; i >= 0; i--)
    {
        //kell egy segedvaltozo amibe lemasolgatom a maszkolas eredmenyet
        unsigned long y = 0;
        y = x & (1ULL<<i);

        //ha valamelyik biten 1es kaptam, azt jelenti van olyan hatvany
        if(y > 0){
            kiir(i,elso);
        }
    }

}

int main()
{
    unsigned long x;
    beolvas(x);

    //bitmuveletet hasznalva maszkolom
    maszkolas(x);   
}