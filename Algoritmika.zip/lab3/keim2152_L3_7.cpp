//Kovacs Elek Akos
//513/1
//2152
//Feladat:Bontsunk törzstényezőkre egy adott 1 000 000-nál kisebb természetes számot!

#include <iostream>

using namespace std;

void beolvas(unsigned int &x)
{
    cout << "Add meg a szamot: ";
    cin >> x;
}

void torzstenyezo(unsigned short szam)
{

    cout << "A megadott szam torzstenyezokre felbontva: ";
    unsigned short masolat = szam;
    bool ok = false;
    int d = 2;
    while(d <= masolat)
    {
        int cnt = 0;
        while(masolat % d == 0)
        {
            cnt++;
            masolat /= d;
        }
        if(cnt != 0)
        {
            if(!ok)
            {   
                ok = true;
                if(cnt == 1)
                {
                    cout << d;
                }
                else
                {
                    cout << d << "^" << cnt;
                }
            }
            else
            {
                if(cnt == 1)
                {
                    cout << "*" << d;
                }
                else
                {
                    cout << "*" << d << "^" << cnt;
                }
            }
                
        }

        if(d == 2)
            d++;
        else
        {
            d+=2;
        }
    }

    
    
       


}

int main()
{
    unsigned int szam;
    beolvas(szam); 
    torzstenyezo(szam);  
}