//Kovacs Elek Akos
//513/1
//2152
//Feladat:Írjunk algoritmust, amely megkeresi és kiírja az első n tökéletes számot! 

#include <iostream>
#include <vector>

#define MAX 1000000000

using namespace std;

void beolvas(unsigned  long &n)
{
    cout << "n = ";
    cin >> n;
}

void szita_feltoltes(vector<unsigned long  > &szita, unsigned  long n)
{
    cout << "Az elso " << n << " tokeletes szam: "; 
    //a szita minden elemrol megmutatja, hogy hany osztoja van
    //kezdetben minden elem osztja sajat magat, illetve minden szamot osztja az egy,
    //ezek a maximum szamitas miatt elhanyagolhatoak
    for(unsigned long  i = 0; i <= MAX; i++)
    {
        szita.push_back(1);
    }
   
    //p vel szamolom a az elemek tobbszoroseit
    unsigned long  p = 2;

    //t pedig egyel marad mindig le, ellenorzi, ha tokelets szamot alkottunk
    unsigned long  t = 1;
    while(p*2 <= MAX && n>0)
    {
        
        if(t > 2 && szita[t] == t)
        {
            n--;
            cout << t << " ";
        }
        //q egy egesz szam, amivel szamolom a p - primszam tobbszoroseit
        unsigned long  q = 2;
        while(p*q <= MAX)
        {
            szita[p*q]+= p;
            q++;
        }
        
        //kiir(szita, n);
        t++;
        p++;
    }


}   



int main()
{
    vector<unsigned long> szita;
    unsigned long n;
    
    beolvas(n);

    szita_feltoltes(szita, n);



}