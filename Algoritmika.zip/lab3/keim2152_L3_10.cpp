//Kovacs Elek Akos
//513/1
//2152
//Feladat:Keressük meg adott n (1 <= n <= 1 000 000) számig a legtöbb osztójú természetes számot!

#include <iostream>
#include <vector>

using namespace std;


void beolvas(unsigned long &n)
{
    cout << "n = ";
    cin >> n;
}

void szita_feltoltes(vector<unsigned long> &szita, unsigned long n)
{
    //a szita minden elemrol megmutatja, hogy hany osztoja van
    //kezdetben minden elem osztja sajat magat, illetve minden szamot osztja az egy,
    //ezek a maximum szamitas miatt elhanyagolhatoak
    for(unsigned long i = 0; i <= n; i++)
    {
        szita.push_back(0);
    }

    unsigned long p = 2;
    while(p*2 <= n)
    {
        //q egy egesz szam, amivel szamolom a p - primszam tobbszoroseit
        unsigned long q = 2;
        while(p*q <= n)
        {
            szita[p*q]++;
            q++;
        }
        
        //kiir(szita, n);

        p++;
    }


}   

void maximum_kiir(vector<unsigned long> szita,unsigned long n)
{   
    unsigned long maxi = 0;
    unsigned long maxi_osztok = 0;
    for(int i = 2; i <= n; i++)
    {   
        //cout << szita[i] << ":" << i << endl;
        if(maxi_osztok < szita[i])
        {
            maxi_osztok = szita[i];
            maxi = i;
        }
    }

    cout << "A legtobb osztoval rendelkezo szam : " << maxi << " ," << maxi_osztok << " valodi oszto";
}

int main()
{
    vector<unsigned long> szita;
    unsigned long n;
    
    beolvas(n);

    szita_feltoltes(szita, n);

    maximum_kiir(szita,n);
}