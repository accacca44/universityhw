#include <iostream>
using namespace std;

int beolvas(){

}

int kiir(){

}

int main(){
    
    return 0;
}