//Kovacs Elek Akos
//513/1
//2152
//Feladat 3 : Adva van egy n db egész számot tartalmazó sorozat (2 <= n <= 10). 
//Helyezzünk az adott számok közé n – 1 aritmetikai műveleti jelt (+, –, *, /), 
//úgy, hogy a kifejezés értéke legyen egyenlő egy adott K számmal! Amennyiben 
//lehetetlen megoldást találni, írjunk ki megfelelő üzenetet! A kifejezés értéke
//minden lépésben legyen egész szám!  Garantáltm, hogy minden részeredmény 
//ábrázolható lesz 32 bites előjeles egész típusban. A műveleteket nem a 
//matematikából ismert operátorprecedencia szerint végezzük, hanem megjelenésük 
//sorrendjében. A megoldásokat tetszőleges sorrendben ki lehet íratni. 

#include <iostream>
#include <fstream>
using namespace std;

ofstream    out("kimenet03.txt");

void beolvas(int& n, int& K, int szamok[])
{
    ifstream in("bemenet03.txt");
    in >> n;
    for(int i = 0; i < n; i++)
        in >> szamok[i];
    in >> K;
}

void kiir(char v[],int szamok[], int n, int K)
{
    out << K <<" = " << szamok[0];
    for(int i = 1; i < n; i++)
        out << " " << v[i] << " " << szamok[i];
    out << endl;
}

//Masodik szamtol kezdbe minden lehetseges muveletet vegigprobal minde kovetkezo szamra
void szamol(int n, int K, int szamok[], int eredmeny, char muveletek[], int k, bool& volt)
{
    //leallasi felt.
    //ha minden szamon atmentunk
    if(k == n)
    {
        if(K == eredmeny)
        {
            volt = true;
            kiir(muveletek,szamok,n,K);
        }
    }
    else
    {
        muveletek[k] = '+';
        szamol(n,K,szamok,eredmeny + szamok[k], muveletek, k+1,volt);

        muveletek[k] = '-';
        szamol(n,K,szamok,eredmeny - szamok[k], muveletek, k+1,volt);

        muveletek[k] = '*';
        szamol(n,K,szamok,eredmeny * szamok[k], muveletek, k+1,volt);
        muveletek[k] = '/';
        //oszatni csak ugy hogy egesz szam maradjon, es valos osztas legyen (ne osszak nullaval)
        if(szamok[k] != 0 && eredmeny%szamok[k] == 0)
            szamol(n,K,szamok,eredmeny / szamok[k], muveletek, k+1,volt);
    }
}

int main()
{
    int n;
    int k = 1;
    int K = 0;
    int eredmeny = 0;
    int szamok[10];
    char muveletek[10];

    bool volt = false;

    beolvas(n,K,szamok);

    eredmeny = szamok[0];
    k = 1;

    szamol(n,K,szamok,eredmeny,muveletek,k,volt);
    if(!volt)
        out << "Nincs megoldas!";

    out.close();
    return 0;
}