//Kovacs Elek Akos
//513/1
//2152
//Feladat 2 : Oldjuk meg a királynős feladatot három logikai tömb segítségével. Ezen tömbök értékei azt fejezik ki, 
//hogy létezik-e királynő egy bizonyos oszlopban, vagy egy olyan átlón, amely párhuzamos a főátlóval, illetve egy 
//olyanon, amely párhuzamos a mellékátlóval. A megoldásokat tetszőleges sorrendben ki lehet íratni. 

#include <iostream>
#include <fstream>

using namespace std;

ofstream out("kimenet02.txt");

void beolvas(int& n)
{
    ifstream in("bemenet02.txt");
    in >> n;
    in.close();
}

void kiir(int v[], int n)
{
 for(int i = 0; i < n; i++)
   {
        for(int j = 0; j < n; j++)
        {
            if(v[i] == j)out << "Q ";
            else
            {
                out << "0 ";
            }
        }
        out << endl;
    }
    out << endl;
}

void feltolt(bool a[], bool b[], bool c[], int n)
{
    for(int i = 0; i < n; i++)
    {
        a[i] = false;
        b[i] = false;
        c[i] = false;
    }
    for(int i = n; i < 2*n; i++)
    {
        b[i] = false;
        c[i] = false;
    }
}


//ellenorzom ha nem uti egyik elozo kirlyno sem
bool szabadLepni(bool o[], bool foa[], bool mea[], int fai, int mai, int i)
{
    return !(o[i] || foa[fai] || mea[mai]);
}


//backtrack
void kiralynok(int n, int m[], bool o[], bool foa[], bool mea[], int k)
{
    if(k == n)
    {
        kiir(m,n);
    }
    else
    {
        //minden sort megprobalok
        for(int i = 0; i < n; i++)
        {
            m[k] = i;

            int fai = n-1 + k - i;
            int mai = k + i;

            //ha szabad lepni, akkor leteszem a kiralynot
            if(szabadLepni(o,foa,mea,fai,mai,i))
            {
                o[i] = true;
                foa[fai] = true;
                mea[mai] = true;
                kiralynok(n,m,o,foa,mea,k+1);

                o[i] = false;
                foa[fai] = false;
                mea[mai] = false;
            }
            
        }

    }
}

int main()
{
    //n*n hosszu sakktabla
    int n;
    beolvas(n);
    //megoldas tomb()
    int megoldas[100];
    //logikai tombok
    bool oszlop[100];
    bool foa[200];
    bool mea[200];

    //elokeszitem a logikai tomboket
    feltolt(oszlop, foa, mea, n);

    //kiralynok alporgram
    kiralynok(n,megoldas,oszlop,foa,mea,0);
    out.close();
    return 0;
}