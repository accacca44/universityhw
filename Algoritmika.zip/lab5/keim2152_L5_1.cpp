//Kovacs Elek Akos
//513/1
//2152
//Feladat 1 : Generáljunk minden lehetséges sorozatot, amelynek elemei a {0, 1, 2} 
//          halmazból vannak, és a 0 m-szer, az 1 p-szer és a 2 q-szor fordul elő.


#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ofstream out("kimenet01.txt");

void bemeneti_adatok(int &m, int &p, int &q)
{
    ifstream in("bemenet01.txt");
    in >> m >> p >> q;
    in.close();
}

void kiir(vector<int>sor)
{

    if(out.is_open())
    {
    for(int i = 0; i < sor.size(); i++)
    {
        out << sor[i] << " ";
    }
    out << endl;
    }

    else
    {
        cout << "A kimenet01.txt nem elerheto!" << endl;
    } 
}

void sorozat(int m, int p, int q,vector<int> sor)
{   
    if(m+p+q == 0)
    {
        kiir(sor);
    }

    if(m!=0)
    {
        sor.push_back(0);
        sorozat(m-1,p,q,sor);
        sor.pop_back();
    }
      
    if(p!=0)
    {
        sor.push_back(1);
        sorozat(m,p-1,q,sor);
        sor.pop_back();
    }  
    
    if(q!=0)
    {
        sor.push_back(2);
        sorozat(m,p,q-1,sor);
        sor.pop_back();
    }
}

int main()
{   
    int m = 0;
    int p = 0;
    int q = 0;

    bemeneti_adatok(m,p,q);
    vector<int> sor;
    sorozat(m,p,q,sor);
    out.close();
    return 0;
}