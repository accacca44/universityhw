//Kovacs Elek Akos
//513/1
//2152
//Feladat 4 : egyen n építőkocka, amelyek 1-től n-ig vannak címkézve. 
//Beolvassuk az oldalaik hosszát és a színüket. Írjunk ki minden k kockából 
//álló tornyot, amelyeket úgy építhetünk fel, hogy nem teszünk egymásra azonos 
//színű kockát és oldalaik mérete (lentről felfele) szigorúan csökkenő sorozatot 
//alkotnak.

#include <iostream>
#include <fstream>
#include <string>
#define INT_MAX 2147483647

using namespace std;

ofstream out("kimenet04.txt");

void beolvas(int cSize[], string cColor[], int& n, int& k)
{
    ifstream in("bemenet04.txt");
    in >> n >> k;
    for(int i = 1 ; i <= n; i++)
    {
        in >> cColor[i] >> cSize[i];
    }
}

void kiir(int megoldas[], int k)
{
    for(int i = 1; i <=k; i++)
        out << megoldas[i] << " ";
    out << endl;
}

void torony(int n, int cSize[], string cColor[], int k, int megoldas[], int step)
{
    //ha meg nem epult fel a torony, valasszon hozza uj kockat
    if(step <= k)
    {   
        //minden kockat megprobalunk
        for(int i = 1; i <= n; i++)
        {
            megoldas[step] = i;
            
            //nem azonos a szine
            if(cColor[megoldas[step-1]] != cColor[i])
            {   
                //kissebb mint az elozo ertek
                if(cSize[megoldas[step-1]] > cSize[i])
                {
                    torony(n,cSize,cColor,k,megoldas,step+1);
                }
            }


        }
    }
    else
    {
        kiir(megoldas,k);
    }
}

int main()
{   
    string kocka_szin[101];
    int kocka_merete[101];
    int n = 0;                      //darab kocka
    int k = 0;                      //torony magassaga (k darab kocka alkotja)
    int megoldas[101];              //egy felepitett torony
    int step = 1;

    beolvas(kocka_merete, kocka_szin,n,k);
    kocka_merete[0] = INT_MAX;
    kocka_szin[0] = "";
    megoldas[0] = 0;

    torony(n,kocka_merete,kocka_szin,k,megoldas,step);
    out.close();
    return 0;
}