//Kovacs Elek Akos
//513/1
//2152
//Feladat 9 : Adva van n dominó (egy dominón két „számjegy” van feltüntetve a 
//{0, 1, ..., 6} halmazból úgy, hogy a nullától különböző számjegyeknek megfelelően 
//pontok vannak a dominóra festve). Írjunk ki valamennyi, n dominóból álló láncot, 
//amelyben bármely, két egymás után következő dominó a szomszédos felén ugyanazt a 
//számjegyet tartalmazza. A dominók bármelyik félfelükkel kapcsolódhatnak a láncba. 
//A bemeneti állomány első sora tartalmazza a dominók n számát, majd a következő n 
//sor mindegyike a dominó két felén szereplő pontok számát. A megoldásokat tetszőleges 
//sorrendben ki lehet íratni.

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ofstream out("kimenet09.txt");

struct Domino
{
    int jobb;
    int bal;
};

void beolvas(int&n, vector<Domino>& v, vector<bool>& b)
{
    ifstream in("bemenet09.txt");
    in >> n;
    for(int i = 0; i < n; i++)
    {   
        Domino temp;
        in >> temp.bal >> temp.jobb;
        v.push_back(temp);
        b.push_back(false);
    }
    in.close();
}

void kiir(vector<Domino>v)
{
    for(int i = 0; i < v.size(); i++)
        out << v[i].bal << " " << v[i].jobb << " ";
    out << endl;
}

void elhelyez(int n, vector<Domino> v, vector<Domino> megoldas, int k,vector<bool>volt, bool& ok)
{
    
    if(k == n)
    {
        ok = true;
        kiir(megoldas);
    }
    
    else
    {
        for(int i = 0; i < n; i++)
        {
            if(k == 0)
            {
                megoldas.push_back(v[i]);
                volt[i] = true;
                elhelyez(n,v,megoldas,k+1,volt,ok);
                megoldas.pop_back();
                volt[i] = false;

                //Megforditom a dominot s ugy is megprobalom
                swap(v[i].jobb, v[i].bal);
                megoldas.push_back(v[i]);
                volt[i] = true;
                elhelyez(n,v,megoldas,k+1,volt,ok);
                megoldas.pop_back();
                volt[i] = false;
            }
            else
            {
                Domino prev = megoldas[k-1];

                if(prev.jobb == v[i].bal && !volt[i])
                {
                    megoldas.push_back(v[i]);
                    volt[i] = true;
                    elhelyez(n,v,megoldas,k+1,volt,ok);
                    volt[i] = false;
                    megoldas.pop_back();
                }
                
                //Megforditom a dominot es ugy is megprobalom
                swap(v[i].jobb, v[i].bal);
                if(prev.jobb == v[i].bal && !volt[i])
                {
                    megoldas.push_back(v[i]);
                    volt[i] = true;
                    elhelyez(n,v,megoldas,k+1,volt,ok);
                    volt[i] = false;
                    megoldas.pop_back();
                }
                
            }

        }
    }
}

int main()
{
    int n = 0;
    int k = 0;
    bool ok = false;
    vector<Domino> myDominos;
    vector<Domino> megoldas;
    vector<bool>volt;
    

    beolvas(n,myDominos,volt);
    elhelyez(n,myDominos, megoldas,k, volt,ok);

    if(!ok)
        cout << "nincs megoldas";
        
    out.close();
    return 0;
}