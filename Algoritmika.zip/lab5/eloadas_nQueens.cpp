#include <iostream>
#include <vector>

using namespace std;

void kiir(int v[9], int n)
{
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            if(v[i] == j)cout << "Q ";
            else{
                cout << "0 ";
            }
        }
        cout << endl;
    }
    cout << endl;
}

bool szabad(int v[], int n, int k)
{
    bool nemTamad = true;
    int j = 1;

    while(j < k && nemTamad)
    {
        if(v[k] == v[j] || k-j == v[k] - v[j] || v[j] - v[k] == k-j)
        {
            nemTamad = false;
        }
        else
        {
            j++;
        }
    }
    return nemTamad;
}
void kiralynok(int v[], int n, int k)
{  
    //vizsgalok minden oszlopot, k. sorban
    for(int i = 1; i <= n; i++)
    {
        //lerakom a legelso helyere a kiralynot az adott sorban
        v[k] = i;
        
        //ha szabad poziciora raktam le akkor veszem a kovetkezo sort
        if(szabad(v,n,k))
        {
            if(k < n)
            {   
                kiralynok(v,n,k+1);
            }
            else
            {
                kiir(v,n);
            }
        }
    }
}

int main()
{
    // n x n -es sakktabla
    int n;
    //az i-dik sorban, es a v[i]-dik oszlopba raktam le a kiralynot
    int v[9] = {0};
    //az elso sorral kezdem
    int k = 1;

    cout << "n = "; cin >> n;

    kiralynok(v,n,k);

}