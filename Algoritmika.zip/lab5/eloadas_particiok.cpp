#include <iostream>

using namespace std;

void kiir(int v[10], int k)
{
    for(int i = 1; i <= k; i++)
        cout << v[i] << " ";
    
    cout << endl;

}

void particiok(int v[], int s, int k)
{
    for(int i = 1; i <= s; i++)
    {
        v[k] = i;
        if(i < s)
        {
            particiok(v,s-i,k+1);   
        }
        else
        {
            kiir(v,k);
        }
    }
}

int main()
{
    int k = 1;
    int n;
    cout << "n = ";
    cin >> n;

    int v[10];

    particiok(v,n,k);
}