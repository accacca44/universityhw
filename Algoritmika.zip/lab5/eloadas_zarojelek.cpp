#include <iostream>

using namespace std;

void kiir(bool a[], int n)
{
    for(int i = 0; i < n; i++)
    {
        if(a[i])cout << '(';
        if(!a[i])cout << ')';
    }
    cout << endl;
}

void zarojelek(bool v[], int n, int nyitott,int zart, int k)
{
    if(k == n)
    { 
        kiir(v,n);
    }
    else
    {
        //NYITOTT - TRUE
        if(nyitott <  n/2)
        {
            v[k] = true;
            zarojelek(v,n,nyitott+1,zart,k+1);
        }
        
        //ZART - FALSE
        if(zart < nyitott)
        {
            v[k] = false;
            zarojelek(v,n,nyitott,zart+1,k+1);
        }
        
    }
}

int main()
{
    int n;
    bool sorozat[100];

    cout << "n =";cin >> n;
    zarojelek(sorozat,n,0,0,0);
}