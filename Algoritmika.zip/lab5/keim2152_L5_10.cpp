#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

//a helyezettek nyeremeny-ertekei, ezek csak kezdoertekek
int p1 = 12;
int p2 = 8;
int p3 = 5;

void beolvas(int&m ,int& x, int& y, int& z, int p[])
{
    ifstream in("bemenet10.txt");
    in >> m;
    in >> x >> y >> z;
    for(int i = 0; i < m; i++)
    {
        in >> p[i];
    }
}

void general_megoldas(int m ,int p[], bool volt[], int tempP1, vector<int>megoldas)
{
    if(tempP1 == p1)
    {   
        cout <<"ok";
    }
    else
    {
        for(int i = 0; i < m; i++)
        {
            volt[i] = true;
            megoldas.push_back(p[i]);
            general_megoldas(m,p,volt,tempP1 + p[i], megoldas);
            volt[i] = false;
            megoldas.pop_back();
        }
    }
}

int main()
{
    int m;
    int x, y, z;
    int prizez[100];
    bool volt[100] = {0};

    vector<int> megoldas;

    beolvas(m,x,y,z,prizez);

    general_megoldas(m,prizez, volt, 0, megoldas);
    

}