#include <iostream>
#include <vector>

using namespace std;

void kiir(vector<int>v)
{
    for(int i = 0; i < v.size(); i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}

void permutacio(vector<int> v, int n, vector<bool> volt)
{
    if(v.size() == n)
    {
        kiir(v);
    }
    else
    {
        for(int i = 1; i <= n; i++)
        {
            if(!volt[i])
            {
                volt[i] = true;
                v.push_back(i);
                permutacio(v,n,volt);
                volt[i] = false;
                v.pop_back();
            }
        }
    } 
}  

int main()
{
    int n;
    cout << "n = "; cin >> n;
    vector<int> v;
    vector<bool> volt(n+1,false); 
    permutacio(v,n,volt);
}