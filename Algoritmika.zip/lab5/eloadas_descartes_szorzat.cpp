#include <iostream>
#define N 10

using namespace std;


void kiir(int a[N], int n)
{
    for(int i = 1; i < n; i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;
}

void descartes(int m, int n, int megoldas[N], int k)
{
    if(n == k)
    {
        kiir(megoldas,k);
    }
    else
    {
        for(int a = 1; a<= m; a++)
        {
            megoldas[k] = a;
            descartes(m,n,megoldas,k+1);
        }
    }

}
int main()
{
    int m;
    int n;
    int megoldas[N];
    cout << "m = ";
    cin >> m;
    cout << "n = ";
    cin >> n;


    descartes(m,n,megoldas,0);
}