//Kovacs Elek Akos
//513/1
//2152
//Feladat 6 : Egy n x n méretű sakktáblán az (x, y) helyen található egy 
//futár és az (x0, y0) helyen egy ló. A lónak el kell jutnia erről a helyről az 
//(x1, y1) helyre, anélkül, hogy egy bizonyos négyzetre többször lépne illetve, 
//hogy olyan helyen állna meg, ahonnan a futár kiütheti. Írjuk ki a ló útvonalait!
//A ló nem ütheti le a futárt!

#include <iostream>
#include <fstream>
#include <math.h>
#include <vector>
using namespace std;

ofstream out("kimenet06.txt");

struct Node
{
    int sor;
    int oszlop;
};

void beolvas(int& n, Node& loPos, Node& futarPos, Node& destPos)
{
    ifstream in("bemenet06.txt");
    in >> n;
    in >> futarPos.sor >> futarPos.oszlop;
    in >> loPos.sor >> loPos.oszlop;
    in >> destPos.sor >> destPos.oszlop;

    futarPos.sor--;
    futarPos.oszlop--;
    loPos.sor--;
    loPos.oszlop--;
    destPos.sor--;
    destPos.oszlop--;
}

void elokeszit_Tabla(int n, Node poslo, Node pos, bool a[101][101])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            a[i][j] = false;
            if (abs(i - pos.sor) == abs(j - pos.oszlop))
            {
                a[i][j] = true;
            }
        }
    }
    a[poslo.sor][poslo.oszlop] = true;
}

bool szabadLepni(int x, int y, bool b[][101], int n)
{
    bool valasz = true;

    //voltunk mar ezen a pozicion, vagy a futarba utkozunk
    if (b[x][y])
    {
        valasz = false;
    }

    //nem lepunk ki a sakktablarol
    if (x < 0 && x >= n && y < 0 && y >= n)
    {
        valasz = false;
    }


    return valasz;
}

void kiir_maskepp(vector<Node> m)
{
    for (int i = 0; i < m.size(); i++)
    {
        out << m[i].sor << " " << m[i].oszlop << endl;
    }
    out << endl;
}

void seta(Node lo, Node dest, bool b[][101], int n, Node megoldas[], int ugras, vector<Node> megoldasok)
{
    int nextMoveX[8] = { 2, 1, -1, -2, -2, -1, 1, 2 };
    int nextMoveY[8] = { 1, 2, 2, 1, -1, -2, -2, -1 };

    if (lo.sor == dest.sor && lo.oszlop == dest.oszlop)
    {
        kiir_maskepp(megoldasok);
    }
    else
    {
        //minden lehetseges lo - lepest megvizsgalunk
        for (int i = 0; i < 8; i++)
        {

            int ujsor = lo.sor + nextMoveX[i];
            int ujoszlop = lo.oszlop + nextMoveY[i];
            
            if (szabadLepni(ujsor, ujoszlop, b, n))
            {
                b[ujsor][ujoszlop] = true;
                lo.sor = ujsor;
                lo.oszlop = ujoszlop;
                megoldasok.push_back(lo);
                
                seta(lo, dest, b, n, megoldas, ugras + 1, megoldasok);
                
                //reset
                b[ujsor][ujoszlop] = false;
                lo.sor -= nextMoveX[i];
                lo.oszlop -= nextMoveY[i];
                megoldasok.pop_back();
            }

        }
    }
}

int main()
{
    //knight positionin 
    Node loPos;
    //futar position
    Node futarPos;
    //cel position
    Node destPos;

    //sakktabla merete
    int n = 0;
    //elozo lepesek lementese
    bool board[101][101];

    //megoldasok
    Node megoldas[10000];

    //megoldasok V2
    vector<Node> megoldasok;

    beolvas(n, loPos, futarPos, destPos);

    //minden pozicion ahol tamadhat a futar megjegyezzuk
    elokeszit_Tabla(n, loPos, futarPos, board);

    //backtrack
    seta(loPos, destPos, board, n, megoldas, 0, megoldasok);
    out.close();
    return 0;
}