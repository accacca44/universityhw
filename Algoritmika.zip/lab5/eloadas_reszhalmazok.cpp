//Genarald az osszes reszhalmazt 1-től n-ig
//pl: n = 3-ra
//1
//1 2 
//1 2 3
//1 3 
//1 3 2
//2 1
//2 1 3

#include <iostream>
#define N 10

using namespace std;


void kiir(int a[N], int n)
{
    for(int i = 1; i < n; i++)
    {
        cout << a[i] << " ";
    }
    cout << endl;
}

void reszhalmaz(int m, int n, int megoldas[N], int k)
{
    if(n == k)
    {
        kiir(megoldas,k);
    }
    else
    {
        for(int a = 1; a<= m; a++)
        {
            megoldas[k] = a;
            reszhalmaz(m,n,megoldas,k+1);
        }
    }

}
int main()
{
    int m;
    int n;
    int megoldas[N];
    cout << "m = ";
    m = 2;
    cout << "n = ";
    cin >> n;


    reszhalmaz(m,n,megoldas,0);
}