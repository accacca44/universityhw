
            int foatlo_index = n + 1 + k - i;