//Kovacs Elek Akos
//513/1
//2152

//Feladat 5 : Írjunk rekurzív algoritmust, amely generálja egy adott n 
//szám minden partícióját. Azok közül a partíciók közül, amelyek csak a 
//tagok sorrendjében különböznek, csak egyet, a lexikografikus szempontból 
//utolsót kell kiírnunk. A megoldásokat lexikografikusan növekvő sorrendben 
//írassuk ki.

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

ofstream out("kimenet05.txt");

void input(int& n)
{
    ifstream in("bemenet05.txt");
    in >> n;
}

void kiir(vector<int> sor)
{
    for(int i = 1; i < sor.size(); i++)
    {
        out << sor[i] << " ";
    }
    out << endl;
}

void particio(int n, vector<int> sor, int sum, int db)
{
    if(n == sum)
    {
        kiir(sor);
    }

    for(int i = 1; i <= n; i++)
    {
        if(sum+i <= n && sor[db-1] >= i)
        {
            sor.push_back(i);
            particio(n,sor,sum+i,db+1);
            sor.pop_back();
        }
    }
}

int main()
{
    int n = 0;
    input(n);

    vector<int> sor;
    sor.push_back(101);

    int sum = 0;
    int db = 1;

    particio(n,sor,sum,db);
    out.close();
    return 0;
}