//Kovacs Elek Akos
//513/1
//2152
//Feladat 8 : Adva van egy n személyből álló csoport. Minden személynek van 
//legalább n/2 barátja a csoporton belül. Lacinak van egy könyve, amelyet a 
//csoport minden tagja el szeretne olvasni. Írjátok ki, hogyan vándorol a könyv 
//egyik személytől a másikig úgy, hogy mindenkihez csak egyszer kerül, és egy 
//személy csak egy barátjának kölcsönzi a könyvet, amíg az visszatér Lacihoz. 
//Az összes lehetséges megoldást keressük, a megoldásokat tetszőleges sorrendben 
//ki lehet íratni. A bemeneti állomány első sora tartalmazza a személyek n számát 
//és a barát párosok m számát. A következő m sor mindegyike tartalmaz egy barát párost. 

#include <iostream>
#include <fstream>
#include <string>
#include <vector>   

using namespace std;

ofstream out("kimenet08.txt");

//a fuggveny visszateriti az adott nev poziciojat,ha letezik
//ha nem, akkor hozzafuzi a sorozatunkhoz, es visszateriti a jelenlegi sorozat utolso indexet
int keres(string str, vector<string> &s)
{
    for(int i = 0; i < s.size(); i++)
    {
        if(s[i] == str)return i;
    }
    s.push_back(str);
    return s.size()-1;
}


//beolvasas elott feltetelezzuk hogy senki nem all kapcsolatban senkivel
void elokeszit(bool b[][100],bool v[])
{   
    for(int i = 0; i < 100; i++)
    {
        v[i] = false;

        for(int j = 0; j < 100; j++)
        {
            b[i][j] = false;
        }
    }
}

void beolvas(int& n, int&m, vector<string>& nevek, bool b[][100])
{
    string nev1, nev2;

    ifstream in("bemenet08.txt");
    in >> n >> m;
    for(int i = 0; i < m; i++)
    {
        int p1,p2;              //azok a poziciok ahanyadik helyen van a szemely a sorozatban
        in >> nev1 >> nev2;
        p1 = keres(nev1,nevek);
        p2 = keres(nev2,nevek);
        b[p1][p2] = true;
        b[p2][p1] = true;
    }
    in.close();
}

void kiir(vector<string> s)
{
    for(int i = 0; i < s.size(); i++)
        out << s[i] << " ";
    out << endl;
}

//parameterek:  
    //pers - azok a szemelyeknek a szama, akik tovabbadtak a konyvet
void korbead(int L, vector<string>nevek, bool b[][100], vector<string>kor, int pers, int n, bool volt[])
{
    if(pers == n && kor[kor.size()-1] == "Laci")
    {
        kiir(kor);
    }
    else
    {
        for(int i = 0; i < n; i++)
        {
            //ha kapott egy baratot
            if(b[L][i] && !volt[i])
            {
                //b[L][i] = false;
                //b[i][L] = false;
                volt[i] = true;
                kor.push_back(nevek[i]);
                korbead(i,nevek,b,kor,pers+1,n,volt);
                kor.pop_back();
                //b[L][i] = true;
                //b[i][L] = true;
                volt[i] = false;
            }
        }
    }
}
int main()
{
    //az csoporton beluli emberek kapcsolatat egy logikai matrixal koduljuk
    //pl: baratsagMatrix[0][3] = TRUE, akkor a nevek[0] es nevek[3] nevu ember BARAT
    bool baratsagMatrix[100][100];
    bool volt[100];
    //beolvasasi elofordulasuk szerint tarolom a neveket
    //pl: INPUT: Laci Bandi, Laci Kati, Bandi Ferenc, elofordusi sorrendjuk: Laci Bandi Kati Ferenc
    vector<string> nevek;
    vector<string> kor;     //az a kor amely azok a szemelyek nevet akik korbeadjak a konyvet
    
    int n = 0;
    int m = 0;

    elokeszit(baratsagMatrix,volt);
    beolvas(n,m,nevek,baratsagMatrix);

    int LaciPos = keres("Laci", nevek);
    kor.push_back("Laci");

    korbead(LaciPos, nevek, baratsagMatrix, kor, 0, n,volt);
    out.close();

    
    return 0;
}