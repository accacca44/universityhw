//Kovacs Elek Akos
//513/1
//2152
//Feladat 7 : Egy utazóügynök házról házra jár az áruival. A cégnek n féle áruja 
//van; minden áru súlyát és árát ismerjük. Tudva azt, hogy az ügynök hátizsákjába 
//legtöbb S súlyú árut lehet becsomagolni, írjuk ki azokat az árukat, amelyeket az 
//ügynök kiválaszt az n áru közül tudva, hogy az áruk értékének legkevesebb 
//Összeg-gel kell egyenlőnek lennie.

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ofstream out("kimenet07.txt");

void beolvas(unsigned int& o, unsigned int& s, unsigned int ar[], unsigned int suly[],int& n)
{
    ifstream in("bemenet07.txt");
    in >> n >> o >> s;
    for(int i = 0; i < n; i++)
    {
        in >> suly[i] >> ar[i];
    }
}

void kiir(vector<int> a)
{
    for(int i = 1; i < a.size(); i++)
        out << a[i]+1 << " ";
    out << endl; 
}

void kivalaszt(int n, unsigned int O, unsigned int S, unsigned int ar[],unsigned int suly[], unsigned int ts, unsigned int to, vector<int> bp)
{

  for(int i = bp[bp.size()-1] + 1; i < n; i++)
    {
        if(ts + suly[i] <= S)
        {
            bp.push_back(i);
            if(to + ar[i] >= O)
                kiir(bp);
            kivalaszt(n,O,S,ar,suly,ts+suly[i],to+ar[i],bp);
            bp.pop_back();
        }
    }

}
int main()
{
    unsigned int O = 0; //penzosszeg
    unsigned int S = 0; //suly

    unsigned int ar[1000] = {0};
    unsigned int suly[1000] = {0};
    int n;              //db aru

    beolvas(O,S,ar,suly,n);
    unsigned int ts = 0;    //jelenlegi suly - ez valtozik minden backtracking hivas utan
    unsigned int to = 0;    //jelenlegi ertek
    vector<int> zsak;       //megoldasaink
    zsak.push_back(-1);     //kedvezo kezdoertek      

    //backtrack
    kivalaszt(n,O,S,ar,suly,ts,to,zsak);
    out.close();
    return 0;
}