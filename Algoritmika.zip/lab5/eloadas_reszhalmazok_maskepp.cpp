#include <iostream>

using namespace std;

void kiir_Reszhalmaz(int v[], int k)
{
    for(int i = 1; i <= k; i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}

void reszhalmazMaskepp(int n, int v[], int k)
{
    for(int i = 1; i <= n; i++)
    {
        v[k] = i;
        if(v[k] > v[k-1])
        {
            kiir_Reszhalmaz(v,k);
            reszhalmazMaskepp(n,v,k+1);
        }
    }
}

int main()
{
    //n elemu reszhalmaz
    int n;
    int k = 1;
    int v[10];
    v[0] = -1;

    cout << "n = ";
    cin >> n;

    reszhalmazMaskepp(n,v,k);
}