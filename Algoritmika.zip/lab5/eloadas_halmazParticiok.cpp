#include <iostream>

using namespace std;

void kiir(int v[], int n)
{
    for(int i = 0; i < n; i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}

void particiok(int n, int v[], int db, int index)
{
    if(index == n)
    {
        kiir(v,n);
    }
    else
    {   
        for(int i = 1; i <= db; i++)
        {
            v[index] = i;
            if(i == db)
                particiok(n,v,db+1,index+1);
            else
                particiok(n,v,db,index+1);
        }
    }
}

int main()
{
    int n = 0;
    int v[100];         //megoldas halmaz
    int halmaz_db = 1;  //hany reszhalmazt hoztunk eddig letre
    int k = 0;          //k.elemnek tartunk
    int index = 0;

    cout << "n = ";cin >> n;
    
    particiok(n,v,halmaz_db,index);
}