 //DINERS CLUB
       else if((elsoNegy/100) == 36)printf("Diners Club");
       else if((elsoNegy/100) == 54)printf("Diners Club");