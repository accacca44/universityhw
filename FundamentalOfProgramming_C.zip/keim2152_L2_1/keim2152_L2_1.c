//Kovacs Elek Akos
//513/1
//2152
//Feladat : Ervenyesitsunk egy bankkartyaszamot

#include <stdio.h>
#include <stdlib.h>

void beolvas(int (*s)[30], int *hossz, int *input)
{
    FILE* in_file = fopen("input.txt", "r");
    *input = 1;
    if(in_file != NULL)
    {
        char aux = '\0';

        //minden karaktert beolvasok, majd atalitva szamjegyekke
        //egy sorozatban tarolom el
        while(!feof(in_file))
        {
            aux = fgetc(in_file);
            //csak a szamjegyeket olvasom be
            if(aux >= 48 && aux <= 57)
            {
                (*s)[*hossz] = aux-48;
                (*hossz)++;
            }
        }
    }
    else
    {
        *input = 0;
    }
}

int Luhn(int card[], int hossz)
{
    int controll = card[hossz-1];
    int seged_tomb[30];
    int sum = 0;

    //atmasolom a segedtombbe a szamokat
    for(int i = hossz-2; i >= 0; i--)
    {
        seged_tomb[hossz- 2 - i] = card[i];
    }
    
    for(int i = 0; i < hossz-1; i++)
    {
        //mivel az indexek 0tol kezdodnek igy index+1-re vizsgalom a paritast
        if((i+1) % 2 == 1)
        {
            seged_tomb[i] *= 2;
            if(seged_tomb[i] > 9)
                seged_tomb[i] -= 9;
        }
        sum += seged_tomb[i];
    }
    sum += controll;

    return sum;
}

int ervenyesit(int card[30], int hossz)
{
    //ellenorzom a hosszat
    if(hossz < 12 || hossz > 19)
        return 0;               //ervenytelen hossz

    int luhn = Luhn(card,hossz);//luhn's algorithm

    if(luhn % 10 != 0)
        return 0;
    return 1;
}

int azonosit(int (*card)[30], int hossz, int ok)
{
    if(ok == 0)
    {
        return -1;
    }
    else
    {
        //Visa, Mastercard, Maestro, American Express, Diners Club
        //A kartya elso negy szamjegye
        int firstFour = (*card)[0]*1000 + (*card)[1]*100 + (*card)[2]*10 + (*card)[3];
        int volt = 0;
        //VISA
        if(((*card)[0] == 4) && (hossz != 12))
        {
            return 0;
        }
        else
        {   
        
        //Maestro
            if(firstFour == 5018){return 1;}
            if(firstFour == 5020){return 1;}
            if(firstFour == 5038){return 1;}
            if(firstFour == 5893){return 1;}
            if(firstFour == 6304){return 1;}
            if(firstFour == 6759){return 1;}
            if(firstFour == 6761){return 1;}
            if(firstFour == 6762){return 1;}
            if(firstFour == 6763){return 1;}

        //MasterCard    
            if(((*card)[0] == 5 && ((*card)[1] >= 1 || (*card)[1] <= 5)) && (hossz == 16))
            {
                return 2;
            }

            if((firstFour >= 2221 && firstFour <= 2720) && (hossz == 16))
            {
                return 2;
            }
        //American Express
            if(((firstFour/100) == 34) && (hossz == 15)){return 3;}   
            if(((firstFour/100) == 37) && (hossz == 15)){return 3;}
        
        //Diners Club
            if((firstFour/100 == 36) && (hossz >= 14 || hossz <= 19)){return 4;}
            //if((firstFour/100 == 54) && (hossz == 16)){printf("Diners Club");volt = 1;return;}
        }
        
        return 5;
    }

}

void kiir(int tipus)
{
    FILE* out_file = fopen("output.txt", "w");
    if(tipus == -2)fprintf(out_file,"Nincs input allomany");
    if(tipus == -1)fprintf(out_file,"ervenytelen");
    if(tipus == 0)fprintf(out_file,"VISA");
    if(tipus == 1)fprintf(out_file,"Maestro");
    if(tipus == 2)fprintf(out_file,"MasterCard");
    if(tipus == 3)fprintf(out_file,"American Express");
    if(tipus == 4)fprintf(out_file,"Diners Club");
    if(tipus == 5)fprintf(out_file,"Ismeretlen kartya");
}

int main()
{
    int card[30] = {0};         //bankkartya elemei egy sorozatban
    int hossz = 0;              //bankkartya szamjegyeinek a szama
    int ok = 1;                 //ok == 1 ha ervenyes a kartya
    int input = 0;


    beolvas(&card,&hossz, &input);

    if(input == 1)
    {    
        ok = ervenyesit(card,hossz);

        int tipus = azonosit(&card,hossz,ok);

        kiir(tipus);
    }
    else
        kiir(-2);
    
    return 0;
}