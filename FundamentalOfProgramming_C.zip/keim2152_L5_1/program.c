//Kovacs Elek Akos
//513/1
//2152
//Lab5.1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#define maxchar 256


void kiir(bool x)
{
    FILE *out_file;
    out_file = fopen("output.txt", "w");
    if(x)
    {
        fprintf(out_file, "hiba");
    }
    if(!x)
    {
        fprintf(out_file, "okes");
    }
}

bool ellenorizve(int argc, const char *argv[])
{
    if(argc != 3)return false;
    int a1;
    int a2;
    a1 = atoi(argv[1]);
    a2 = atoi(argv[2]);
    if(a1 == 0 || a2 == 0)return false;
    return true;
}

//beolvasom egy dinamikus tombbe a karakterlancokat
void beolvas(char*** text, int* n,int start, int stop)
{
    FILE *in_file = fopen("input.txt","r");

    (*text) = (char**)malloc(sizeof(char*));
    (*n)++;
    stop--;
    start--;

    int cnt = 0;    
    char* line = (char*)malloc(sizeof(char) * maxchar);
   
    while(fgets(line,maxchar,in_file))
    {
        if(cnt >= start && cnt <= stop)
        {
            //leszukitem a lefogalt helyt a minimumra
            line = (char*)realloc(line, sizeof(char) * (strlen(line) + 1));

            //ujrafoglalok n helyet
            (*text) = (char**)realloc((*text), sizeof(char*) * (*n));
            
            //a beolvasot karakterek igy neznek ki: ['a' , 'b' , 'c' , '1' , 'a', '/n', /0];

            //lefoglalom a helyet az elozoleg beolvasott stringnek
            (*text)[*n-1] = (char*)malloc(sizeof(char) * (strlen(line) + 1));
            //atmasolom a beolvasott stringet

            //a beolvasasbol hatrebb hozom az \0t a \n helyere
            //line[strlen(line) - 1] = '\0';
            strcpy((*text)[*n-1], line);

            //printf("%s\n", (*text)[*n-1]);

            (*n)++;
        }
        cnt++;
    }
    for(int i = 0; i < *n - 2; i++)
    {
        (*text)[i][strlen((*text)[i]) - 1] = '\0';
    }
} 

//kiiratom a karakterlancokat
void kiir2(char **text, int n)
{
    FILE *out = fopen("output.txt", "w");
    for(int i = 0; i < n - 1; i++)
    {
        fprintf(out,"%d\n",(int)(text[i]));
    }
}

void getWord(char x, char** to_insert, int* add_size)
{
    switch (x)
    {
    case '0':
        strcpy(*to_insert,"nulla");
        *add_size = 4;
        break;
    case '1':
        strcpy(*to_insert,"egy");
        *add_size = 2;
        break;
    case '2':
        strcpy(*to_insert,"ketto");
        *add_size = 4;
        break;
    case '3':
        strcpy(*to_insert,"harom");
        *add_size = 4;
        break;
    case '4':
        strcpy(*to_insert,"negy");
        *add_size = 3;
        break;
    case '5':
        strcpy(*to_insert,"ot");
        *add_size = 2;
        break;
    case '6':
        strcpy(*to_insert,"hat");
        *add_size = 2;
        break;
    case '7':
        strcpy(*to_insert,"het");
        *add_size = 2;
        break;
    case '8':
        strcpy(*to_insert,"nyolc");
        *add_size = 4;
        break;
    case '9':
        strcpy(*to_insert,"kilenc");
        *add_size = 5;
        break;
    
    default:
        break;
    }
}

void feldolgoz(char*** text, int n)
{
    int add_size = 0;
    char* insert = (char*)malloc(sizeof(char) * 10);

    for(int i = 0; i < n - 1; i++)
    {

        int m = strlen((*text)[i]);
        for(int j = 0; j < strlen((*text)[i]); j++)
        {
            if((*text)[i][j] >= '0' && (*text)[i][j] <= '9')
            {
                getWord((*text)[i][j], &insert, &add_size);
                //printf("%c '%s' %d\n", (*text)[i][j], insert, add_size);
                
                (*text)[i] = (char*)realloc((*text)[i], sizeof(char) * (strlen((*text)[i]) + 1 + add_size));
                memmove((*text)[i] + j + add_size + 1, (*text)[i] + j + 1, strlen((*text)[i]) - j);
                memmove((*text)[i] + j, insert, add_size + 1);
                //printf("%d\n", strlen((*text)[i]));
            }
        }
    }

}

int main(int argc, const char *argv[])
{
    if(!ellenorizve(argc,argv))
    {
        kiir(true);
    }
    else
    {
        int start;
        int stop;
        start = atoi(argv[1]);
        stop = atoi(argv[2]);

        char **text;
        int n = 0;
        beolvas(&text, &n,start,stop);
        kiir2(text,n);

        feldolgoz(&text, n);

        kiir2(text,n);
    }

    return 0;
}