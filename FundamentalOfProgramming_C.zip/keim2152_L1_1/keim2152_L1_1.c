/*
* KOVACS ELEK AKOS
* 2152
* 513/1
* FELADAT 1
*/
# include <stdio.h>

int main()
{
    char line[257] = "";
    char key[4];
    int x,y,z;



    //olvasunk a filebol
    FILE *file_in;
    file_in = fopen("input.txt", "r");

    FILE *file_out;
    file_out = fopen("output.txt", "w");

    if(!file_out){
        printf("Error- Az output.txt nem elerheto!\n");
        return 0;
    }
    if(!file_in){
        fprintf(file_out,"Error - Az input.txt nem elerheto!\n");
        return 0;
    }

    //Beolvasom az uzenetet!
    fgets(line,257,file_in);
    //printf("%s", line);
    //Bezarom az input filet
    fclose(file_in);



    //Beolvasom a harom szamjegyet!
    scanf("%d%d%d", &x,&y,&z);

    //Beolvasok a kulcsot!
    scanf("%s", key);

    //Ellenorzom a szamjegyek helyesseget!
    if(x > 9 || x < 0){fprintf(file_out,"Error - x nem szamjegy\n");return 0;}
    if(y > 9 || y < 0){fprintf(file_out,"Error - y nem szamjegy\n");return 0;}
    if(z > 9 || z < 0){fprintf(file_out,"Error - z nem szamjegy\n");return 0;}


    //Ellenorzom a kulcs helyesseget!
    if(key[3] || !key[2]){
        fprintf(file_out,"Error - a kulcs nem megfelelo");
        return 0;
    }


    //Kodolas - Titkositas
    int i = 0;
    int d;
    char szo_bitterkep;
    while(line[i] != '\0'){
        d = ~x << (y + z);
        szo_bitterkep = key[0] & key[1] | key[2];
        line[i] = line[i] ^ d ^ szo_bitterkep;

        fprintf(file_out,"%c", line[i]);
        i++;
    }

    int bulean = 0;
    for(int j = 0; j < 26; j++){
        for(i = 0+j; i <= 234+j; i+=26){
            if(i < 256){
            if(i == 10 || i == 8 || i == 7 || i == 9 || i == 13){printf("|%3d [0x%2x]:   ",i,i,i);}
            else printf("|%3d [0x%2x]: %c ",i,i,i);
            }
        }

        printf("\n");
    }


  return 0;
}
