//Kovacs Elek Akos
//513/1
//2152
//Feladat : The Game of Life

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define SLEEP_TIME 25
#define INPUT "input_blinker.txt"

typedef struct Cella
{   
    bool allapot;                       //FALSE = HALOTT, TRUE = ELO
    bool kov_allapot;
    int eloszomszedok;                  //Halott szomszedok szama = 8 - elo. szom. szama
}Cells;

bool paramOK(int argc, const char *argv[])
{
    //ha pontosan 3 parametert adtunk meg
    if(argc != 4)return false;
    int row = atoi(argv[1]);
    int col = atoi(argv[2]);
    int iter = atoi(argv[3]);

    //ha a parameterek helyes szamok
    if(row == 0 || col == 0 || iter == 0)
        return false;
    return true;
}

//bejarom a cellamat, s minden cellat beallitok halottra
void init(Cells ***grid, int row, int col)
{
    for(int i = 0; i < row; i++)
        for(int j = 0; j < col; j++)
            (*grid)[i][j].allapot = false;
}

//kiiratom a cellaimat
void printGrid(Cells*** grid, int row, int col)
{
    for(int i = 0; i < row; i++)
    {
        for(int j = 0; j < col; j++)
        {
            if((*grid)[i][j].allapot)
                printf("%c",219);   //LIVE
            else    
                printf("%c", 32);   //DEAD
        }
        printf("\n");
    }
    printf("\n");
}

void beolvas(Cells*** grid, int row, int col, bool *file_opened)
{
    FILE* in_file = fopen(INPUT, "r");
    FILE* out_file = fopen("output.txt", "w");

    int x,y;        //koordinatak

    if(in_file == NULL)
    {
        *file_opened = false;
    }
    else
    {

        while(!feof(in_file))
        {
            fscanf(in_file, "%d%d" ,&x, &y);
            (*grid)[x][y].allapot = true;
        }

    }
}

//szomszedokat megszamolo alprogram
int cntSzomszed(Cells*** grid, int row, int col, int x, int y)
{
    int count = 0;

        for(int i = -1; i < 2; i++)
        {
            for(int j = -1; j < 2; j++)
            {
                int nextX = x + i;
                int nextY = y + j;
                if(i != 0 || j != 0)
                {

                    if(nextX < 0)nextX += row;
                    if(nextY < 0)nextY += col;

                    if(nextX >= row)nextX -= row;
                    if(nextY >= col)nextY -= col;

                    if((*grid)[nextX][nextY].allapot)
                        count++;
                }

                //printf("%c",(*grid)[nextX][nextY]);
            }
            //printf("\n");
        }
    
    return count;
}

//leszimulalom az eletet(amire a valasz 42)
void simulate(Cells*** grid, int row, int col, int iter)
{
    //iter - db generacio fog legtortenni
    for(int i = 0; i < iter; i++)
    {
        //atmegyek az osszes cellan
        for(int r = 0; r < row; r++)
        {
            for(int c = 0; c < col; c++)
            {
                (*grid)[r][c].eloszomszedok = cntSzomszed(grid,row,col,r,c);
                
                //az elet szabalyai
                if((*grid)[r][c].eloszomszedok < 2)
                    (*grid)[r][c].kov_allapot = false;

                if((*grid)[r][c].eloszomszedok == 2 || (*grid)[r][c].eloszomszedok == 3)
                {
                    if((*grid)[r][c].allapot)
                        (*grid)[r][c].kov_allapot = true;
                }

                if((*grid)[r][c].eloszomszedok > 3)
                {
                    if((*grid)[r][c].allapot)
                        (*grid)[r][c].kov_allapot = false;
                }

                if((*grid)[r][c].eloszomszedok == 3)
                {
                    if(!(*grid)[r][c].allapot)
                        (*grid)[r][c].kov_allapot = true;
                }
            }
        }

        //majd megtortenik a valtozas
        for(int r = 0; r < row; r++)
        {
            for(int c = 0; c < col; c++)
            {
                (*grid)[r][c].allapot = (*grid)[r][c].kov_allapot; 
            }
        
        }
        //system("cls");
        //HELYETTE : kurzor mozgatasa

        //rewind(stdin);
        //fseek(stdin,0L,SEEK_SET);
        
        printf("%d\n",i+1);            //Iteracio szama
        printGrid(grid,row,col);        //A cellak
        //Sleep(SLEEP_TIME);              //Kep lassitasa
    }
}

int main(int argc, const char *argv[])
{
    //ha a parancssorbol a paramterek helyesek 
    //akkor elvegezzuk a szimulaciot
    if(paramOK(argc,argv))
    {
        int row = atoi(argv[1]);
        int col = atoi(argv[2]);
        int iter = atoi(argv[3]);
        
        //dinamikusan lefoglalt Cella tipusu matrix
        Cells** grid;
        grid = (Cells**)calloc(row,sizeof(Cells*));
        for(int i = 0; i < row; i++)
        {
            grid[i] = (Cells*)calloc(col,sizeof(Cells));
        }

        //kezdetben minden cella halott
        init(&grid,row,col);

        bool file_opened_successfully = true;

        //beolvasom az elo cellakat
        beolvas(&grid, row, col, &file_opened_successfully);

        if(file_opened_successfully)
        {
            printGrid(&grid, row, col);
            //elkezdem a szimulaciot
            simulate(&grid,row,col,iter);
        }
        else
        {
            printf("hiba");
        }



    }
    else
    {
        printf("hiba");
    }
    return 0;
}