#include <stdio.h>
#include <stdlib.h>

void kiir(int **m, int a)
{
    for(int i = 0; i < a; i++)
    {
        for(int j = 0; j < a; j++)
        {
            printf("%d ",m[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    //pointer to vector of pointers
    int **m;
    m = (int**)calloc(2,sizeof(int*));

    //ponters to vectors of integers
    for(int i = 0; i < 2; i++)
    {
        m[i] = (int*)calloc(2,sizeof(int));
    }

    int a = 1;
    int newSize = 0;
    int prevSize = 2;
    while(a != 0)
    {
        scanf("%d",&a);
        newSize = a;
        m = (int**)realloc(m,newSize * sizeof(int*));
        for(int i = 0; i < prevSize; i++)
        {
            m[i] = (int*)realloc(m[i],prevSize * sizeof(int));
        }
        for(int i = prevSize; i < newSize; i++)
        {
            m[i] = (int*)calloc(newSize-prevSize, sizeof(int));
        }
        kiir(m,a);
        prevSize = newSize;
    }

    return 0;
}