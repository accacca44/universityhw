#include <stdlib.h>
#include <time.h>
#include <stdio.h>

void init(int ***m, int newSize,int lastSize)
{
    for(int i = 0; i < newSize; i++)
    {
        for(int j = lastSize; j < newSize; j++)
        {
            (*m)[i][j] = 0;
        }
    }
}

void kiir(int** m, int n)
{
    for(int i = 0; i < n; i++)
    {  
        
        for(int j = 0; j < n; j++)
        {
            printf("%d ", m[i][j]);
        }
        printf("\n",n);
    }
}
void beolvas(int ***m, int *n)
{   
    
    FILE *in_file = fopen("network.txt", "r");
    
    int newSize = 0;
    int lastSize = 2;
    //csomopontok
    int x,y;
    //distance
    int d;
    while(!feof(in_file))
    {   //beolvasom a koordinatakat
        fscanf(in_file,"%d%d%d",&x,&y,&d);

        int maxi;
        if(x >= y)maxi = x;
        else      maxi = y;

        //ha nem eleg nagy a tomb akkor foglalok meg helyet a memoriaban
        if(*n <= maxi)
        {
            *n = maxi+1;
            newSize = *n;
            
            *m = (int**)realloc(*m, *n * sizeof(int*));
            for(int i = 0; i < lastSize; i++)
            {
                (*m)[i] = (int*)realloc((*m)[i], *n * sizeof(int));
            }
            for(int i = lastSize; i < newSize; i++)
            {
                (*m)[i] = (int*)calloc(*n , sizeof(int));
            }
            init(m,newSize,lastSize);

            lastSize = newSize;
            

        }
        
        (*m)[x][y] = d;
        (*m)[y][x] = d;
        
    }
}

//beolvasom a ket szemely pozociojat
void getNodes(int *a, int *b)
{
    FILE *coord_file = fopen("input.txt", "r");
    fscanf(coord_file,"%d",a);
    fscanf(coord_file,"%d",b);
}

//bolyongas algoritmus
void bolyongas(int** m, int n, float* siker, float* tavolsag, int P, int J)
{   
    *siker = 0.0;
    *tavolsag = 0.0;
    int lepes = 0;

    while(P != J && lepes < 2*n)
    {   

        //addig valasztok egy random iranyt, meg egy helyeset nem talalok
        int newPos = rand()%(n);
        while(m[P][newPos] == 0)
        {
            newPos = rand()%(n);
        }

        //majd atlepek abba az iranyba
        *tavolsag+=m[P][newPos];
        P = newPos;
        lepes++;
    }
    if(P == J)
    {
        *siker = 1;
    }

}


int main()
{
    /*FELADAT 1 : MATRIX BELVASAS*/
    int** m;
    int n = 2;
    m = (int**)calloc(n, sizeof(int*));
    
    for(int i = 0; i < n; i++)
    {
        m[i] = (int*)calloc(n , sizeof(int));
    }
    beolvas(&m,&n);
    
    /*Feladat 2 : Julcsa es Peti helyenek beolvasasa*/
    int node_Peti = -1;
    int node_Julcsa = -1;
    getNodes(&node_Peti,&node_Julcsa);

    /*Feladat 3 : Bolyongás algoritmus*/
    srand(time(NULL));
    float atlag_sikeresseg = 0.0;
    float atlag_tav = 0.0;
    float const NAP = 365;
    for(int i = 0; i < NAP; i++)
    {
        float sik = 0.0;
        float tav = 0.0;
        bolyongas(m,n, &sik, &tav, node_Peti, node_Julcsa);
        atlag_sikeresseg += sik;
        atlag_tav += tav;
    }
    atlag_tav /= NAP;
    atlag_sikeresseg *= 100.0;
    atlag_sikeresseg /= NAP;

    /*Feladat 4 : Stratégia sikeressége*/
    FILE *out_file = fopen("output.txt","w");
    fprintf(out_file,"%0.2f \n%0.2f",atlag_sikeresseg,atlag_tav);

    /*Memoria felszabaditas*/
    for(int i = 0; i < n; i++)
    {
        free(m[i]);
    }
    free(m);

}