#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#define MAXLEN 256

struct elet{
	int tag[6];
};

struct jatekos{
	char* neve;
	char* talalgat;
	struct elet hp;
};

void ellenoriz(int* ok,int *N, int argc, const char * argv[])
{
	(*ok) = 1;

	if(argc != 2)
	{
		(*ok) = 0;
	}

	(*N) = atoi(argv[1]);
	if((*N) <= 0)
	{
		*ok = 0;
	}
}

void beolvas(char *** mondatok, int* db, struct jatekos * player)
{
	FILE* in_file = fopen("input.txt", "r");
	if(in_file == NULL)
	{
		printf("Nincs input file!");
	}
	else
	{


		char* line = (char*)calloc(MAXLEN, sizeof(char));

		while(!feof(in_file))
		{
			//beolvasom a sorokat
			fgets(line, MAXLEN, in_file);
			int hossz = strlen(line);
			line[hossz-1] = '\0';

			//lementem a tombbe
			(*mondatok) = (char **)realloc((*mondatok), (((*db) +1) * sizeof(char*)));
			(*mondatok)[(*db)] = (char*)calloc(MAXLEN,sizeof(char));
			strncpy((*mondatok)[(*db)], line, MAXLEN);
			//printf("%s\n",(*mondatok)[(*db)]);
			(*db)++;
		}
	}

	//A JATEKOS NEVE
	player->neve = (char*)calloc(MAXLEN, sizeof(char));
	printf("Jatekos neve: ");
	scanf("%s", player->neve);
	//printf("%s", player->neve);

	//JATEKOS ELETE
	for(int i = 0; i < 6; i++)
	{
		player->hp.tag[i] = 1;
	}
}

void kiir_talal(char * s, int ctr)
{
	printf("Ezeket a betuket tippelted meg eddig: ");
	int n = strlen(s);
	for(int i = 0; i < ctr; i++)
	{
		printf("%c", s[i]);
	}
	printf("\n");
}

char getTipp()
{
	char x;
	printf("\nszerinted: ");
	scanf("%c", &x);
	return x;
}

void modosit(char ** hide, char* line, char tipp)
{
	for(int i = 0; i < strlen(line); i++)
	{
		if(line[i] == tipp)
		{
			(*hide)[i] = tipp;
		}
	}
}

void jatek(int N)
{
	//INICIALIZALAS

	char** mondatok = (char**)calloc(1, sizeof(char*));
	int db = 0;
	struct jatekos player;

	beolvas(&mondatok, &db, &player);
	//UTOLSO MONDATOK 2X OLVASSA BE
	db--;

	//JATEK KEZDETE
	srand(time(NULL));
	for(int i = 0; i < N; i++)
	{
		printf("\n Uj jatek!\n");
		//kivalaszt random mondat
		int randPos = rand()%db;
		int hossz = strlen(mondatok[randPos]);
		char * jelenlegi = (char*)malloc((hossz+1) * sizeof(char));
		char* hide = (char*)malloc((hossz+1) * sizeof(char));
		strcpy(jelenlegi, mondatok[randPos]);
		strcpy(hide, mondatok[randPos]);

		for(int j = 0; j < hossz; j++)
		{
			hide[j] = '_';
		}


		int elet = 6;
		int nyert = 0;
		int ctr = 0;			//tipplet karakterek szama
		char tipp;

		player.talalgat = (char* )malloc(1 * sizeof(char));

		while(elet > 0)
		{
			if(strcmp(hide, jelenlegi) == 0)
			{
				printf("Gartulalok %s, gyoztel!", player.neve);
				break;
			}
			printf("\n %s \n", hide);

			tipp = getTipp();
			if(ctr != 0)
			{

				while(strchr(player.talalgat,tipp) != NULL)
				{
					//printf("Ezt a betut mar probaltad!\n");
					tipp = getTipp();
				}
			}
			ctr++;
			player.talalgat = (char*)realloc(player.talalgat, ctr * sizeof(char));
			player.talalgat[ctr-1] = tipp;
			kiir_talal(player.talalgat, ctr);

			if(strchr(jelenlegi, tipp) != NULL)
			{
				modosit(&hide, jelenlegi, tipp);
			}
			else
			{
				elet--;
				int randomTest = rand()%6;
				while(!player.hp.tag[randomTest])
				{
					randomTest = rand()%6;
				}
				player.hp.tag[randomTest] = 0;
				if(randomTest == 0)
				{
					printf("Fej felakasztva\n");
				}
				if(randomTest == 1)
				{
					printf("Torzs felakasztva\n");
				}
				if(randomTest == 2)
				{
					printf("Jobb kez felakasztva\n");
				}
				if(randomTest == 3)
				{
					printf("Bal kez felakasztva\n");
				}
				if(randomTest == 4)
				{
					printf("Jobb lab felakasztva\n");
				}
				if(randomTest == 5)
				{
					printf("Bal lab felakasztva\n");
				}
			}

		}
		if(elet == 0)
		{
			printf("\n %s, akasztofara kerultel! \n", player.neve);
		}

	}
}

int main(int argc, const char * argv[])
{
	int ok = 0;
	int N = 0;
	ellenoriz(&ok, &N, argc,argv);

	if(ok)
	{
		jatek(N);
	}
	else
	{
		printf("Hiba");
	}
}
