//Kovacs Elek Akos
//513/1
//2152


#include <stdio.h>
#include "keim2152_mode.h"
#include <time.h>

#if (MODE == 1)
    #include "keim2152_normal.h"

#elif (MODE == 2)
    #include "keim2152_inline.h"

#else
    #include "keim2152_macro.h"
#endif


void beolvas(int *n)
{
    FILE *fin;
    fin = fopen("input.txt", "r");

    fscanf(fin,"%d", n);
}

int fibonacci(int n)
{
    if(n < 2)
    {
        return n;
    }
    return ADD(fibonacci(n-1) , fibonacci(n-2));
}

void stopper(int n)
{
    FILE *g;
    g = fopen("output.txt", "a");
    int fib = fibonacci(n);
    double avg = 0;    
    fprintf(g,"fibonacci(%d): %d\n",n,fib);
    fprintf(g,"%s\n",STR);

    clock_t start, stop;
    for(int i = 1; i <= 5; i++)
    {
    start = clock();
    int fib = fibonacci(n);
    stop = clock();
    double eredmeny = ((double)(stop-start))/CLOCKS_PER_SEC;
    fprintf(g,"#%d run: %f\n",i,eredmeny);
    avg = avg + eredmeny;
    }
    fprintf(g,"average: %f\n",avg/5);
    fprintf(g,"\n");

}

int main()
{
    int n;
    beolvas(&n);
    stopper(n);
}