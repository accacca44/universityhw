
#define STR "inline function"

static inline int  __attribute__((always_inline)) ADD(int x, int y)
{
    return x+y;
}   
