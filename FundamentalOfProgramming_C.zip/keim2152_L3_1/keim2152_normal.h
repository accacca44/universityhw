
#define STR "normal function"

int ADD(int x, int y)
{
    return x+y;
}
