#define STR "macro function"
#define ADD(x,y) ((x)+(y))
