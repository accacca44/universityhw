#include <iostream>
#include <cmath>
#include <time.h>

using   namespace std;

int muvelet(int a, int b, int c , int d, int e, int f, int g)
{
    int eredmeny = 0;
    int elso = ((a-e)%5)-d/3;
    int masodik = (max(2*f+3,2*b/c-1)%4+a*a-g/3);
    cout << "elso :" << elso << ", masodik:" <<masodik << endl; 
    eredmeny = elso - masodik;
    return 2*eredmeny;
}

int main()
{
    srand(time(NULL));
    int v[7];

    for(int i = 0; i < 7; i++)
    {
        v[i] = rand()%200 - rand()%200;
        cout << v[i] << " "; 
    }

    int a = v[0];
    int b = v[1];
    int c = v[2];
    int d = v[3];
    int e = v[4];
    int f = v[5];
    int g = v[6];
    cout <<endl<< muvelet(a,b,c,d,e,f,g);
}